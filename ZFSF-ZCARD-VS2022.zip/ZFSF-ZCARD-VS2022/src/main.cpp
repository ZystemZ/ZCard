// ZFS-F / ZCARD prototype - Visual Studio 2022 / C++17
// Windows 10/11. Uses Windows Compression API (Cabinet.lib).
//
// This is a research prototype, not a production compression format.
// It tests whether a reversible z = z^2 + c transform helps compression
// and demonstrates transparent, block-on-demand reads.

#include <windows.h>
#include <compressapi.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>

#pragma comment(lib, "Cabinet.lib")

using Bytes = std::vector<uint8_t>;

static void die(const std::string& s) { throw std::runtime_error(s); }

template<class T> static void writeLE(std::ofstream& f, T v) { f.write(reinterpret_cast<const char*>(&v), sizeof(T)); }
template<class T> static T readLE(std::ifstream& f) { T v{}; f.read(reinterpret_cast<char*>(&v), sizeof(T)); return v; }

// ---------------- Windows Compression API ----------------
static Bytes compressLZMS(const Bytes& input) {
    COMPRESSOR_HANDLE h = nullptr;
    if (!CreateCompressor(COMPRESS_ALGORITHM_LZMS, nullptr, &h))
        die("CreateCompressor(LZMS) falhou.");

    SIZE_T needed = 0;
    Compress(h, input.data(), input.size(), nullptr, 0, &needed);
    if (!needed) { CloseCompressor(h); die("Nao foi possivel calcular o tamanho comprimido."); }

    Bytes out(needed);
    if (!Compress(h, input.data(), input.size(), out.data(), out.size(), &needed)) {
        CloseCompressor(h); die("Compress(LZMS) falhou.");
    }
    out.resize(needed);
    CloseCompressor(h);
    return out;
}

static Bytes decompressLZMS(const Bytes& input, size_t expected) {
    DECOMPRESSOR_HANDLE h = nullptr;
    if (!CreateDecompressor(COMPRESS_ALGORITHM_LZMS, nullptr, &h))
        die("CreateDecompressor(LZMS) falhou.");

    Bytes out(expected);
    SIZE_T written = 0;
    if (!Decompress(h, input.data(), input.size(), out.data(), out.size(), &written)) {
        CloseDecompressor(h); die("Decompress(LZMS) falhou.");
    }
    CloseDecompressor(h);
    out.resize(written);
    return out;
}

// ---------------- tiny integrity hash ----------------
static uint64_t fnv1a64(const Bytes& b) {
    uint64_t h = 1469598103934665603ULL;
    for (uint8_t x : b) { h ^= x; h *= 1099511628211ULL; }
    return h;
}

// ---------------- deterministic fixed-point fractal ----------------
// Q16.16. This is deliberately simple: the point is to test the idea,
// not to claim cryptographic or mathematical superiority.
struct FractalParams {
    int32_t zr0;
    int32_t zi0;
    int32_t cr;
    int32_t ci;
    uint32_t iterations;
};

static int32_t mulQ16(int32_t a, int32_t b) {
    int64_t p = (int64_t)a * (int64_t)b;
    return (int32_t)(p >> 16);
}

static uint32_t mix32(uint32_t x) {
    x ^= x >> 16; x *= 0x7feb352dU;
    x ^= x >> 15; x *= 0x846ca68bU;
    x ^= x >> 16;
    return x;
}

// Generate a reversible mask from the orbit. The decoder runs exactly the
// same function and XORs it again.
static Bytes fractalMask(size_t n, uint64_t seed, uint32_t blockIndex, const FractalParams& p) {
    Bytes mask(n);
    int32_t zr = p.zr0 ^ (int32_t)mix32((uint32_t)seed ^ blockIndex);
    int32_t zi = p.zi0 ^ (int32_t)mix32((uint32_t)(seed >> 32) ^ blockIndex * 0x9E3779B9U);
    int32_t cr = p.cr;
    int32_t ci = p.ci;
    uint32_t s = mix32((uint32_t)seed ^ blockIndex * 0xA341316CU);

    for (size_t i = 0; i < n; ++i) {
        for (uint32_t k = 0; k < p.iterations; ++k) {
            int32_t zr2 = mulQ16(zr, zr);
            int32_t zi2 = mulQ16(zi, zi);
            int32_t zri = mulQ16(zr, zi);
            int64_t nr = (int64_t)zr2 - zi2 + cr;
            int64_t ni = (int64_t)(zri * 2LL) + ci;
            // Keep the finite-point experiment stable.
            zr = (int32_t)std::clamp<int64_t>(nr, -8LL * 65536, 8LL * 65536);
            zi = (int32_t)std::clamp<int64_t>(ni, -8LL * 65536, 8LL * 65536);
        }
        uint32_t a = (uint32_t)std::abs(zr);
        uint32_t b = (uint32_t)std::abs(zi);
        s = mix32(s ^ a ^ (b * 0x9E3779B9U) ^ (uint32_t)i);
        mask[i] = (uint8_t)(s >> 24);
    }
    return mask;
}

static Bytes xorBytes(const Bytes& a, const Bytes& b) {
    Bytes r(a.size());
    for (size_t i = 0; i < a.size(); ++i) r[i] = a[i] ^ b[i];
    return r;
}

// ---------------- ZCARD format ----------------
#pragma pack(push,1)
struct ZCardHeader {
    char magic[4];          // ZCF1
    uint16_t version;       // 1
    uint16_t flags;
    uint32_t blockSize;
    uint64_t originalSize;
    uint32_t blockCount;
    uint32_t headerSize;
    uint64_t sourceHash;
    uint64_t fractalSeed;
    FractalParams fractal;
};

struct ZCardEntry {
    uint64_t offset;
    uint32_t storedSize;
    uint32_t rawSize;
    uint8_t mode;           // 0 RAW, 1 LZMS, 2 FRACTAL+LZMS
    uint8_t reserved[3];
};
#pragma pack(pop)

static constexpr uint8_t MODE_RAW = 0;
static constexpr uint8_t MODE_LZMS = 1;
static constexpr uint8_t MODE_FRACTAL_LZMS = 2;

static Bytes readAll(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) die("Nao abriu: " + path);
    f.seekg(0, std::ios::end); auto n = f.tellg(); f.seekg(0);
    Bytes b((size_t)n); f.read((char*)b.data(), b.size()); return b;
}

static void writeZCard(const std::string& inputPath, const std::string& outPath,
                       uint32_t blockSize, uint64_t seed, FractalParams fp) {
    Bytes source = readAll(inputPath);
    uint32_t blocks = (uint32_t)((source.size() + blockSize - 1) / blockSize);
    std::vector<ZCardEntry> table(blocks);
    std::vector<Bytes> payloads(blocks);

    size_t totalStored = 0;
    size_t totalFractal = 0;

    for (uint32_t i = 0; i < blocks; ++i) {
        size_t off = (size_t)i * blockSize;
        size_t n = std::min<size_t>(blockSize, source.size() - off);
        Bytes raw(source.begin() + off, source.begin() + off + n);

        Bytes lz = compressLZMS(raw);
        Bytes mask = fractalMask(n, seed, i, fp);
        Bytes transformed = xorBytes(raw, mask);
        Bytes flz = compressLZMS(transformed);

        uint8_t mode = MODE_RAW;
        Bytes best = raw;
        if (lz.size() < best.size()) { mode = MODE_LZMS; best = std::move(lz); }
        if (flz.size() < best.size()) { mode = MODE_FRACTAL_LZMS; best = std::move(flz); }

        if (mode == MODE_FRACTAL_LZMS) totalFractal += best.size();
        totalStored += best.size();
        table[i].storedSize = (uint32_t)best.size();
        table[i].rawSize = (uint32_t)n;
        table[i].mode = mode;
        table[i].reserved[0] = table[i].reserved[1] = table[i].reserved[2] = 0;
        payloads[i] = std::move(best);
    }

    ZCardHeader h{};
    memcpy(h.magic, "ZCF1", 4);
    h.version = 1;
    h.flags = 1; // has fractal parameters
    h.blockSize = blockSize;
    h.originalSize = source.size();
    h.blockCount = blocks;
    h.headerSize = sizeof(ZCardHeader) + (uint32_t)(table.size() * sizeof(ZCardEntry));
    h.sourceHash = fnv1a64(source);
    h.fractalSeed = seed;
    h.fractal = fp;

    uint64_t payloadOffset = h.headerSize;
    for (uint32_t i = 0; i < blocks; ++i) {
        table[i].offset = payloadOffset;
        payloadOffset += payloads[i].size();
    }

    std::ofstream out(outPath, std::ios::binary);
    if (!out) die("Nao abriu saida: " + outPath);
    out.write((char*)&h, sizeof(h));
    for (auto& e : table) out.write((char*)&e, sizeof(e));
    for (auto& p : payloads) out.write((char*)p.data(), p.size());

    std::cout << "ZCARD criado: " << outPath << "\n";
    std::cout << "Original: " << source.size() << " bytes\n";
    std::cout << "ZCARD payload: " << totalStored << " bytes\n";
    std::cout << "Fractal+LZMS usado em " << totalFractal << " bytes de payload\n";
    std::cout << "Reducao payload: " << (100.0 * (1.0 - (double)totalStored / source.size())) << "%\n";
}

static void verifyZCard(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) die("Nao abriu ZCARD.");
    ZCardHeader h{}; f.read((char*)&h, sizeof(h));
    if (memcmp(h.magic, "ZCF1", 4) != 0) die("Magic ZCF1 invalido.");
    std::vector<ZCardEntry> table(h.blockCount);
    for (auto& e : table) f.read((char*)&e, sizeof(e));

    Bytes reconstructed; reconstructed.reserve((size_t)h.originalSize);
    for (uint32_t i = 0; i < h.blockCount; ++i) {
        auto& e = table[i];
        f.seekg((std::streamoff)e.offset);
        Bytes stored(e.storedSize); f.read((char*)stored.data(), stored.size());
        Bytes raw;
        if (e.mode == MODE_RAW) raw = stored;
        else {
            Bytes t = decompressLZMS(stored, e.rawSize);
            if (e.mode == MODE_LZMS) raw = std::move(t);
            else if (e.mode == MODE_FRACTAL_LZMS) {
                Bytes mask = fractalMask(e.rawSize, h.fractalSeed, i, h.fractal);
                raw = xorBytes(t, mask);
            } else die("Modo desconhecido.");
        }
        reconstructed.insert(reconstructed.end(), raw.begin(), raw.end());
    }
    if (reconstructed.size() != h.originalSize) die("Tamanho reconstruido incorreto.");
    uint64_t hash = fnv1a64(reconstructed);
    std::cout << "Hash esperado : " << std::hex << h.sourceHash << "\n";
    std::cout << "Hash obtido   : " << std::hex << hash << "\n" << std::dec;
    std::cout << (hash == h.sourceHash ? "OK - ZCARD reproduz exatamente os dados.\n" : "ERRO - dados diferentes!\n");
}

static void printStats(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    ZCardHeader h{}; f.read((char*)&h, sizeof(h));
    if (memcmp(h.magic, "ZCF1", 4) != 0) die("Nao e ZCF1.");
    std::vector<ZCardEntry> t(h.blockCount);
    for (auto& e : t) f.read((char*)&e, sizeof(e));
    size_t raw=0,lz=0,fr=0;
    for (auto&e:t) { if(e.mode==MODE_RAW)raw+=e.storedSize; else if(e.mode==MODE_LZMS)lz+=e.storedSize; else fr+=e.storedSize; }
    std::cout << "Original : " << h.originalSize << " bytes\n";
    std::cout << "Header+indice: " << h.headerSize << " bytes\n";
    std::cout << "RAW: " << raw << " | LZMS: " << lz << " | FRACTAL+LZMS: " << fr << "\n";
}

int main(int argc, char** argv) {
    try {
        if (argc < 2) {
            std::cout << "ZFS-F ZCARD prototype\n\n"
                      << "Uso:\n"
                      << "  zfsf.exe make input.gb output.zcard [blockSize]\n"
                      << "  zfsf.exe verify file.zcard\n"
                      << "  zfsf.exe stats file.zcard\n";
            return 0;
        }
        std::string cmd = argv[1];
        if (cmd == "make" && argc >= 4) {
            uint32_t bs = argc >= 5 ? (uint32_t)std::stoul(argv[4]) : 65536;
            // c = -0.123 + 0.745i; seed is stored in the header.
            FractalParams fp{};
            fp.zr0 = 0; fp.zi0 = 0;
            fp.cr = (int32_t)(-0.123 * 65536.0);
            fp.ci = (int32_t)( 0.745 * 65536.0);
            fp.iterations = 1;
            writeZCard(argv[2], argv[3], bs, 0x5A46534643415244ULL, fp);
            return 0;
        }
        if (cmd == "verify" && argc >= 3) { verifyZCard(argv[2]); return 0; }
        if (cmd == "stats" && argc >= 3) { printStats(argv[2]); return 0; }
        die("Argumentos invalidos.");
    } catch (const std::exception& e) {
        std::cerr << "ERRO: " << e.what() << "\n"; return 1;
    }
}
