# ZFS-F / ZCARD Prototype — Visual Studio 2022

Protótipo de pesquisa para testar a ideia de usar `z = z² + c` como uma transformação reversível antes de uma compressão convencional.

## O que este protótipo testa

- ZCARD binário próprio (`ZCF1`), sem ZIP.
- Dados divididos em blocos.
- `RAW` quando comprimir não compensa.
- `LZMS` da Windows Compression API.
- `FRACTAL+LZMS`: gera uma máscara determinística a partir de `z = z² + c`, faz XOR e depois comprime.
- Leitura/reconstrução bloco a bloco.
- Verificação por hash FNV-1a-64.

O fractal **não é tratado como criptografia** e o projeto não afirma que a transformação melhora compressão. O objetivo é medir.

## Compilar

Abra `ZFSF-ZCARD.sln` no Visual Studio 2022 e compile `Release | x64`.

Requer Windows SDK e `Cabinet.lib` (já incluído no Windows SDK). O projeto usa `#pragma comment(lib, "Cabinet.lib")`.

## Uso

```text
zfsf.exe make capybara.gb capybara.zcard
zfsf.exe stats capybara.zcard
zfsf.exe verify capybara.zcard
```

Tamanho de bloco opcional:

```text
zfsf.exe make capybara.gb capybara.zcard 65536
```

## Fluxo de leitura

O formato foi pensado para permitir:

```text
CPU/emulador
    -> Read(address)
    -> identifica bloco
    -> lê apenas o bloco comprimido
    -> LZMS
    -> se necessário desfaz XOR fractal
    -> cache do bloco
    -> retorna byte
```

Portanto, não é necessário descompactar a ROM inteira antes da execução.

## Próxima etapa

A próxima versão deve comparar vários modelos fractais, tamanhos de bloco e preditores. O objetivo é encontrar situações em que `FRACTAL+compressor` realmente fique menor que `compressor` sozinho.
