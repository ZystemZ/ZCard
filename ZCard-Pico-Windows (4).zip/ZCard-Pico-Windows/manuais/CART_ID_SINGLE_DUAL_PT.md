# CART_ID — identificação segura de cartuchos simples e duplos

O projeto usa um pino separado de identificação física para não confundir:

- cartucho simples, com um chip;
- cartucho duplo, cujo segundo chip está ausente ou com defeito.

## Ligações

```text
CART_ID do cartucho simples → 10 kΩ → GND
CART_ID do cartucho duplo   → 10 kΩ → 3V3
```

No Pico:

```text
CART_ID → GP21
GP21 configurado como entrada com pull-down
```

Não aterre o `CS1#` diretamente. `CS1#` é uma saída do Pico e serve exclusivamente para selecionar o segundo W25Q.

## Validação

| CART_ID | CS0# | CS1# | Comportamento |
|---|---|---|---|
| SINGLE/baixo | responde | ausente | aceita um chip |
| DUAL/alto | responde | responde | aceita dois chips |
| DUAL/alto | responde | ausente | erro `CART_TYPE_MISMATCH`; não monta MSC |
| SINGLE/baixo | responde | responde | erro de configuração; não monta MSC |

O firmware lê o JEDEC ID de cada posição, calcula a capacidade e somente libera CDC/MSC quando o tipo declarado e o número de chips detectado coincidem.

## Conector atualizado

```text
1 — 3V3
2 — GND
3 — SCK / GP18
4 — MOSI / GP19
5 — MISO / GP16
6 — CS0# / GP17
7 — CS1# / GP20
8 — CART_ID / GP21
```

## Firmware

O código atualizado está em:

```text
pico-zhs/src/main.c
pico-arduino-zhs/pico_arduino_zhs.ino
```

O status adicional é:

```text
ST_CART_TYPE_MISMATCH = 9
```

O MSC retorna dispositivo não pronto quando a configuração não corresponde, evitando que o Windows monte uma capacidade incorreta e peça formatação.
