# ZCard Pico ZHS — Guia Windows

Este pacote foi preparado para **Windows 10/11**. Não use `sudo`, `apt`, caminhos `/home/...` ou comandos Linux.

## Conteúdo

```text
pico-zhs/                 Projeto VS Code + Pico SDK + CMake
pico-arduino-zhs/         Projeto para Arduino IDE
host-csharp/              Cliente C# de teste ZHS
manuais/                  Documentação em português
```

## Escolha rápida

### Quero testar pela Arduino IDE

Use a pasta:

```text
pico-arduino-zhs
```

Ela contém o sketch completo com USB Serial, SPI e protocolo ZHS somente leitura.

### Quero usar Pico SDK/TinyUSB/MSC

Use a pasta:

```text
pico-zhs
```

Ela contém o projeto CMake e os descritores USB. Para o código CDC atual, a compilação pelo VS Code é a opção mais segura. O modo MSC deve ser mantido em firmware separado.

## Parte 1 — Arduino IDE

### Instalar a Arduino IDE

1. Baixe e instale a Arduino IDE 2.x pelo site oficial do Arduino.
2. Abra **Arquivo > Preferências**.
3. Em **URLs adicionais para gerenciadores de placas**, adicione:

```text
https://github.com/earlephilhower/arduino-pico/releases/download/global/package_rp2040_index.json
```

4. Abra **Ferramentas > Placa > Gerenciador de Placas**.
5. Pesquise `pico`.
6. Instale **Raspberry Pi Pico/RP2040 by Earle F. Philhower**.

### Abrir o sketch

1. Abra a Arduino IDE.
2. Clique em **Arquivo > Abrir**.
3. Selecione:

```text
pico-arduino-zhs\pico_arduino_zhs.ino
```

4. Em **Ferramentas > Placa**, escolha:
   - `Raspberry Pi Pico` para Pico original;
   - `Raspberry Pi Pico 2` para Pico 2.
5. Em **Ferramentas > Porta**, selecione a porta COM, se já aparecer.
6. Clique em **Verificar** para compilar.

### Gravar pela primeira vez

1. Desconecte o Pico.
2. Segure `BOOTSEL`.
3. Conecte o cabo USB.
4. Solte `BOOTSEL`.
5. Na Arduino IDE, selecione **Ferramentas > Porta > UF2 Board** ou a opção equivalente que aparecer.
6. Clique em **Upload**.

Se a Arduino IDE não encontrar a porta na primeira gravação, use o método manual: compile, localize o arquivo `.uf2` gerado e copie-o para a unidade `RPI-RP2` no Explorador de Arquivos.

### Testar o sketch

Abra **Ferramentas > Monitor Serial** e configure `115200 baud`.

O sketch não deve imprimir mensagens de diagnóstico durante o uso normal, pois transmite quadros binários ZHS. Para testar o hardware, use o cliente C# ou um programa que envie quadros ZHS.

### Alterar entre W25Q64 e W25Q128

No arquivo `pico_arduino_zhs.ino`:

Para W25Q64:

```cpp
constexpr uint32_t FLASH_CAPACITY = 8u * 1024u * 1024u;
```

Para W25Q128:

```cpp
constexpr uint32_t FLASH_CAPACITY = 16u * 1024u * 1024u;
```

## Parte 2 — VS Code + Pico SDK + CMake

### Instalar no Windows

Instale estes programas para Windows:

1. **Visual Studio Code**;
2. extensão **Raspberry Pi Pico** no VS Code;
3. **Git for Windows**;
4. **CMake para Windows**;
5. **Ninja para Windows**;
6. **Arm GNU Toolchain para Windows**.

Não execute comandos `sudo`, `apt` ou `gcc-arm-none-eabi` neste manual: eles são comandos de Linux e não pertencem ao procedimento Windows.

A extensão Raspberry Pi Pico pode oferecer a instalação automática do SDK e da toolchain. Aceite essa opção quando aparecer.

### Instalar SDK pelo PowerShell

Abra o PowerShell e execute:

```powershell
New-Item -ItemType Directory -Force "$env:USERPROFILE\pico" | Out-Null
Set-Location "$env:USERPROFILE\pico"
git clone --depth 1 https://github.com/raspberrypi/pico-sdk.git
Set-Location "$env:USERPROFILE\pico\pico-sdk"
git submodule update --init
[Environment]::SetEnvironmentVariable("PICO_SDK_PATH", "$env:USERPROFILE\pico\pico-sdk", "User")
```

Feche e reabra o VS Code depois desse procedimento.

### Preparar o projeto

O ZIP já inclui `pico_sdk_import.cmake`. Não é necessário copiá-lo de um caminho Linux.

Abra no VS Code a pasta:

```text
zcardemu\pico-zhs
```

Use **Arquivo > Abrir Pasta**, nunca abra apenas o arquivo `main.c`.

O VS Code exibirá a recomendação de instalar as extensões listadas em:

```text
pico-zhs\.vscode\extensions.json
```

### Compilar pelo VS Code

1. Abra a pasta `pico-zhs`.
2. Pressione `Ctrl+Shift+P`.
3. Execute **CMake: Select Configure Preset** ou **CMake: Configure**.
4. Selecione o kit ARM GNU.
5. Para Pico original, configure `PICO_BOARD=pico`.
6. Para Pico 2, configure `PICO_BOARD=pico2`.
7. Pressione `F7` ou execute **CMake: Build**.

O arquivo final ficará em:

```text
pico-zhs\build\pico_zhs.uf2
```

### Compilar pelo PowerShell

Abra o PowerShell dentro de `pico-zhs`:

```powershell
cmake -S . -B build -G Ninja -DPICO_BOARD=pico
cmake --build build
```

Para Pico 2:

```powershell
Remove-Item -Recurse -Force .\build -ErrorAction SilentlyContinue
cmake -S . -B build -G Ninja -DPICO_BOARD=pico2
cmake --build build
```

### Gravar o UF2

1. Segure `BOOTSEL` no Pico.
2. Conecte o USB.
3. Solte o botão.
4. Abra o Explorador de Arquivos.
5. Abra a unidade `RPI-RP2`.
6. Copie `pico_zhs.uf2` para essa unidade.

O Pico reinicia automaticamente.

## Ligação da flash

```text
Pico GP18  -> W25Q CLK
Pico GP16  -> W25Q DO/MISO
Pico GP19  -> W25Q DI/MOSI
Pico GP17  -> W25Q CS#
Pico 3V3   -> W25Q VCC
Pico GND   -> W25Q GND
```

No CI SOIC-8, mantenha `WP#` e `HOLD#/RESET#` em 3,3 V através de resistores de 10 kΩ. Use capacitor de 100 nF entre VCC e GND junto ao chip.

## Porta COM e cliente C#

Depois da gravação normal, o Pico aparece como uma porta COM. Exemplo:

```text
COM7
```

O cliente de teste está em:

```text
host-csharp\ZhsPicoDevice.cs
```

A classe usa `System.IO.Ports.SerialPort` e implementa `GET_INFO`, `READ`, `VERIFY` e `GET_STATUS`.

## Problemas comuns no Windows

### `sudo` não existe

Isso indica que um comando Linux foi usado no PowerShell. Ignore esses comandos. Use somente os comandos PowerShell deste manual.

### `cmake não é reconhecido`

Reinstale o CMake para Windows e marque a opção **Add CMake to the system PATH**. Feche e reabra o PowerShell.

### `ninja não é reconhecido`

Instale Ninja para Windows ou use a extensão Raspberry Pi Pico para instalar as ferramentas.

### `arm-none-eabi-gcc não é reconhecido`

Instale Arm GNU Toolchain para Windows e adicione a pasta `bin` ao PATH, ou selecione o kit pela extensão Raspberry Pi Pico.

### O Pico aparece como `RPI-RP2`, mas não como COM

`RPI-RP2` é o modo de gravação BOOTSEL. Depois de copiar o UF2 e o Pico reiniciar, a porta CDC deve aparecer como COM.

### O JEDEC ID retorna zero ou FF

Confira VCC de 3,3 V, GND, CS, CLK, MOSI, MISO, `WP#`, `HOLD#` e fios curtos. Comece com SPI a 1 MHz.
