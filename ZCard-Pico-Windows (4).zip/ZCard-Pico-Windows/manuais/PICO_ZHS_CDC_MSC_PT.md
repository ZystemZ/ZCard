# Pico: ZHS por USB CDC, cliente C# e MSC somente leitura

## Observação sobre a linguagem do ZCardEmulator

O pacote `ZCardEmulator-native-emulators-1-9-0` analisado anteriormente é C++/Win32, não C#. A classe C# deste diretório é uma implementação de referência para um host separado ou para uma futura ferramenta .NET. No programa atual, a mesma lógica deve ser portada para uma classe C++ derivada de `ZhsDevice`.

## Firmware criado

O diretório `pico-zhs` contém um esqueleto para Pico SDK:

- `src/main.c`: SPI0, comando JEDEC `0x9F`, leitura `0x03`, parser ZHS e USB CDC;
- `src/usb_descriptors.c`: descriptor USB CDC;
- `include/tusb_config.h`: TinyUSB CDC ativado;
- `CMakeLists.txt`: alvo Pico SDK.

Pinagem usada:

```text
GP18  -> CLK
GP16  -> DO/MISO
GP19  -> DI/MOSI
GP17  -> CS#
3V3   -> VCC
GND   -> GND
```

O firmware assume W25Q128 com 16 MiB. Para W25Q64, altere `FLASH_CAPACITY` em `main.c` para `8u * 1024u * 1024u`.

O código começa a 1 MHz SPI. Depois de validar o hardware, aumente gradualmente. `WP#` e `HOLD#/RESET#` devem ficar em 3,3 V por pull-up no CI solto.

## Observação importante sobre o quadro READ

O contrato ZHS V0.1 do projeto usa o tamanho do payload da requisição para indicar quantos bytes devem ser lidos. Por isso o host envia `count` bytes de preenchimento, não um payload vazio. Isso é compatível com o dispatcher C++ atual.

## Compilação do Pico

Instale o Pico SDK e disponibilize `pico_sdk_import.cmake` ao projeto. O TinyUSB já vem integrado ao SDK nos exemplos usuais. Depois:

```bash
cmake -S pico-zhs -B pico-zhs/build -DPICO_BOARD=pico
cmake --build pico-zhs/build
```

O resultado esperado é `pico_zhs.uf2`. O código não foi compilado nesta sandbox porque Pico SDK, CMake e toolchain ARM não estão instalados aqui.

## Cliente C#

`host-csharp/ZhsPicoDevice.cs` usa `System.IO.Ports.SerialPort`. Ele:

- monta o frame little-endian;
- calcula CRC32 igual ao C++/Pico;
- confere magic, versão, comando e `request_id`;
- implementa `GetInfo`, `Read`, `Verify` e `GetStatus`;
- rejeita status ZHS diferente de `OK`.

Uso básico:

```csharp
using var pico = new ZCardHost.ZhsPicoDevice("COM7");
pico.Open();
var info = pico.GetInfo();
byte[] header = pico.Read(0, 64);
pico.Verify();
```

Para um leitor real no C++ do projeto atual, crie `ZhsSerialDevice : public ZhsDevice` e reutilize exatamente a codificação do arquivo `src/zcard/zhs_device.cpp`. No Windows, a porta CDC do Pico aparece como COM; em Linux aparece normalmente como `/dev/ttyACM0`.

## MSC somente leitura

`src/msc_disk.c` mostra os callbacks TinyUSB necessários. Para ativá-lo:

1. troque `CFG_TUD_MSC` para `1` em `tusb_config.h`;
2. altere o descriptor para um dispositivo composto CDC + MSC;
3. inclua `src/msc_disk.c` no alvo;
4. altere o descritor de configuração para `TUD_CDC_DESCRIPTOR(...)` seguido de `TUD_MSC_DESCRIPTOR(...)`;
5. aumente o `CONFIG_TOTAL_LEN` para `TUD_CONFIG_DESC_LEN + TUD_CDC_DESC_LEN + TUD_MSC_DESC_LEN`;
6. mantenha `MSC_BLOCK_SIZE = 512`;
7. faça `block_count = capacidade / 512`;
8. retorne `false` em `tud_msc_is_writable_cb`;
9. retorne falha e sense `DATA_PROTECT` em `tud_msc_write10_cb`;
10. implemente `READ10` traduzindo `lba * 512 + offset` para endereço SPI.

O host espera os comandos SCSI básicos `INQUIRY`, `TEST UNIT READY`, `READ CAPACITY`, `READ FORMAT CAPACITY`, `MODE SENSE`, `REQUEST SENSE`, `READ10` e `WRITE10`. TinyUSB trata vários deles internamente; os callbacks completam a capacidade, leitura e bloqueio de escrita. O exemplo oficial CDC+MSC usa um disco FAT12 de 8 KiB como menor mídia que o Windows monta; para um W25Q128 será necessário gravar uma imagem FAT válida na flash, não apenas expor bytes arbitrários.

### A flash precisa conter um filesystem

MSC não expõe automaticamente um arquivo `.zcard`. Ele expõe setores de um disco. Para aparecer no Explorer com `GAME.ZCARD`, prepare uma imagem FAT12/FAT16 com:

```text
BOOT SECTOR
FAT
ROOT DIRECTORY
GAME.ZCARD
```

Depois grave essa imagem começando no endereço zero da W25Q. O tamanho do arquivo mais as estruturas FAT devem caber nos 16 MiB. O emulador pode abrir `GAME.ZCARD` pelo caminho da unidade.

### Não misture MSC e ZHS no mesmo momento

CDC/ZHS e MSC podem coexistir no descriptor USB, mas não devem acessar a flash simultaneamente. Use um modo selecionado no boot:

```text
botão pressionado ao ligar -> MSC somente leitura
sem botão -> ZHS CDC
```

Ou use dois firmwares separados. Isso evita que o Windows leia o filesystem enquanto o host ZHS faz leituras aleatórias.

### Limitação do MSC somente leitura

Mesmo marcado como somente leitura, alguns sistemas operacionais podem enviar comandos de montagem, cache ou tentativa de escrita. O firmware deve rejeitar toda escrita e o hardware deve manter `WP#` em nível alto. Não use MSC para atualizar o cartão; grave a flash com um programador ou crie depois um modo de atualização autenticado.

## Referências

- [TinyUSB CDC + MSC](https://docs.tinyusb.org/en/latest/examples/device/cdc_msc.html)
- [Exemplo TinyUSB MSC read-only](https://github.com/hathach/tinyusb/blob/master/examples/device/cdc_msc/src/msc_disk.c)
- [Pico SDK Hardware APIs](https://www.raspberrypi.com/documentation/pico-sdk/hardware.html)
- `docs/ZHS_PROTOCOL.md` do ZCardEmulator
