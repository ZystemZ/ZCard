$ErrorActionPreference = 'Stop'

Write-Host '=== ZCard Pico - preparação do ambiente Windows ===' -ForegroundColor Cyan

function Require-Command($name, $hint) {
  if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
    Write-Warning "$name não foi encontrado. $hint"
  } else {
    Write-Host "$name OK" -ForegroundColor Green
  }
}

Require-Command git 'Instale Git for Windows.'
Require-Command cmake 'Instale CMake para Windows e adicione-o ao PATH.'
Require-Command ninja 'Instale Ninja ou use a extensão Raspberry Pi Pico do VS Code.'

$sdk = Join-Path $env:USERPROFILE 'pico\pico-sdk'
New-Item -ItemType Directory -Force (Split-Path $sdk) | Out-Null
if (-not (Test-Path $sdk)) {
  git clone --depth 1 https://github.com/raspberrypi/pico-sdk.git $sdk
}
Set-Location $sdk
git submodule update --init
[Environment]::SetEnvironmentVariable('PICO_SDK_PATH', $sdk, 'User')

Write-Host ''
Write-Host "PICO_SDK_PATH configurado para: $sdk" -ForegroundColor Green
Write-Host 'Feche e reabra o VS Code e o PowerShell antes de compilar.' -ForegroundColor Yellow
Write-Host 'A toolchain ARM GNU pode ser instalada pela extensão Raspberry Pi Pico do VS Code.'
