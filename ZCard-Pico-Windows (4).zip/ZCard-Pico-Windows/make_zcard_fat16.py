#!/usr/bin/env python3
"""Cria uma imagem FAT16 de 32 MiB e divide em dois BINs de 16 MiB.
Uso no Windows PowerShell:
  py make_zcard_fat16.py jogo.zcard
"""
from pathlib import Path
import struct, sys, hashlib

SECTOR = 512
TOTAL_SECTORS = 65536
FAT_START = 1
FAT_SECTORS = 128
FAT2_START = FAT_START + FAT_SECTORS
ROOT_START = FAT2_START + FAT_SECTORS
ROOT_SECTORS = 32
DATA_START = ROOT_START + ROOT_SECTORS
SPC = 2
CLUSTER_BYTES = SECTOR * SPC
TOTAL_CLUSTERS = (TOTAL_SECTORS - DATA_START) // SPC


def short_name(name: str) -> bytes:
    base, dot, ext = name.upper().partition('.')
    return (base[:8].ljust(8) + ext[:3].ljust(3)).encode('ascii')


def lfn_entry(long_name: str, alias: bytes) -> bytes:
    """Cria uma entrada VFAT LFN para um nome curto ASCII simples."""
    checksum = 0
    for value in alias:
        checksum = ((checksum & 1) << 7) + (checksum >> 1) + value
        checksum &= 0xFF
    entry = bytearray(32)
    entry[0] = 0x41  # última/única entrada LFN
    entry[11] = 0x0F
    entry[13] = checksum
    chars = [ord(c) for c in long_name] + [0]
    chars += [0xFFFF] * (13 - len(chars))
    for index, offset in enumerate((1, 3, 5, 7, 9)):
        struct.pack_into('<H', entry, offset, chars[index])
    for index, offset in enumerate((14, 16, 18, 20, 22, 24)):
        struct.pack_into('<H', entry, offset, chars[index + 5])
    for index, offset in enumerate((28, 30)):
        struct.pack_into('<H', entry, offset, chars[index + 11])
    return bytes(entry)


def fat16_image(zcard: bytes) -> bytearray:
    img = bytearray(TOTAL_SECTORS * SECTOR)
    boot = memoryview(img)[:SECTOR]
    boot[0:3] = b'\xEB\x3C\x90'
    boot[3:11] = b'MSDOS5.0'
    struct.pack_into('<H', boot, 11, SECTOR)
    boot[13] = SPC
    struct.pack_into('<H', boot, 14, 1)
    boot[16] = 2
    struct.pack_into('<H', boot, 17, 512)
    # 65536 não cabe no campo TotSec16; FAT16 usa TotSec32 quando ele é zero.
    struct.pack_into('<H', boot, 19, 0)
    boot[21] = 0xF8
    struct.pack_into('<H', boot, 22, FAT_SECTORS)
    struct.pack_into('<H', boot, 24, 32)
    struct.pack_into('<H', boot, 26, 64)
    struct.pack_into('<I', boot, 28, 0)
    struct.pack_into('<I', boot, 32, TOTAL_SECTORS)
    boot[36] = 0x80
    boot[38] = 0x29
    struct.pack_into('<I', boot, 39, 0x5A434152)
    boot[43:54] = b'ZCARD 32MB '
    boot[54:62] = b'FAT16   '
    boot[510:512] = b'\x55\xAA'

    fat = bytearray(FAT_SECTORS * SECTOR)
    struct.pack_into('<HH', fat, 0, 0xFFF8, 0xFFFF)
    clusters_needed = (len(zcard) + CLUSTER_BYTES - 1) // CLUSTER_BYTES
    if clusters_needed == 0:
        clusters_needed = 1
    if clusters_needed > TOTAL_CLUSTERS - 1:
        raise ValueError('GAME.ZCARD não cabe na área de dados FAT16')
    first_cluster = 2
    for i in range(clusters_needed):
        current = first_cluster + i
        nxt = 0xFFFF if i == clusters_needed - 1 else current + 1
        struct.pack_into('<H', fat, current * 2, nxt)
    img[FAT_START * SECTOR:(FAT_START + FAT_SECTORS) * SECTOR] = fat
    img[FAT2_START * SECTOR:(FAT2_START + FAT_SECTORS) * SECTOR] = fat

    root = memoryview(img)[ROOT_START * SECTOR:(ROOT_START + ROOT_SECTORS) * SECTOR]
    root[0:11] = b'ZCARD 32MB '
    root[11] = 0x08
    alias = short_name('GAME~1.ZCF')
    root[32:64] = lfn_entry('GAME.ZCARD', alias)
    entry = 64
    root[entry:entry+11] = alias
    root[entry+11] = 0x20
    struct.pack_into('<H', root, entry + 26, first_cluster)
    struct.pack_into('<I', root, entry + 28, len(zcard))

    data_offset = DATA_START * SECTOR
    img[data_offset:data_offset + len(zcard)] = zcard
    return img


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    if len(sys.argv) != 2:
        print('Uso: py make_zcard_fat16.py jogo.zcard')
        return 2
    source = Path(sys.argv[1])
    if not source.is_file():
        print(f'Arquivo não encontrado: {source}')
        return 2
    zcard = source.read_bytes()
    img = fat16_image(zcard)
    stem = source.stem
    image_path = Path(f'{stem}_32mib_fat16.img')
    chip_a = Path(f'{stem}_chip_a_16mib.bin')
    chip_b = Path(f'{stem}_chip_b_16mib.bin')
    image_path.write_bytes(img)
    chip_a.write_bytes(img[:16 * 1024 * 1024])
    chip_b.write_bytes(img[16 * 1024 * 1024:])
    print(f'Imagem: {image_path} ({len(img)} bytes) SHA256 {sha256(image_path)}')
    print(f'Chip A: {chip_a} ({chip_a.stat().st_size} bytes) SHA256 {sha256(chip_a)}')
    print(f'Chip B: {chip_b} ({chip_b.stat().st_size} bytes) SHA256 {sha256(chip_b)}')
    print(f'GAME.ZCARD: {len(zcard)} bytes; FAT16 data start LBA {DATA_START}; cluster size {CLUSTER_BYTES} bytes')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
