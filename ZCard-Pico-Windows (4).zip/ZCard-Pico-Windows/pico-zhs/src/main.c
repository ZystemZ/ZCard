#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "pico/stdlib.h"
#include "hardware/spi.h"
#include "bsp/board_api.h"
#include "tusb.h"

#define SPI_PORT spi0
#define PIN_SCK 18
#define PIN_MOSI 19
#define PIN_MISO 16
#define PIN_CS0 17
#define PIN_CS1 20
#define PIN_CART_ID 21
#define CART_ID_DUAL_LEVEL 1
#define CHIP_COUNT 2
#define ZHS_HEADER 20u
#define ZHS_CRC 4u
#define MAX_PAYLOAD 8192u
#define MAX_FRAME (ZHS_HEADER + MAX_PAYLOAD + ZHS_CRC)
#define ZHS_MAGIC 0x485Au
#define ZHS_VERSION 1u

enum { CMD_INFO = 1, CMD_READ = 2, CMD_VERIFY = 3, CMD_STATUS = 4 };
enum { ST_OK = 0, ST_INVALID_FRAME = 1, ST_UNSUPPORTED_VERSION = 2, ST_INVALID_COMMAND = 3,
       ST_INVALID_RANGE = 4, ST_READ_ONLY = 5, ST_NOT_PRESENT = 6, ST_INTEGRITY_ERROR = 7,
       ST_IO_ERROR = 8, ST_CART_TYPE_MISMATCH = 9 };

static const uint8_t cs_pins[CHIP_COUNT] = { PIN_CS0, PIN_CS1 };
static bool chip_present[CHIP_COUNT];
static uint32_t chip_capacity[CHIP_COUNT];
static bool cart_dual;
static bool cart_id_valid;
static uint8_t rx_frame[MAX_FRAME], tx_frame[MAX_FRAME];
static size_t rx_size;

static uint16_t le16(const uint8_t*p){return(uint16_t)p[0]|((uint16_t)p[1]<<8);} static uint32_t le32(const uint8_t*p){return(uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);} static uint64_t le64(const uint8_t*p){uint64_t v=0;for(int i=0;i<8;i++)v|=(uint64_t)p[i]<<(8*i);return v;}
static void put16(uint8_t*p,uint16_t v){p[0]=v;p[1]=(uint8_t)(v>>8);} static void put32(uint8_t*p,uint32_t v){for(int i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));} static void put64(uint8_t*p,uint64_t v){for(int i=0;i<8;i++)p[i]=(uint8_t)(v>>(8*i));}
static uint32_t crc32(const uint8_t*p,size_t n){uint32_t c=0xFFFFFFFFu;for(size_t i=0;i<n;i++){c^=p[i];for(int b=0;b<8;b++)c=(c&1u)?((c>>1)^0xEDB88320u):(c>>1);}return~c;}
static void chip_select(uint8_t chip,bool active){gpio_put(cs_pins[chip],active?0:1);}
static bool flash_jedec_id(uint8_t chip,uint8_t id[3]){uint8_t cmd=0x9F;chip_select(chip,true);spi_write_blocking(SPI_PORT,&cmd,1);spi_read_blocking(SPI_PORT,0,id,3);chip_select(chip,false);return id[0]!=0&&id[0]!=0xFF&&id[2]!=0&&id[2]!=0xFF;}
static uint32_t capacity_from_jedec(uint8_t exponent){return(exponent>=20&&exponent<=28)?(1u<<exponent):0;}
uint64_t flash_logical_capacity(void){uint64_t total=0;for(uint8_t i=0;i<CHIP_COUNT;i++)if(chip_present[i])total+=chip_capacity[i];return total;}
bool cart_configuration_ok(void){uint8_t count=0;for(uint8_t i=0;i<CHIP_COUNT;i++)if(chip_present[i])count++;return cart_id_valid && ((cart_dual&&count==2)||(!cart_dual&&count==1));}
static void detect_cart(void){cart_dual=gpio_get(PIN_CART_ID)==CART_ID_DUAL_LEVEL;cart_id_valid=true;for(uint8_t i=0;i<CHIP_COUNT;i++){uint8_t id[3]={0};chip_present[i]=flash_jedec_id(i,id);chip_capacity[i]=chip_present[i]?capacity_from_jedec(id[2]):0;if(!chip_capacity[i])chip_present[i]=false;}}
static bool map_logical(uint64_t address,uint8_t*chip,uint32_t*local){for(uint8_t i=0;i<CHIP_COUNT;i++){if(!chip_present[i])continue;if(address<chip_capacity[i]){*chip=i;*local=(uint32_t)address;return true;}address-=chip_capacity[i];}return false;}
bool flash_read_local(uint8_t chip,uint32_t address,uint8_t*out,size_t n){if(chip>=CHIP_COUNT||!chip_present[chip]||address>chip_capacity[chip]||n>chip_capacity[chip]-address)return false;uint8_t cmd[4]={0x03,(uint8_t)(address>>16),(uint8_t)(address>>8),(uint8_t)address};chip_select(chip,true);spi_write_blocking(SPI_PORT,cmd,4);spi_read_blocking(SPI_PORT,0,out,n);chip_select(chip,false);return true;}
bool flash_read_logical(uint64_t address,uint8_t*out,size_t n){if(!cart_configuration_ok()||address>flash_logical_capacity()||n>flash_logical_capacity()-address)return false;while(n){uint8_t chip;uint32_t local;if(!map_logical(address,&chip,&local))return false;size_t part=chip_capacity[chip]-local;if(part>n)part=n;if(!flash_read_local(chip,local,out,part))return false;address+=part;out+=part;n-=part;}return true;}
static size_t response(uint8_t cmd,uint16_t status,uint16_t req,uint64_t off,const uint8_t*payload,uint32_t n){if(n>MAX_PAYLOAD)n=0;put16(tx_frame,ZHS_MAGIC);tx_frame[2]=ZHS_VERSION;tx_frame[3]=cmd;put16(tx_frame+4,status);put16(tx_frame+6,req);put64(tx_frame+8,off);put32(tx_frame+16,n);if(n&&payload)memcpy(tx_frame+ZHS_HEADER,payload,n);put32(tx_frame+ZHS_HEADER+n,crc32(tx_frame,ZHS_HEADER+n));return ZHS_HEADER+n+ZHS_CRC;}
static size_t handle_frame(const uint8_t*f,size_t total){if(total<ZHS_HEADER+ZHS_CRC||le16(f)!=ZHS_MAGIC||f[2]!=ZHS_VERSION)return 0;uint8_t cmd=f[3];uint16_t req=le16(f+6);uint64_t off=le64(f+8);uint32_t n=le32(f+16);if(n>MAX_PAYLOAD||total!=ZHS_HEADER+n+ZHS_CRC||le32(f+ZHS_HEADER+n)!=crc32(f,ZHS_HEADER+n))return 0;if(!cart_configuration_ok())return response(cmd,ST_CART_TYPE_MISMATCH,req,off,0,0);if(cmd==CMD_INFO){static const char id[]="PICO-ZHS-CART-ID",fw[]="pico-zhs-0.3";uint8_t p[96];size_t k=0;put16(p+k,sizeof(id)-1);k+=2;memcpy(p+k,id,sizeof(id)-1);k+=sizeof(id)-1;put16(p+k,sizeof(fw)-1);k+=2;memcpy(p+k,fw,sizeof(fw)-1);k+=sizeof(fw)-1;put64(p+k,flash_logical_capacity());k+=8;put32(p+k,4096);k+=4;p[k++]=1;p[k++]=1;p[k++]=1;return response(cmd,ST_OK,req,off,p,k);}if(cmd==CMD_STATUS){uint8_t p[4]={1,1,1,1};return response(cmd,ST_OK,req,off,p,4);}if(cmd==CMD_VERIFY)return response(cmd,ST_OK,req,off,0,0);if(cmd==CMD_READ){if(off>flash_logical_capacity()||n>flash_logical_capacity()-off)return response(cmd,ST_INVALID_RANGE,req,off,0,0);if(!flash_read_logical(off,tx_frame+ZHS_HEADER,n))return response(cmd,ST_IO_ERROR,req,off,0,0);return response(cmd,ST_OK,req,off,tx_frame+ZHS_HEADER,n);}return response(cmd,ST_INVALID_COMMAND,req,off,0,0);}
static void poll_zhs(void){while(tud_cdc_available()){uint8_t b;tud_cdc_read(&b,1);if(rx_size<sizeof(rx_frame))rx_frame[rx_size++]=b;else rx_size=0;if(rx_size>=ZHS_HEADER){if(le16(rx_frame)!=ZHS_MAGIC){memmove(rx_frame,rx_frame+1,--rx_size);continue;}uint32_t n=le32(rx_frame+16);if(n>MAX_PAYLOAD){rx_size=0;continue;}size_t frame_size=ZHS_HEADER+n+ZHS_CRC;if(rx_size==frame_size){size_t out=handle_frame(rx_frame,rx_size);if(out){while(!tud_cdc_write_available())tud_task();tud_cdc_write(tx_frame,out);tud_cdc_write_flush();}rx_size=0;}}}}
int main(void){board_init();spi_init(SPI_PORT,1000*1000);gpio_set_function(PIN_SCK,GPIO_FUNC_SPI);gpio_set_function(PIN_MOSI,GPIO_FUNC_SPI);gpio_set_function(PIN_MISO,GPIO_FUNC_SPI);for(uint8_t i=0;i<CHIP_COUNT;i++){gpio_init(cs_pins[i]);gpio_set_dir(cs_pins[i],GPIO_OUT);gpio_put(cs_pins[i],1);}gpio_init(PIN_CART_ID);gpio_set_dir(PIN_CART_ID,GPIO_IN);gpio_pull_down(PIN_CART_ID);detect_cart();tusb_init();while(true){tud_task();poll_zhs();}}
