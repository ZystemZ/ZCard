#include "tusb.h"

#define USB_VID 0xCafe
#define USB_PID 0x4011
#define USB_BCD 0x0100

enum { ITF_NUM_CDC = 0, ITF_NUM_CDC_DATA, ITF_NUM_MSC, ITF_NUM_TOTAL };
#define CONFIG_TOTAL_LEN (TUD_CONFIG_DESC_LEN + TUD_CDC_DESC_LEN + TUD_MSC_DESC_LEN)
#define EPNUM_CDC_NOTIF 0x81
#define EPNUM_CDC_OUT   0x02
#define EPNUM_CDC_IN    0x82
#define EPNUM_MSC_OUT   0x03
#define EPNUM_MSC_IN    0x83

static const tusb_desc_device_t device_desc = {
  .bLength = TUSB_DESC_DEVICE_LEN, .bDescriptorType = TUSB_DESC_DEVICE,
  .bcdUSB = 0x0200, .bDeviceClass = 0, .bDeviceSubClass = 0, .bDeviceProtocol = 0,
  .bMaxPacketSize0 = CFG_TUD_ENDPOINT0_SIZE, .idVendor = USB_VID, .idProduct = USB_PID,
  .bcdDevice = USB_BCD, .iManufacturer = 1, .iProduct = 2, .iSerialNumber = 3,
  .bNumConfigurations = 1
};

uint8_t const *tud_descriptor_device_cb(void) { return (uint8_t const *)&device_desc; }

static const uint8_t config_desc[] = {
  TUD_CONFIG_DESCRIPTOR(1, ITF_NUM_TOTAL, 0, CONFIG_TOTAL_LEN,
                        TUSB_DESC_CONFIG_ATT_REMOTE_WAKEUP, 100),
  TUD_CDC_DESCRIPTOR(ITF_NUM_CDC, 4, EPNUM_CDC_NOTIF, 8,
                     EPNUM_CDC_OUT, EPNUM_CDC_IN, 64),
  TUD_MSC_DESCRIPTOR(ITF_NUM_MSC, 5, EPNUM_MSC_OUT, EPNUM_MSC_IN, 64)
};

uint8_t const *tud_descriptor_configuration_cb(uint8_t index) {
  (void)index; return config_desc;
}

static const char *strings[] = {
  (const char[]){0x09, 0x04}, "ZCard Project", "ZCARD Pico Drive", "PICO-MSC-0001", "ZHS CDC"
};
static uint16_t desc_str[32];
uint16_t const *tud_descriptor_string_cb(uint8_t index, uint16_t langid) {
  (void)langid; uint8_t count;
  if (index == 0) { desc_str[1] = 0x0409; count = 1; }
  else {
    if (index >= sizeof(strings) / sizeof(strings[0])) return NULL;
    const char *s = strings[index]; count = 0;
    while (s[count] && count < 31) { desc_str[1 + count] = s[count]; ++count; }
  }
  desc_str[0] = (uint16_t)((TUSB_DESC_STRING << 8) | (2 * count + 2));
  return desc_str;
}
