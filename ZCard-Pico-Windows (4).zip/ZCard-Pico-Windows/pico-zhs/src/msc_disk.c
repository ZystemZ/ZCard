/* MSC somente leitura para a mídia lógica concatenada. */
#include "tusb.h"
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

#define MSC_BLOCK_SIZE 512u
extern uint64_t flash_logical_capacity(void);
extern bool flash_read_logical(uint64_t address, uint8_t *out, size_t n);
extern bool cart_configuration_ok(void);

uint32_t tud_msc_inquiry2_cb(uint8_t lun, scsi_inquiry_resp_t *r, uint32_t bufsize) {
  (void)lun; (void)bufsize;
  memcpy(r->vendor_id, "ZCARD   ", 8);
  memcpy(r->product_id, "AUTO FLASH READ", 16);
  memcpy(r->product_rev, "0.2 ", 4);
  return sizeof(scsi_inquiry_resp_t);
}

bool tud_msc_test_unit_ready_cb(uint8_t lun) {
  (void)lun;
  return cart_configuration_ok() && flash_logical_capacity() != 0;
}

void tud_msc_capacity_cb(uint8_t lun, uint32_t *block_count, uint16_t *block_size) {
  (void)lun;
  *block_size = MSC_BLOCK_SIZE;
  *block_count = cart_configuration_ok() ? (uint32_t)(flash_logical_capacity() / MSC_BLOCK_SIZE) : 0;
}

bool tud_msc_is_writable_cb(uint8_t lun) { (void)lun; return false; }

int32_t tud_msc_read10_cb(uint8_t lun, uint32_t lba, uint32_t offset,
                          void *buffer, uint32_t bufsize) {
  (void)lun;
  uint64_t capacity = flash_logical_capacity();
  uint64_t address = (uint64_t)lba * MSC_BLOCK_SIZE + offset;
  if (offset > MSC_BLOCK_SIZE || bufsize > MSC_BLOCK_SIZE - offset || address > capacity || bufsize > capacity - address) return -1;
  return flash_read_logical(address, (uint8_t *)buffer, bufsize) ? (int32_t)bufsize : -1;
}

int32_t tud_msc_write10_cb(uint8_t lun, uint32_t lba, uint32_t offset,
                           uint8_t *buffer, uint32_t bufsize) {
  (void)lba; (void)offset; (void)buffer; (void)bufsize;
  tud_msc_set_sense(lun, SCSI_SENSE_DATA_PROTECT, 0x27, 0x00);
  return -1;
}

int32_t tud_msc_scsi_cb(uint8_t lun, uint8_t const scsi_cmd[16],
                       void *buffer, uint16_t bufsize) {
  (void)scsi_cmd; (void)buffer; (void)bufsize;
  tud_msc_set_sense(lun, SCSI_SENSE_ILLEGAL_REQUEST, 0x20, 0x00);
  return -1;
}
