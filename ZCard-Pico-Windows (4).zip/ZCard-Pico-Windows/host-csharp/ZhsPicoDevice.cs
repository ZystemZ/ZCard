using System;
using System.IO;
using System.IO.Ports;
using System.Text;

namespace ZCardHost;

public sealed record ZhsInfo(
    string DeviceId,
    string FirmwareVersion,
    ulong Capacity,
    uint BlockSize,
    bool Present,
    bool ReadOnly,
    bool MasterLocked);

public sealed class ZhsPicoDevice : IDisposable
{
    private const ushort Magic = 0x485A;
    private const byte Version = 1;
    private const int HeaderSize = 20;
    private const int CrcSize = 4;
    private const int MaxPayload = 8192;
    private readonly SerialPort port;
    private ushort nextRequestId = 1;

    public ZhsPicoDevice(string portName, int baudRate = 115200)
    {
        port = new SerialPort(portName, baudRate, Parity.None, 8, StopBits.One)
        {
            ReadTimeout = 2000,
            WriteTimeout = 2000,
            DtrEnable = false,
            RtsEnable = false
        };
    }

    public void Open() => port.Open();
    public void Close() { if (port.IsOpen) port.Close(); }
    public void Dispose() => Close();

    public ZhsInfo GetInfo()
    {
        var response = Exchange(1, 0, Array.Empty<byte>());
        using var ms = new MemoryStream(response.Payload);
        using var br = new BinaryReader(ms, Encoding.UTF8, leaveOpen: false);
        string ReadString() => Encoding.UTF8.GetString(br.ReadBytes(br.ReadUInt16()));
        return new ZhsInfo(ReadString(), ReadString(), br.ReadUInt64(), br.ReadUInt32(),
            br.ReadByte() != 0, br.ReadByte() != 0, br.ReadByte() != 0);
    }

    public byte[] Read(ulong offset, int count)
    {
        if (count < 0 || count > MaxPayload) throw new ArgumentOutOfRangeException(nameof(count));
        // ZHS V0.1 encodes the requested byte count as request payload length.
        var response = Exchange(2, offset, new byte[count]);
        if (response.Payload.Length != count)
            throw new IOException($"READ retornou {response.Payload.Length} bytes; esperado {count}.");
        return response.Payload;
    }

    public void Verify() => _ = Exchange(3, 0, Array.Empty<byte>());

    public (bool Open, bool Present, bool ReadOnly, bool MasterLocked) GetStatus()
    {
        var p = Exchange(4, 0, Array.Empty<byte>()).Payload;
        if (p.Length != 4) throw new IOException("GET_STATUS inválido.");
        return (p[0] != 0, p[1] != 0, p[2] != 0, p[3] != 0);
    }

    private Response Exchange(byte command, ulong offset, byte[] payload)
    {
        if (!port.IsOpen) throw new InvalidOperationException("Porta Pico não está aberta.");
        if (payload.Length > MaxPayload) throw new ArgumentOutOfRangeException(nameof(payload));
        ushort requestId = nextRequestId++;
        byte[] frame = new byte[HeaderSize + payload.Length + CrcSize];
        Put16(frame, 0, Magic); frame[2] = Version; frame[3] = command;
        Put16(frame, 4, 0); Put16(frame, 6, requestId); Put64(frame, 8, offset);
        Put32(frame, 16, (uint)payload.Length);
        Buffer.BlockCopy(payload, 0, frame, HeaderSize, payload.Length);
        Put32(frame, HeaderSize + payload.Length, Crc32(frame, 0, HeaderSize + payload.Length));
        port.Write(frame, 0, frame.Length);

        byte[] header = ReadExact(HeaderSize);
        if (Get16(header, 0) != Magic || header[2] != Version)
            throw new IOException("Cabeçalho ZHS inválido.");
        if (header[3] != command || Get16(header, 6) != requestId)
            throw new IOException("Resposta ZHS não corresponde à requisição.");
        uint responseLength = Get32(header, 16);
        if (responseLength > MaxPayload) throw new IOException("Resposta ZHS grande demais.");
        byte[] body = ReadExact((int)responseLength + CrcSize);
        byte[] all = new byte[HeaderSize + body.Length];
        Buffer.BlockCopy(header, 0, all, 0, HeaderSize);
        Buffer.BlockCopy(body, 0, all, HeaderSize, body.Length);
        uint expected = Get32(body, (int)responseLength);
        uint actual = Crc32(all, 0, HeaderSize + (int)responseLength);
        if (expected != actual) throw new IOException("CRC32 ZHS divergente.");
        ushort status = Get16(header, 4);
        if (status != 0) throw new IOException($"Pico respondeu status ZHS {status}.");
        var result = new byte[responseLength];
        Buffer.BlockCopy(body, 0, result, 0, result.Length);
        return new Response(status, result);
    }

    private byte[] ReadExact(int count)
    {
        byte[] result = new byte[count];
        int done = 0;
        while (done < count) done += port.Read(result, done, count - done);
        return result;
    }

    private readonly record struct Response(ushort Status, byte[] Payload);
    private static void Put16(byte[] b, int o, ushort v) { b[o] = (byte)v; b[o + 1] = (byte)(v >> 8); }
    private static void Put32(byte[] b, int o, uint v) { for (int i = 0; i < 4; i++) b[o + i] = (byte)(v >> (8 * i)); }
    private static void Put64(byte[] b, int o, ulong v) { for (int i = 0; i < 8; i++) b[o + i] = (byte)(v >> (8 * i)); }
    private static ushort Get16(byte[] b, int o) => (ushort)(b[o] | (b[o + 1] << 8));
    private static uint Get32(byte[] b, int o) => (uint)(b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24));
    private static ulong Get64(byte[] b, int o) { ulong v = 0; for (int i = 0; i < 8; i++) v |= (ulong)b[o + i] << (8 * i); return v; }

    private static uint Crc32(byte[] b, int offset, int length)
    {
        uint crc = 0xFFFFFFFFu;
        for (int i = offset; i < offset + length; i++)
        {
            crc ^= b[i];
            for (int bit = 0; bit < 8; bit++) crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xEDB88320u : crc >> 1;
        }
        return ~crc;
    }
}
