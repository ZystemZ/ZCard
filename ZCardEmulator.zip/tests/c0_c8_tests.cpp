#include "zconsole/emulator/emulator.hpp"
#include "zconsole/emulator/zexe.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>

static std::string readText(const std::filesystem::path& path) {
  std::ifstream input(path);
  return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}

int main() {
  for (int index = 0; index <= 7; ++index) {
    std::string profile = "c" + std::to_string(index) + "-";
    for (const auto& entry : std::filesystem::directory_iterator("examples")) {
      if (!entry.is_directory() || entry.path().filename().string().rfind(profile, 0) != 0) continue;
      zconsole::ZConsoleEmulator emulator;
      std::string error;
      assert(emulator.loadCard(entry.path(), &error));
      assert(emulator.boot(&error));
      assert(emulator.console().cpu().registers().halted);
      assert(emulator.console().cpu().registers().a == 42);
      std::cout << entry.path().generic_string() << " ZEXE OK\n";
    }
  }

  const auto legacyFile = std::filesystem::temp_directory_path() / "zconsole-c2-real.zcard";
  const auto zcfFile = std::filesystem::temp_directory_path() / "zconsole-c3-real.zcard";
  std::string buildReport, buildError;
  assert(zconsole::ZCardBuilder::build("examples/c2-legacy-zcard", legacyFile, &buildReport, &buildError));
  zconsole::ZConsoleEmulator legacy;
  assert(legacy.loadCard(legacyFile, &buildError));
  assert(legacy.boot(&buildError));
  assert(legacy.console().cpu().registers().halted);
  assert(zconsole::ZCardBuilder::buildZcf("examples/c3-zcf-base", zcfFile, &buildReport, &buildError));
  zconsole::ZConsoleEmulator zcf;
  assert(zcf.loadCard(zcfFile, &buildError));
  assert(zcf.boot(&buildError));
  assert(zcf.console().cpu().registers().halted);
  std::filesystem::remove(legacyFile);
  std::filesystem::remove(zcfFile);

  const std::filesystem::path c8 = "examples/c8-native-windows";
  assert(!std::filesystem::exists(c8 / "CODE" / "game.zexe"));
  const auto manifest = readText(c8 / "META" / "zgame.json");
  const auto runtime = readText(c8 / "META" / "native-runtime.json");
  assert(manifest.find("zgame-native-0.1") != std::string::npos);
  assert(manifest.find("windows-x64") != std::string::npos);
  assert(manifest.find("native/windows/MyGame.exe") != std::string::npos);
  assert(runtime.find("external-host-required") != std::string::npos);
  assert(runtime.find("external-host-required") != std::string::npos);
  zconsole::ZConsoleEmulator nativeCard;
  std::string nativeError;
  assert(nativeCard.loadCard(c8, &nativeError));
  assert(nativeCard.boot(&nativeError));
  assert(nativeCard.executionKind() == zconsole::CardExecutionKind::NativeWindows);
  std::cout << c8.generic_string() << " Windows native payload OK\n";

  zconsole::ZConsoleEmulator gba;
  std::string gbaError;
  assert(gba.loadCard("examples/rom-gba", &gbaError));
  assert(gba.boot(&gbaError));
  assert(gba.executionKind() == zconsole::CardExecutionKind::RomNoBackend);
  assert(gba.lastError().find("ROM reconhecida") != std::string::npos);
  assert(gba.romPlan().system == "gba");

  zconsole::ZConsoleEmulator iso;
  std::string isoError;
  assert(iso.loadCard("examples/disc-iso", &isoError));
  assert(iso.boot(&isoError));
  assert(iso.executionKind() == zconsole::CardExecutionKind::RomWindowsMount);
  assert(iso.romPlan().system == "pc");
  assert(iso.romPlan().mountMode == "windows");
  std::cout << "filesystem ROM/ISO routing OK\n";
  return 0;
}
