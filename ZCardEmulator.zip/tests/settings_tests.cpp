#include "zconsole/platform/settings.hpp"
#include <cassert>

int main() {
  const auto settings = zconsole::defaultHostSettings();
  assert(settings.cpuThreads == 0);
  assert(settings.memoryMiB >= 128);
  assert(settings.graphics.mode.width > 0);
  assert(settings.audio.sampleRate > 0);
  assert(settings.emulators.count("gba") == 1);
  assert(settings.emulators.count("ps2") == 1);
  assert(settings.emulators.count("pc") == 1);
  assert(settings.emulators.at("gba").arguments == "{rom}");
  return 0;
}
