#include "zconsole/emulator/zexe.hpp"
#include "zconsole/zcard/zcard_container.hpp"
#include "zconsole/zcard/zcf_hash.hpp"
#include <cassert>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

static std::uint64_t get64(const std::vector<std::uint8_t>& b,std::size_t p){std::uint64_t v=0;for(int i=0;i<8;++i)v|=static_cast<std::uint64_t>(b[p+i])<<(8*i);return v;}
static void put64(std::vector<std::uint8_t>& b,std::size_t p,std::uint64_t v){for(int i=0;i<8;++i)b[p+i]=static_cast<std::uint8_t>(v>>(8*i));}
static void refreshHeaderHash(std::vector<std::uint8_t>& b){std::fill(b.begin()+32,b.begin()+64,0);const auto h=zconsole::zcfSha256(std::vector<std::uint8_t>(b.begin(),b.begin()+64));std::copy(h.begin(),h.end(),b.begin()+32);}
static void save(const std::filesystem::path& p,const std::vector<std::uint8_t>& b){std::ofstream f(p,std::ios::binary|std::ios::trunc);f.write(reinterpret_cast<const char*>(b.data()),static_cast<std::streamsize>(b.size()));}
int main(){
  const auto source=std::filesystem::path("examples/complete-game.zgame");
  const auto base=std::filesystem::temp_directory_path()/"zcf-security-base.zcard";
  const auto overlap=std::filesystem::temp_directory_path()/"zcf-security-overlap.zcard";
  const auto capacity=std::filesystem::temp_directory_path()/"zcf-security-capacity.zcard";
  std::string report,error;assert(zconsole::ZCardBuilder::buildZcf(source,base,&report,&error));
  std::ifstream input(base,std::ios::binary);const std::vector<std::uint8_t> original((std::istreambuf_iterator<char>(input)),{});
  assert(original.size()>4096+48*5);
  auto badOverlap=original;const auto masterOffset=get64(badOverlap,64);put64(badOverlap,64+48,masterOffset);refreshHeaderHash(badOverlap);save(overlap,badOverlap);
  zconsole::ZCardContainer overlapCard(overlap);assert(!overlapCard.open(&error));assert(error.find("sobrepostas")!=std::string::npos);
  auto badCapacity=original;const auto declared=get64(badCapacity,16);put64(badCapacity,16,declared+4096);refreshHeaderHash(badCapacity);save(capacity,badCapacity);
  zconsole::ZCardContainer capacityCard(capacity);assert(!capacityCard.open(&error));assert(error.find("capacidade")!=std::string::npos);
  std::filesystem::remove(base);std::filesystem::remove(overlap);std::filesystem::remove(capacity);
  return 0;
}
