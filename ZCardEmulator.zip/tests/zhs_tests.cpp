#include "zconsole/zcard/zhs_device.hpp"
#include "zconsole/zcard/zhs_dispatcher.hpp"
#include <cassert>
#include <cstdint>
#include <string>
#include <vector>

int main() {
  using namespace zconsole;

  ZhsFrame request;
  request.command = ZhsCommand::Read;
  request.requestId = 7;
  request.offset = 4;
  request.payload = {0x10, 0x20, 0x30};
  const auto encoded = encodeZhsFrame(request);
  assert(!encoded.empty());

  ZhsFrame decoded;
  std::string error;
  assert(decodeZhsFrame(encoded, decoded, &error));
  assert(decoded.command == ZhsCommand::Read);
  assert(decoded.requestId == 7);
  assert(decoded.offset == 4);
  assert(decoded.payload == request.payload);

  auto corrupted = encoded;
  corrupted[corrupted.size() - 1] ^= 0x01;
  assert(!decodeZhsFrame(corrupted, decoded, &error));
  assert(error.find("CRC32") != std::string::npos);

  std::vector<std::uint8_t> image(4096, 0xA5);
  ZhsMemoryDevice device(image);
  assert(device.open(&error));
  const auto info = device.info();
  assert(info.present);
  assert(info.readOnly);
  assert(info.masterLocked);
  assert(info.capacity == 4096);

  std::vector<std::uint8_t> data(8, 0);
  assert(device.read(100, data, &error));
  for (const auto byte : data) assert(byte == 0xA5);
  assert(device.verify(&error));

  assert(!device.read(4090, data, &error));
  assert(error.find("fora dos limites") != std::string::npos);
  assert(!device.write(0, data, &error));
  assert(error.find("somente leitura") != std::string::npos);

  device.close();
  assert(!device.read(0, data, &error));
  assert(error.find("não está aberto") != std::string::npos);

  ZhsMemoryDevice dispatchDevice(std::vector<std::uint8_t>(64, 0x5A));
  ZhsDispatcher dispatcher(dispatchDevice);
  ZhsFrame infoRequest;
  infoRequest.command = ZhsCommand::GetInfo;
  infoRequest.requestId = 11;
  ZhsFrame infoResponse;
  assert(decodeZhsFrame(dispatcher.handle(encodeZhsFrame(infoRequest), &error), infoResponse, &error));
  assert(infoResponse.flags == static_cast<std::uint16_t>(ZhsStatus::Ok));
  assert(infoResponse.requestId == 11);
  assert(infoResponse.payload.size() > 4);

  ZhsFrame readRequest;
  readRequest.command = ZhsCommand::Read;
  readRequest.requestId = 12;
  readRequest.offset = 4;
  readRequest.payload.assign(8, 0);
  ZhsFrame readResponse;
  assert(decodeZhsFrame(dispatcher.handle(encodeZhsFrame(readRequest), &error), readResponse, &error));
  assert(readResponse.flags == static_cast<std::uint16_t>(ZhsStatus::Ok));
  assert(readResponse.payload == std::vector<std::uint8_t>(8, 0x5A));

  ZhsFrame verifyRequest;
  verifyRequest.command = ZhsCommand::Verify;
  ZhsFrame verifyResponse;
  assert(decodeZhsFrame(dispatcher.handle(encodeZhsFrame(verifyRequest), &error), verifyResponse, &error));
  assert(verifyResponse.flags == static_cast<std::uint16_t>(ZhsStatus::Ok));

  ZhsFrame statusRequest;
  statusRequest.command = ZhsCommand::GetStatus;
  ZhsFrame statusResponse;
  assert(decodeZhsFrame(dispatcher.handle(encodeZhsFrame(statusRequest), &error), statusResponse, &error));
  assert(statusResponse.flags == static_cast<std::uint16_t>(ZhsStatus::Ok));
  assert(statusResponse.payload.size() == 4);
  assert(statusResponse.payload[0] == 1 && statusResponse.payload[1] == 1);

  ZhsFrame invalidRequest;
  invalidRequest.command = static_cast<ZhsCommand>(0xFF);
  ZhsFrame invalidResponse;
  assert(decodeZhsFrame(dispatcher.handle(encodeZhsFrame(invalidRequest), &error), invalidResponse, &error));
  assert(invalidResponse.flags == static_cast<std::uint16_t>(ZhsStatus::InvalidCommand));
  return 0;
}
