#include "zconsole/runtime/rom_runtime.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <string>

int main() {
  const auto root = std::filesystem::temp_directory_path() / "zcard_rom_runtime_test";
  std::filesystem::remove_all(root);
  std::filesystem::create_directories(root / "META");
  std::filesystem::create_directories(root / "roms");
  std::ofstream(root / "roms" / "game.gba", std::ios::binary) << "GBA";
  std::ofstream(root / "META" / "rom-runtime.json")
      << "{\"format\":\"zcard-rom-runtime-0.1\",\"rom\":\"roms/game.gba\","
         "\"system\":\"gba\",\"internal\":{\"enabled\":true,\"core\":\"gba\"},"
         "\"external\":{\"enabled\":false,\"command\":\"vgba.exe\"}}\n";

  zconsole::RomLaunchPlan plan;
  std::string error;
  assert(zconsole::resolveRomRuntime(root, "roms/game.gba", plan, &error));
  assert(plan.system == "gba");
  assert(plan.backend == zconsole::RomBackendKind::InternalCore);
  assert(plan.message.find("gba") != std::string::npos);

  std::ofstream(root / "META" / "rom-runtime.json")
      << "{\"system\":\"gba\",\"internal\":{\"enabled\":false},"
         "\"external\":{\"enabled\":true,\"command\":\"vgba.exe\"}}\n";
  assert(zconsole::resolveRomRuntime(root, "roms/game.gba", plan, &error));
  assert(plan.backend == zconsole::RomBackendKind::ExternalProcess);
  assert(plan.command == "vgba.exe");
  assert(plan.arguments.size() == 1);
  zconsole::RomProcessInvocation invocation;
  assert(zconsole::prepareExternalRomInvocation(plan, invocation, &error));
  assert(invocation.executable == "vgba.exe");
  assert(invocation.arguments.size() == 1);
  assert(invocation.arguments.front().find("game.gba") != std::string::npos);

  assert(!zconsole::resolveRomRuntime(root, "../secret.gba", plan, &error));
  std::filesystem::remove_all(root);

  assert(zconsole::resolveRomRuntime("examples/rom-gba", "roms/demo.gba", plan, &error));
  assert(plan.system == "gba");
  assert(plan.backend == zconsole::RomBackendKind::InternalCore);
  assert(!std::filesystem::exists("examples/rom-gba/CODE/game.zexe"));
  assert(!std::filesystem::exists("examples/disc-iso/CODE/game.zexe"));
  assert(zconsole::resolveRomRuntime("examples/disc-iso", "media/demo.iso", plan, &error));
  assert(plan.system == "pc");
  assert(plan.backend == zconsole::RomBackendKind::WindowsMount);
  assert(plan.mountMode == "windows");
  return 0;
}
