#include "zconsole/emulator/zexe.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

int main() {
  const auto root = std::filesystem::temp_directory_path() / "zcard_zuf_test";
  const auto output = std::filesystem::temp_directory_path() / "zcard_zuf_test.zuf";
  std::filesystem::remove_all(root);
  std::filesystem::create_directories(root / "UPDATE");
  std::ofstream(root / "UPDATE" / "patch.bin", std::ios::binary) << "PATCH";
  std::ofstream(root / "update.json") << "{\"version\":\"1.1\"}\n";
  std::string report, error;
  assert(zconsole::ZCardBuilder::buildZuf(root, output, &report, &error));
  std::ifstream input(output, std::ios::binary);
  const std::vector<std::uint8_t> bytes((std::istreambuf_iterator<char>(input)), {});
  assert(bytes.size() > 32);
  assert(bytes[0] == 'Z' && bytes[1] == 'U' && bytes[2] == 'F' && bytes[3] == '0');
  assert(report.find("arquivos=2") != std::string::npos);
  std::filesystem::remove_all(root);
  std::filesystem::remove(output);
  return 0;
}
