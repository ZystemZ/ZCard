#include "zconsole/asset_runtime.hpp"
#include "zconsole/zcard/virtual_card.hpp"
#include "zconsole/zcard/zcard_archive.hpp"
#include "zconsole/emulator/console.hpp"
#include "zconsole/emulator/emulator.hpp"
#include "zconsole/emulator/hardware.hpp"
#include "zconsole/platform/services.hpp"
#include "zconsole/emulator/zexe.hpp"
#include <cassert>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>

int main(){
  std::string error;
  const auto storageRoot=std::filesystem::temp_directory_path()/"zconsole-storage-test";std::filesystem::remove_all(storageRoot);zconsole::ZStorage storage(storageRoot,1024);const std::vector<std::uint8_t> configData={'o','k'};assert(storage.write(zconsole::ZStorageScope::SaveReadWrite,"profile/config.bin",configData,&error));assert(storage.read(zconsole::ZStorageScope::SaveReadWrite,"profile/config.bin",&error)==configData);assert(!storage.write(zconsole::ZStorageScope::InstallReadOnly,"blocked.bin",configData,&error));assert(!storage.write(zconsole::ZStorageScope::SaveReadWrite,"../escape.bin",configData,&error));std::filesystem::remove_all(storageRoot);
  zconsole::ZConsoleGraphics graphics(32,18); graphics.clear({0,0,0,255}); graphics.fillRect(2,3,5,4,{255,0,0,255}); assert(graphics.framebuffer()[((3*32+2)*4)]==255); zconsole::ZConsoleInput input; input.push({zconsole::ZInputKey::Action,true}); assert(input.isDown(zconsole::ZInputKey::Action)); zconsole::ZInputEvent event{}; assert(input.poll(event)&&event.pressed); zconsole::ZConsoleAudio audio; audio.playTone(440,100); assert(audio.tones().size()==1&&audio.tones()[0].frequency==440);
  zconsole::ZConsole console(1024);
  const auto zexe=zconsole::ZExecutableLoader::buildMinimal(0x100);
  zconsole::ZExeHeader header;
  assert(zconsole::ZExecutableLoader::inspect(zexe,header,&error));
  assert(header.entryPoint==0 && header.codeSize==16);
  assert(zconsole::ZExecutableLoader::load(zexe,console,&header,&error));
  assert(console.cpu().run(8,&error)==4);
  std::uint32_t stored=0; assert(console.memory().read(0x100,&stored,4) && stored==47);
  assert(console.cpu().registers().a==47 && console.cpu().registers().halted && console.cpu().instructions()==4);
  auto bad=zexe; bad.back()^=1; assert(!zconsole::ZExecutableLoader::inspect(bad,header,&error));

  zconsole::ZConsole control(128);
  const std::uint8_t controlProgram[] = {0x01,7,0,0,0, 0x05,7,0,0,0, 0x06,20,0,0,0, 0x01,1,0,0,0, 0x07,0x08,0xff};
  assert(control.memory().write(0,controlProgram,sizeof(controlProgram))); control.cpu().reset(); control.cpu().addBreakpoint(5);
  assert(control.cpu().run(20,&error)==1 && control.cpu().breakpointHit() && control.cpu().paused() && control.cpu().registers().pc==5);
  control.cpu().removeBreakpoint(5); control.cpu().resume(); assert(control.cpu().run(20,&error)==5); assert(control.cpu().registers().a==7 && control.cpu().registers().halted);

  zconsole::AssetRuntime runtime(std::filesystem::path("examples/demo.zgf"), 1024 * 1024);
  assert(runtime.loadManifest(&error));
  zconsole::AssetRuntime typedRuntime("examples/complete-game.zgame",1024*1024);
  assert(typedRuntime.loadManifest(&error));
  const auto typedAssets=typedRuntime.assetList();
  assert(typedAssets.size()==2 && typedAssets.front().type=="text");
  const auto scene = runtime.assetsForScene("menu");
  assert(scene.size() == 1 && scene.front() == "assets/menu.bin");
  assert(runtime.requestPrefetch(scene, 10, 100.0, &error));
  const auto loaded = runtime.processPrefetch(10, 2, 1024.0, true, 10.0);
  assert(loaded.size() == 2);
  assert(runtime.status("assets/menu.bin")->state == zconsole::RequestState::Ready);
  const auto first = runtime.read("assets/menu.bin");
  const auto second = runtime.read("assets/menu.bin");
  assert(!first.empty() && first == second && runtime.metrics().hits >= 1);
  zconsole::VirtualZCard directoryCard(std::filesystem::path("examples/demo.zgf"));
  assert(directoryCard.mount(&error));
  auto assetStream=directoryCard.openStream("assets/level.bin",&error);
  assert(assetStream && assetStream->size()>0);
  zconsole::ZCardArchive archive(std::filesystem::path("examples/demo.zcard"));
  assert(archive.open(&error));
  const auto archiveEntries=archive.entries();
  assert(std::find(archiveEntries.begin(),archiveEntries.end(),"META/zgame.json")!=archiveEntries.end());
  assert(!archive.openStream("../escape",&error));

  const auto root=std::filesystem::temp_directory_path()/"zconsole_mvp_card"; std::filesystem::remove_all(root); std::filesystem::create_directories(root/"META"); std::filesystem::create_directories(root/"CODE");
  std::ofstream(root/"META/zgame.json") << "{\"format\":\"zgame-0.1\",\"title\":\"MVP\",\"platform\":\"zconsole-v1\",\"executable\":\"CODE/game.zexe\",\"entrypoint\":0,\"boot_scene\":\"menu\",\"memory_required\":260}";
  std::ofstream(root/"META/assets.zgf") << "ZGF-0.1\n";
  std::ofstream exe(root/"CODE/game.zexe",std::ios::binary); exe.write(reinterpret_cast<const char*>(zexe.data()),zexe.size()); exe.close();
  std::string report; const auto deterministicCard=root.parent_path()/"zconsole_mvp.zcard"; assert(zconsole::ZCardBuilder::build(root,deterministicCard,&report,&error)); assert(report.find("entradas=")!=std::string::npos && report.find("fnv1a32=")!=std::string::npos && report.find("verificacao=ok")!=std::string::npos); std::ifstream firstBuild(deterministicCard,std::ios::binary); const std::vector<char> firstBytes((std::istreambuf_iterator<char>(firstBuild)),{}); assert(zconsole::ZCardBuilder::build(root,deterministicCard,&report,&error)); std::ifstream secondBuild(deterministicCard,std::ios::binary); const std::vector<char> secondBytes((std::istreambuf_iterator<char>(secondBuild)),{}); assert(firstBytes==secondBytes);
  const auto generatedRoot=std::filesystem::temp_directory_path()/"zconsole_generated_assets"; std::filesystem::remove_all(generatedRoot); std::filesystem::create_directories(generatedRoot/"META"); std::filesystem::create_directories(generatedRoot/"CODE"); std::filesystem::create_directories(generatedRoot/"assets"); std::ofstream(generatedRoot/"META/zgame.json")<<"{\"format\":\"zgame-0.1\",\"title\":\"Generated\",\"platform\":\"zconsole-v1\",\"executable\":\"CODE/game.zexe\",\"entrypoint\":0,\"boot_scene\":\"menu\",\"memory_required\":260}"; std::ofstream generatedAsset(generatedRoot/"assets/sample.ztex",std::ios::binary);generatedAsset<<"texture";generatedAsset.close();std::ofstream generatedExe(generatedRoot/"CODE/game.zexe",std::ios::binary);generatedExe.write(reinterpret_cast<const char*>(zexe.data()),zexe.size());generatedExe.close(); const auto generatedCard=generatedRoot.parent_path()/"zconsole_generated_assets.zcard"; assert(zconsole::ZCardBuilder::build(generatedRoot,generatedCard,&report,&error)); zconsole::ZCardArchive generatedArchive(generatedCard);assert(generatedArchive.open(&error));auto generatedManifest=generatedArchive.openStream("META/assets.zgf",&error);assert(generatedManifest);std::string generatedText(static_cast<std::size_t>(generatedManifest->size()),'\0');assert(generatedManifest->read(generatedText.data(),generatedText.size())==generatedText.size());assert(generatedText.find("asset|assets/sample.ztex|streaming|100|-|-|ztex")!=std::string::npos);std::filesystem::remove_all(generatedRoot);std::filesystem::remove(generatedCard);
  zconsole::ZConsoleEmulator emulator; assert(emulator.loadCard(root.parent_path()/"zconsole_mvp.zcard",&error)); assert(emulator.boot(&error)); assert(emulator.title()=="MVP" && emulator.bootScene()=="menu"); assert(emulator.console().cpu().instructions()==4 && emulator.console().cpu().registers().halted && emulator.console().cpu().registers().a==47);
  assert(emulator.reset(&error)); assert(emulator.pause(&error)); assert(emulator.runInstructions(1,&error)); assert(emulator.console().cpu().instructions()==0); assert(emulator.resume(&error)); assert(emulator.runOneInstruction(&error)); assert(emulator.console().cpu().instructions()==1);
  zconsole::ZConsoleEmulator completeGame;
  assert(completeGame.loadCard("examples/complete-game.zgame",&error));
  assert(completeGame.boot(&error));
  assert(completeGame.title()=="ZConsole Treasure Run" && completeGame.bootScene()=="menu");
  std::uint32_t bootMarker=0, treasureMarker=0;
  assert(completeGame.console().memory().read(0x200,&bootMarker,4) && bootMarker==1);
  assert(completeGame.console().memory().read(0x208,&treasureMarker,4) && treasureMarker==42);
  assert(completeGame.console().cpu().registers().halted && completeGame.console().cpu().registers().a==42);
  const auto completeOutput=std::filesystem::temp_directory_path()/"complete-game-built.zcard";
  assert(zconsole::ZCardBuilder::build("examples/complete-game.zgame",completeOutput,&report,&error));
  zconsole::ZConsoleEmulator completeArchive;
  assert(completeArchive.loadCard(completeOutput,&error) && completeArchive.boot(&error));
  assert(completeArchive.console().memory().read(0x208,&treasureMarker,4) && treasureMarker==42);
  std::filesystem::remove(completeOutput);
  const auto gbaOutput=std::filesystem::temp_directory_path()/"rom-gba-built.zcard"; assert(zconsole::ZCardBuilder::build("examples/rom-gba",gbaOutput,&report,&error)); assert(report.find("ROM runtime")!=std::string::npos); zconsole::ZCardArchive gbaArchive(gbaOutput); assert(gbaArchive.open(&error)); const auto gbaEntries=gbaArchive.entries(); assert(std::find(gbaEntries.begin(),gbaEntries.end(),"META/rom-runtime.json")!=gbaEntries.end()); zconsole::ZConsoleEmulator gbaCard; assert(gbaCard.loadCard(gbaOutput,&error)); assert(gbaCard.boot(&error)); assert(gbaCard.executionKind()==zconsole::CardExecutionKind::RomNoBackend); assert(gbaCard.lastError().find("ROM reconhecida")!=std::string::npos); std::filesystem::remove(gbaOutput);
  const auto zcfOutput=std::filesystem::temp_directory_path()/"complete-game.zcf.zcard"; assert(zconsole::ZCardBuilder::buildZcf("examples/complete-game.zgame",zcfOutput,&report,&error)); assert(report.find("container=ZCF0")!=std::string::npos); zconsole::ZConsoleEmulator zcfGame; assert(zcfGame.loadCard(zcfOutput,&error) && zcfGame.boot(&error)); assert(zcfGame.console().memory().read(0x208,&treasureMarker,4) && treasureMarker==42); zconsole::VirtualZCard writableCard(zcfOutput);assert(writableCard.mount(&error));const std::vector<std::uint8_t> saveData={'S','A','V','E'};assert(!writableCard.writeStream(zconsole::ZcfRegionKind::Master,"CODE/game.zexe",saveData,&error));assert(error.find("MASTER")!=std::string::npos);assert(writableCard.writeStream(zconsole::ZcfRegionKind::Save,"SAVE/state.bin",saveData,&error));auto saveStream=writableCard.openStream("SAVE",&error);assert(saveStream&&saveStream->size()==saveData.size());
  const auto corrupted=zcfOutput.parent_path()/"complete-game-corrupted.zcard"; std::filesystem::copy_file(zcfOutput,corrupted,std::filesystem::copy_options::overwrite_existing); std::fstream corruptFile(corrupted,std::ios::in|std::ios::out|std::ios::binary); corruptFile.seekg(4096+10); char changed=0;corruptFile.read(&changed,1);changed=static_cast<char>(changed^0x5a);corruptFile.seekp(4096+10);corruptFile.write(&changed,1);corruptFile.close(); zconsole::ZConsoleEmulator corruptedGame; assert(!corruptedGame.loadCard(corrupted,&error)); assert(error.find("hash")!=std::string::npos||error.find("MASTER")!=std::string::npos); std::filesystem::remove(zcfOutput);std::filesystem::remove(corrupted);
  const auto native32Output=std::filesystem::temp_directory_path()/"windows-x86-32-built.zcard"; assert(zconsole::ZCardBuilder::build("examples/windows-x86-32",native32Output,&report,&error)); zconsole::ZConsoleEmulator native32; assert(native32.loadCard(native32Output,&error) && native32.boot(&error)); assert(native32.guestPolicy().architecture=="x86" && native32.guestPolicy().binaryFormat=="PE32" && native32.guestPolicy().visibleProcessors==1 && native32.guestPolicy().threadPolicy=="serialized_guest_parallel_host"); std::filesystem::remove(native32Output);
  std::cout << "ZCONSOLE MVP-1 OK | ZEXE -> ZCARD -> ROM -> native Windows policy\n";
  std::filesystem::remove_all(root); std::filesystem::remove(root.parent_path()/"zconsole_mvp.zcard"); return 0;
}
