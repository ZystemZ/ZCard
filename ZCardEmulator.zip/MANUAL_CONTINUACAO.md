# Manual de Continuação do Projeto ZConsole/ZCARD

## 1. Conteúdo do pacote

Este pacote contém o código atual do emulador, a solução Visual Studio, a GUI Win32, o runtime de assets, o reader `.zcard`, a CPU virtual, os testes, exemplos, checklist técnico e o prompt mestre de implementação.

A solução principal é `ZCardEmulator.sln`. Ela contém um único projeto C++ Win32 para evitar o problema de projetos descarregados observado anteriormente.

## 2. Requisitos Windows

Instale pelo Visual Studio Installer o workload **Desktop development with C++**. Inclua o compilador MSVC v143, o Windows 10 ou Windows 11 SDK, as ferramentas C++ MSBuild e as ferramentas CMake para Windows. O projeto usa C++17 e arquitetura x64.

## 3. Abrir e executar

Extraia o ZIP preservando a pasta inteira. Abra diretamente `ZCardEmulator.sln`. Não abra apenas a pasta e não abra um projeto antigo de outro pacote.

Selecione `Debug` e `x64`. Use `Compilar > Recompilar Solução`. Pressione `F5`. O projeto de inicialização é `ZCardEmulator` e gera uma aplicação Win32.

Se o Gerenciador de Soluções não aparecer, use `Exibir > Gerenciador de Soluções` ou `Ctrl+Alt+L`.

## 4. Teste manual da GUI

A GUI apresenta um dashboard com status do emulador, CPU, program counter, assets, cache, prefetch e log de eventos.

Use `Montar diretório` e selecione `examples\\demo.zgf`. Depois use `Prefetch boot` e `Processar fila`. O painel de eventos deve registrar o boot e o processamento da fila.

Use `Abrir .zcard` e selecione `examples\\demo.zcard` para testar o reader ZIP. O formato atual aceita entradas armazenadas; DEFLATE depende de ZLIB habilitado no CMake.

## 5. Estrutura técnica atual

```text
include/zconsole/emulator       CPU, memória, timing e ciclo do console
include/zconsole/runtime        ZAssetStream
include/zconsole/zcard          VirtualZCard e ZCardArchive
include/zconsole/platform       abstração de host
src/asset_runtime.cpp           cache, prefetch, cenas e deadlines
src/zcard/zcard_archive.cpp     reader do arquivo .zcard
src/emulator/cpu.cpp            CPU virtual inicial
src/emulator/console.cpp        memória e timing
src/emulator/emulator.cpp       ciclo de vida do emulador
gui/win32_gui.cpp               dashboard Win32
tests/runtime_tests.cpp         testes nativos
examples/demo.zgf               cartão em diretório
examples/demo.zcard             cartão em arquivo
```

## 6. Ordem de desenvolvimento

A ordem recomendada é implementar primeiro o formato ZEXE e seu loader. Em seguida, implementar o Builder que gera `.zcard` a partir de um diretório. Depois conectar o executável ao dashboard e à CPU. Somente depois disso deve começar a adaptação de um jogo C++ grande ou a exportação Unity.

## 7. Overgrowth

O Overgrowth deve ser baixado separadamente do repositório oficial. Primeiro reproduza a compilação original conforme `COMPILING.md`. Depois faça uma auditoria das APIs de janela, input, áudio, filesystem, threads, OpenGL, shaders e carregamento de dados.

O repositório fornece o código, mas não os assets comerciais e níveis do jogo. Não inclua esses dados no pacote ZCARD nem redistribua dados comerciais sem autorização.

O primeiro alvo de portabilidade deve ser uma amostra reduzida do engine, e não o jogo completo.

## 8. Unity

O suporte Unity deverá ser criado como um pacote `com.zcard.zconsole` com validação de projeto, configurações de plataforma, exportação de assets, manifesto, backend de build e geração de ZEXE ou bytecode compatível.

Um executável Windows comum produzido pelo Unity não deve ser simplesmente renomeado para `.zexe`. O jogo de teste precisa ser compilado ou convertido para o formato virtual suportado pelo ZConsole.

## 9. Diagnóstico

Se a solução aparecer descarregada, execute `check_vs.ps1` em um PowerShell. Se `Microsoft.Cpp.Default.props` ou `cl.exe` não forem encontrados, corrija a instalação do Visual Studio.

Se a compilação terminar e nada aparecer, verifique se o projeto `ZCardEmulator` está definido como projeto de inicialização e se está selecionado `Debug|x64`.

## 10. Critério do primeiro marco

O marco `ZConsole MVP-1` estará concluído quando um programa mínimo próprio for compilado para ZEXE, empacotado em ZCARD, montado pela GUI, identificado pelo manifesto, carregado na memória virtual e executado com PC, registradores e contagem de instruções visíveis.

### Implementação MVP-1 entregue

O pacote agora inclui `include/zconsole/emulator/zexe.hpp` e `src/emulator/zexe.cpp`. O formato `ZEXE` versão 1 usa header fixo de 40 bytes, arquitetura 1 (`ZCPU-32`), segmento CODE flat, entry point 0, requisito de memória e checksum. `ZCardBuilder` gera cartões ZIP stored contendo o diretório inteiro, enquanto `ZConsoleEmulator::boot` lê `META/zgame.json`, localiza `CODE/game.zexe`, valida, carrega e executa o programa mínimo. O dashboard mostra título, cena, PC, registradores, entry point e instruções.

O teste nativo reproduzível é `zconsole_tests`; ele verifica também o runtime de assets existente e o fluxo `ZEXE -> ZCARD -> mount -> load -> run`. O ambiente desta entrega não possui Visual Studio, MSVC, CMake ou g++; portanto a compilação oficial deve ser realizada no Windows conforme as etapas acima.
