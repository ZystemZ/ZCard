# ZCARD Container Format 0.1 (ZCF)

## Status

Esta especificação define o próximo formato do `.zcard`. A implementação atual do projeto continua aceitando o formato legado, que é um ZIP direto. O magic `ZCF0` será usado para distinguir o novo container sem quebrar cartões MVP-1.

## Objetivo

O ZCF adiciona um cabeçalho estável e regiões lógicas ao cartão. O conteúdo de cada região é um ZIP interno alinhado em blocos, permitindo separar dados imutáveis do jogo, atualizações, DLC, saves e dados do usuário.

```text
+----------------------+ offset 0
| ZCF fixed header     | 64 bytes
+----------------------+
| region table         | N * 48 bytes
+----------------------+
| alignment padding    |
+----------------------+
| MASTER region        | ZIP interno
+----------------------+
| UPDATE region        | ZIP interno ou vazio
+----------------------+
| DLC region           | ZIP interno ou vazio
+----------------------+
| SAVE region          | ZIP interno ou vazio
+----------------------+
| USER region          | ZIP interno ou vazio
+----------------------+
```

## Cabeçalho fixo de 64 bytes

Todos os valores inteiros usam little-endian.

| Offset | Tamanho | Campo | Descrição |
|---:|---:|---|---|
| 0 | 4 | `magic` | ASCII `ZCF0` |
| 4 | 2 | `version` | `1` para ZCF 0.1 |
| 6 | 2 | `header_size` | `64` |
| 8 | 4 | `flags` | Deve ser zero em 0.1 |
| 12 | 4 | `block_size` | `4096` |
| 16 | 8 | `capacity` | Capacidade lógica total em bytes |
| 24 | 4 | `region_count` | Quantidade de entradas na tabela |
| 28 | 4 | `region_table_offset` | Normalmente `64` |
| 32 | 32 | `header_hash` | SHA-256 dos bytes 0–31, com este campo zerado |

Os oito bytes finais do cabeçalho são reservados e devem ser zero. O Builder calcula SHA-256 do header com o campo de hash zerado e armazena os 32 bytes em `header_hash`. Um leitor deve rejeitar versão desconhecida, tamanho de cabeçalho menor que 64, block size diferente de 4096, hash divergente ou tabela fora da capacidade do arquivo.

## Entrada de região de 48 bytes

| Offset | Tamanho | Campo | Descrição |
|---:|---:|---|---|
| 0 | 8 | `offset` | Offset absoluto, alinhado a `block_size` |
| 8 | 8 | `size` | Tamanho ocupado da região |
| 16 | 8 | `capacity` | Capacidade reservada da região |
| 24 | 4 | `kind` | `MASTER=1`, `UPDATE=2`, `DLC=3`, `SAVE=4`, `USER=5` |
| 28 | 4 | `flags` | `READ_ONLY=1`, `TRANSACTIONAL=2` |
| 32 | 16 | `content_hash_prefix` | Primeiros 16 bytes do SHA-256 do conteúdo |

A região `MASTER` deve existir exatamente uma vez. O manifesto `META/zgame.json`, `META/assets.zgf` e `CODE/game.zexe` pertencem à MASTER. A MASTER é somente leitura depois da criação do cartão. O Builder ZCF atual também reserva regiões `UPDATE`, `DLC`, `SAVE` e `USER`, cada uma com capacidade inicial de 64 KiB.

## Segurança e escrita

A API deve verificar que:

- nenhum offset ou tamanho ultrapassa a capacidade declarada;
- regiões não se sobrepõem;
- offsets são alinhados;
- MASTER não recebe escrita após o lock;
- UPDATE, DLC, SAVE e USER só aceitam escrita dentro da capacidade reservada;
- escrita transacional usa temporário, flush e commit do índice antes de substituir a região ativa.

A API `VirtualZCard::writeStream` aceita uma região gravável e um payload. No incremento atual o payload ocupa a região como um registro único; a escrita atualiza tamanho, hash da região e hash do header. A escrita na MASTER retorna `escrita proibida na região MASTER`.

Falhas devem ser reportadas em português: `cartão corrompido`, `região MASTER inválida`, `assinatura ausente`, `escrita proibida na região MASTER` ou `região fora dos limites`.

## Compatibilidade

O leitor deve examinar os primeiros quatro bytes:

- `ZCF0`: usar `ZCardContainer`;
- `PK\x03\x04` ou assinatura ZIP equivalente: usar `ZCardArchive` legado;
- qualquer outra assinatura: rejeitar com erro claro.

Um Builder com opção padrão legado continua produzindo ZIP MVP-1 até que a opção `--format zcf` seja habilitada e os testes ZCF estejam completos.

## Hashes

A especificação exige SHA-256 para o header e regiões. O Builder e o reader já calculam e verificam o SHA-256 do header e os primeiros 16 bytes do SHA-256 da MASTER. FNV-1a32 continua permitido no relatório humano do Builder, mas não substitui o hash de integridade do ZCF.

## Fora do escopo de 0.1

Assinatura digital, criptografia de conteúdo, compressão por região, journaling completo contra power-loss e sincronização com hardware ZHS ficam para versões posteriores. O MVP-2 deve primeiro garantir detecção, leitura, hash, proteção da MASTER e compatibilidade com ZIP legado.
