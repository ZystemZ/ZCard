# Roteiro de implementação do ZConsole e perfis ZCARD C0–C8

## Síntese

O ZConsole já possui um fluxo funcional de demonstração: um programa ZEXE autoral pode ser colocado em um diretório de jogo, empacotado como ZIP legado ou ZCF, montado pelo emulador e executado pela CPU virtual. O sistema ainda não executa binários Windows ou Linux arbitrários. Para isso, é necessário separar três objetivos diferentes: **executar ZEXE**, **empacotar arquivos de jogos nativos** e **portar ou encapsular um runtime nativo compatível**.

> Um `.zexe` não é um `.exe` do Windows renomeado. Ele é um executável para a ISA e ABI virtuais do ZConsole. Um `.exe` Windows só pode ser executado diretamente pelo Windows, por Wine/Proton, ou por uma camada de compatibilidade que ainda precisa ser implementada.

## Estado atual

| Área | Situação | Próxima ação |
|---|---|---|
| ZEXE mínimo | Funcional | Evoluir header para segmentos, relocação e símbolos |
| CPU virtual | Funcional para programas pequenos | Definir syscalls, interrupções, threads e ABI |
| ZCARD ZIP legado | Funcional | Manter compatibilidade e melhorar compressão |
| ZCF 0.1 | Funcional com MASTER, UPDATE, DLC, SAVE e USER | Adicionar índice, journaling, locks e commits robustos |
| Builder | Funcional por CLI | Validar/gerar manifesto, profiles e patches |
| AssetRuntime | Funcional em protótipo | Implementar streaming assíncrono, LRU e upload GPU |
| Memória virtual | Funcional em primeira versão | Adicionar mapa de memória, proteção e paginação |
| Framebuffer RGBA8 | Funcional para testes | Separar resolução lógica da resolução de apresentação |
| SDL2 | Backend opcional funcional | Completar ciclo de janela, input, áudio e gamepad |
| Vulkan | Instance, device, swapchain, render pass e clear frame | Pipeline, shaders, buffers, texturas e triângulo |
| Windows GUI | Protótipo funcional | Integrar inspector, frame loop, logs e configuração |
| DX12/DX11/OpenGL | Contratos e roadmap | Implementar backends nativos e smoke tests no Windows |
| Jogos Windows | Não executados pelo ZEXE | Empacotar somente ou criar ponte de compatibilidade |
| Linux/Bazzite/ZOS | Empacotamento possível | Criar runtime nativo Linux e política de sandbox |

## Ordem recomendada de implementação

### Etapa 1 — Fechar o MVP verificável

A primeira etapa deve estabilizar contratos. É necessário concluir syscalls mínimas, mapa de memória, códigos de erro, validação completa do ZEXE e execução por frame. O dashboard deve mostrar memória usada, PC, SP, estado da CPU, frame atual, eventos e motivo de parada.

### Etapa 2 — Fechar o ZCF como armazenamento confiável

O ZCF deve impedir sobreposição de regiões, validar capacidade total, manter hashes de todas as regiões, suportar escrita transacional com flush, recuperar `.tmp` após interrupção e manter um índice de arquivos por região. UPDATE e DLC devem aceitar pacotes versionados. SAVE e USER devem ter quota e política de limpeza.

### Etapa 3 — Criar o renderer real

A abstração deve separar `ZRenderDevice`, `ZBuffer`, `ZTexture`, `ZPipeline`, `ZCommandList` e `ZSwapchain`. O backend Vulkan deve desenhar um triângulo, depois uma textura, depois uma cena 3D com depth buffer. A resolução lógica deve ser independente da resolução da janela. DX12 deve ser adicionado depois do caminho Vulkan validado.

### Etapa 4 — Criar o SDK e toolchain ZEXE

O SDK precisa fornecer headers de janela, input, áudio, filesystem, clock, renderer e rede. O compilador ou backend deve gerar ZEXE com segmentos `CODE`, `RODATA`, `DATA` e `BSS`. O linker deve produzir entry point, relocação e símbolos de debug. O primeiro alvo deve ser uma demo 3D autoral, não um jogo comercial completo.

### Etapa 5 — Streaming e distribuição

O Builder deve gerar índice de assets, chunks independentes, prioridades por cena, hashes por arquivo e cache persistente. O runtime deve fazer I/O assíncrono, descompressão em workers e upload incremental para a GPU. O objetivo é reduzir loading screens sem fingir que o SSD elimina o custo de decompression, criação de recursos e upload.

### Etapa 6 — Compatibilidade nativa

Um jogo Windows instalado pode ser empacotado como dados, mas isso não o transforma em ZEXE. Para executá-lo, existem três caminhos: manter o Windows como host e iniciar o `.exe`; usar Wine/Proton em Linux; ou portar o jogo para o SDK ZConsole. O terceiro caminho é o único que produz um jogo realmente nativo ZEXE. DRM, cracks e remoção de proteções não fazem parte do projeto.

## Perfis principais C0–C8

Os nomes C0–C8 são definidos neste roteiro como **perfis de montagem e teste**. Eles não substituem o magic `ZCF0` nem alteram a especificação binária atual. Cada perfil exercita uma capacidade diferente.

| Perfil | Propósito | Estrutura principal | Resultado esperado |
|---|---|---|---|
| C0 | Programa mínimo | `META` + `CODE` | Boot, execução e HALT |
| C1 | Projeto em diretório | `META` + `CODE` + `assets` | Montagem direta sem empacotar |
| C2 | ZCARD legado | Projeto C1 convertido em ZIP | Leitura de entries e streams |
| C3 | ZCF base | MASTER + regiões vazias | Hash, alinhamento e boot |
| C4 | Atualização | MASTER + UPDATE | Escrita/leitura de UPDATE |
| C5 | DLC | MASTER + DLC | Conteúdo opcional versionado |
| C6 | Saves e usuário | SAVE + USER | Persistência e quotas |
| C7 | Streaming | Manifesto ZGF com prioridades | Prefetch e cache por cena |
| C8 | Compatibilidade nativa | `native/windows` ou `native/linux` | Empacotamento de runtime externo, sem convertê-lo em ZEXE |

## Como testar os nove diretórios

O repositório contém diretórios em `examples/c0-minimal` até `examples/c8-native-windows`. Cada um possui um `README.md`. Os perfis C0–C7 usam o manifesto `zgame-0.1` e o `CODE/game.zexe` autoral de teste. O perfil C8 demonstra o local correto para arquivos nativos Windows e deixa explícito que eles são payload externo.

Esses nove perfis são testes do pipeline ZEXE/ZCARD e, por isso, C0–C7 possuem deliberadamente um `game.zexe`. Eles não representam todos os tipos de conteúdo que um ZCARD pode armazenar. Para mídias que não são ZEXE, há exemplos separados:

```text
examples/rom-gba/
├── META/rom-runtime.json
└── roms/demo.gba

examples/disc-iso/
├── META/rom-runtime.json
└── media/demo.iso
```

Esses fixtures não contêm `CODE/game.zexe`. A ROM GBA é encaminhada ao runtime `gba`; o fixture ISO é identificado como `disc` e permanece bloqueado até que um backend de disco seja configurado. Os arquivos são fixtures autorais mínimos, não jogos comerciais e não são imagens bootáveis.

Para gerar um ZCARD ZIP legado:

```bash
./build-linux/zcard_builder \
  --source examples/c1-directory \
  --output /tmp/c1.zcard
```

Para gerar ZCF:

```bash
./build-linux/zcard_builder \
  --source examples/c3-zcf-base \
  --output /tmp/c3.zcard \
  --format zcf
```

No Windows, use o executável gerado pelo Visual Studio:

```powershell
build\Debug\zcard_builder.exe --source examples\c3-zcf-base --output $env:TEMP\c3.zcard --format zcf
```

## Como montar um jogo Windows corretamente

### Caso A — Jogo próprio ou redistribuível

Coloque no perfil C8 somente os arquivos que você tem autorização para distribuir. Um layout recomendado é:

```text
examples/c8-native-windows/
├── META/
│   ├── zgame.json
│   └── native-runtime.json
├── native/
│   └── windows/
│       ├── MyGame.exe
│       ├── MyGame_Data/
│       └── arquivos auxiliares autorizados/
└── README.md
```

O `native-runtime.json` deve registrar o executável, arquitetura, versão, argumentos permitidos e requisitos. O Builder pode armazenar esses arquivos no ZCARD, mas o emulador atual não os executa como ZEXE. Um launcher Windows futuro poderá extrair ou mapear o payload e iniciar o processo com uma sandbox.

### Caso B — Jogo comprado ou instalado de terceiros

Não copie nem redistribua arquivos protegidos sem autorização. Para uso pessoal, mantenha a instalação original e registre no manifesto apenas o caminho local autorizado, ou faça uma cópia usando o instalador e as ferramentas oficiais. Não remova DRM, não contorne autenticação e não inclua DLLs ou conteúdo cuja licença proíba redistribuição.

### Caso C — Executar no Linux/Bazzite

Um `.exe` Windows pode exigir Wine/Proton, drivers, bibliotecas, prefixo e configuração específica. O ZCARD pode distribuir metadados e assets autorizados, mas o runtime de compatibilidade deve ser separado:

```text
native/linux/
├── launcher.json
├── prefix-policy.json
└── README.md
```

Esse perfil ainda não é uma implementação funcional no ZConsole. O trabalho futuro inclui detectar Wine/Proton, configurar prefixo por jogo, mapear arquivos, encaminhar input/áudio/janela e definir a política de processos.

## O que não deve ser prometido

O ZCARD reduz custo de distribuição e pode reduzir loading com índice, streaming, cache e prefetch. Ele não converte automaticamente um jogo Windows em ZEXE. Ele também não torna um emulador compatível com Unity, Unreal ou DirectX apenas por armazenar os arquivos dessas engines. Compatibilidade real exige executar o runtime original ou portar o código para a ABI do ZConsole.

## Critérios de pronto para a próxima versão

| Critério | Teste |
|---|---|
| C0–C3 | Cada diretório gera cartão e executa o ZEXE mínimo |
| C4–C6 | Testes gravam, reabrem e verificam UPDATE, DLC, SAVE e USER |
| C7 | Teste mede prefetch, cache hit/miss e bytes streamed |
| C8 | Builder empacota payload autorizado e o emulador recusa executá-lo como ZEXE |
| Vulkan | Smoke test com triângulo em sessão gráfica |
| Windows | Rebuild completo no VS2022 Debug x64 sem LNK2019/LNK1120 |
| Segurança | Corrupção, path traversal, overflow, sobreposição e escrita na MASTER são rejeitados |

## Referências

[1]: docs/ZCF_SPEC.md "Especificação do ZCARD Container Format 0.1"

[2]: docs/RUNTIME_ARCHITECTURE.md "Arquitetura do runtime ZConsole"

[3]: CHECKLIST_ZCONSOLE.md "Checklist mestre do ZConsole"
