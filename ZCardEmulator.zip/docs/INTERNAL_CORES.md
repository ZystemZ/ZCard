# Núcleos internos libretro

A versão atual adiciona um host libretro dentro do processo do ZConsole. O host carrega uma biblioteca `.dll` no Windows ou `.so` no Linux, registra os callbacks oficiais de vídeo, áudio, entrada e ambiente, carrega a ROM diretamente da memória e executa um frame por chamada. Ele não inicia RetroArch nem outro processo filho. **O host está dentro deste projeto, mas os binários completos SameBoy/mGBA ainda não estão incluídos.** Portanto, sem uma biblioteca interna real configurada, o cartão é reconhecido e montado, mas permanece parado com diagnóstico claro; ele não simula que existe um backend.

## Configuração

Na janela **Configurações**, selecione `gb`, `gbc` ou `gba`, informe a **Biblioteca interna** e marque **Ativar núcleo interno**. Quando a biblioteca estiver configurada, ela tem prioridade sobre o emulador externo. O campo externo continua disponível como fallback quando o núcleo interno não estiver habilitado.

A configuração persistida usa chaves equivalentes a:

```ini
emulator.gba.internal_enabled=true
emulator.gba.internal_library=C:/ZConsole/cores/mgba_libretro.dll
emulator.gba.enabled=true
emulator.gba.executable=C:/Emulators/mGBA/mGBA.exe
emulator.gba.arguments={rom}
```

Os arquivos de ROM continuam sendo responsabilidade do usuário. O ZConsole não inclui ROMs comerciais, BIOS oficiais, dumps de cartuchos ou jogos de teste proprietários. Para um `.zcard` ROM, a mídia é extraída para um diretório temporário antes de ser carregada pelo core.

## SameBoy e mGBA

O primeiro alvo recomendado é **SameBoy** para Game Boy/Game Boy Color e **mGBA** para Game Boy Advance. O projeto do ZConsole contém o host genérico e a configuração; os binários dos cores devem ser obtidos, compilados e auditados separadamente, fixando um commit upstream. SameBoy deve conservar o aviso Expat/MIT-like e o mGBA deve conservar a licença MPL-2.0 e os avisos de terceiros. Um pacote de distribuição deve incluir NOTICE/SBOM e as fontes correspondentes exigidas pelas licenças.

Para SameBoy, prefira compilar o alvo libretro sem frontends SDL/Cocoa/iOS e apontar `internal_library` para `sameboy_libretro.dll` ou `sameboy_libretro.so`. Para mGBA, prefira `BUILD_LIBRETRO=ON` e desligue Qt/SDL quando o objetivo for somente o core. Os nomes finais dos artefatos dependem do commit e da toolchain; o host valida a ABI libretro antes de carregar a biblioteca.

## Limitações desta etapa

O host já executa `retro_load_game` e `retro_run`, copia frames XRGB8888 e aceita áudio em lote, mas ainda usa input neutro e não expõe mapeamento completo de controles, save states ou opções específicas por core à GUI. A próxima etapa deve adicionar input/controller mapping, persistência de SRAM e serialize/unserialize, seleção de modelo GB/GBC e testes com homebrew legalmente redistribuível. Até essa etapa, os emuladores externos permanecem a opção recomendada para uso imediato.

## Licenças não escolhidas

Mesen/Nestopia são GPL; Snes9x e Genesis Plus GX/PicoDrive possuem restrições não comerciais. Eles não foram incorporados ao repositório nesta etapa. Uma futura integração exige decisão de licenciamento do produto e revisão de compliance antes de adicionar código upstream.
