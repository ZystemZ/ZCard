# ROMs no ZCARD

## Regra

Um arquivo de ROM não é `game.zexe` e não deve ser enviado à CPU virtual ZConsole. O launcher deve identificar o formato e encaminhar a ROM ao núcleo de emulação correspondente.

```text
arquivo .gba
    ↓
resolver de runtime
    ↓
backend GBA configurado
    ├── núcleo interno do ZConsole
    └── emulador externo configurado pelo usuário
```

## Mapeamento inicial

| Extensão | Backend lógico |
|---|---|
| `.gba` | `gba` |
| `.nes` | `nes` |
| `.sfc`, `.smc` | `snes` |
| `.gb`, `.gbc` | `gameboy` |
| `.n64` | `n64` |
| `.iso`, `.bin`, `.cue`, `.chd` | definido pelo manifesto: console ou PC |

## Configuração

O cartão pode conter um manifesto de runtime, por exemplo:

```json
{
  "format": "zcard-rom-runtime-0.1",
  "rom": "roms/game.gba",
  "system": "gba",
  "backend": "configured-external-or-internal",
  "external": {
    "enabled": true,
    "command": "C:/Emulators/VGBA/vgba.exe",
    "arguments": ["{rom}"]
  },
  "internal": {
    "enabled": true,
    "core": "gba"
  }
}
```

O caminho para o executável externo deve ser configurado pelo usuário; o ZCARD não deve presumir que o VisualBoyAdvance esteja instalado nem redistribuir software de terceiros sem licença.

## ISOs por plataforma

A extensão `.iso` sozinha não determina o emulador. O manifesto deve informar o sistema:

| `system` | Destino |
|---|---|
| `ps1`, `ps2`, `ps3`, `ps4`, `ps5` | núcleo/emulador PlayStation configurado |
| `xbox`, `xbox360`, `xboxone` | núcleo/emulador Xbox configurado |
| `gamecube`, `wii`, `wiiu` | núcleo/emulador Nintendo configurado |
| `pc` + `mount.enabled=true` | montagem de ISO no Windows |

Exemplo de ISO de PC:

```json
{
  "format": "zcard-rom-runtime-0.1",
  "rom": "media/game.iso",
  "system": "pc",
  "media": "iso",
  "mount": {"enabled": true, "mode": "windows"}
}
```

Uma ISO de PS2, por exemplo, deve declarar `system: "ps2"` e ser encaminhada ao backend PS2 configurado; nunca deve ser montada como unidade de PC. Da mesma forma, uma ISO de PC não deve ser enviada a um núcleo de console apenas por possuir a extensão `.iso`.

## Prioridade de abertura

1. Validar a extensão, o sistema e o hash da ROM.
2. Preferir um núcleo interno se ele estiver disponível e autorizado.
3. Caso contrário, procurar um backend externo configurado.
4. Se nenhum backend estiver disponível, exibir uma mensagem clara e não tentar executar a ROM como ZEXE.

O suporte a iniciar processos externos aplica a política de configuração e permissões do host. No dashboard Windows, a janela **Configurações** permite ativar um perfil por sistema, informar o executável e os argumentos. O marcador `{rom}` recebe o caminho absoluto da mídia.

## Implementação atual

`resolveRomRuntime()` já valida o caminho contra traversal, verifica a existência da ROM, infere o sistema pela extensão e lê `META/rom-runtime.json`. Ele dá prioridade ao núcleo interno quando `internal.enabled` está ativo; caso contrário, retorna um plano para o processo externo configurado.

O resolvedor **não inicia processos**. A execução externa ficará em uma camada de host com confirmação de configuração, quoting seguro dos argumentos e política de sandbox. Isso permite testar a resolução no Linux/Windows sem abrir executáveis arbitrários durante o boot do cartão.

`prepareExternalRomInvocation()` valida o backend, verifica um executável configurado com caminho explícito, expande `{rom}` e monta `executable + argv` sem passar por shell. `launchExternalRom()` inicia o processo com `CreateProcess` no Windows e fecha os handles do processo pai. Para `system: "pc"` com montagem habilitada, o resolvedor retorna `windows-mount` e o modo `windows`; a montagem automática da imagem continua separada do lançamento de emuladores e deve ser provida por um host autorizado.
