# ZCARD Emulator V2 / ZConsole Emulator 0.1

A arquitetura agora separa o emulador do runtime de assets:

```text
ZCARD Emulator
├── ZConsole Emulator
│   ├── Emulator lifecycle
│   └── Host abstraction
├── Virtual ZCARD
│   └── mount/verify/openStream
├── ZGame Runtime
│   └── AssetRuntime, scheduler, cache, metrics
└── Host
    └── Windows/Linux system services
```

A API anterior de `AssetRuntime` foi preservada. A nova interface `ZAssetStream` acrescenta leitura real em chunks:

```cpp
auto stream = card.openStream("assets/level.bin");
std::array<char, 64 * 1024> buffer;
while (auto count = stream->read(buffer.data(), buffer.size())) {
    consume(buffer.data(), count);
}
```

O método não carrega o arquivo inteiro na RAM. `FileAssetStream` é a implementação atual; `VirtualZCardStream` e `ZHSAssetStream` poderão substituir a origem sem alterar o jogo.

## GUI Windows

O alvo `zcard_emulator_gui` é criado somente no Windows e usa Win32 nativo. A janela permite:

- abrir um diretório Virtual ZCARD/ZGF;
- selecionar arquivo para tentativa de montagem futura;
- listar as unidades do Windows, incluindo drives removíveis.

O formato V2 sem dependências externas é um diretório `.zgf` contendo `META/assets.zgf` e `assets/`. O suporte a um `.zcard` compactado será adicionado em uma camada de reader, preservando `VirtualZCard`.

## Núcleo ZConsole

A primeira fatia do núcleo já existe em `emulator/console.hpp` e `console.cpp`:

- memória linear configurável;
- leitura e escrita com checagem de limites;
- relógio/timing em microssegundos;
- estado `running`;
- reset do console.

Esse núcleo ainda não pretende simular uma CPU real. Ele estabelece o ciclo de vida e os contratos que serão ligados depois a CPU, GPU, áudio, entrada e OS.

## GUI Windows atual

A GUI Win32 possui quatro ações:

1. abrir diretório Virtual ZCARD/ZGF e executar mount/boot;
2. selecionar arquivo `.zcard`/`.zgf` — o reader compactado será conectado na próxima etapa;
3. selecionar configuração `.ini`, `.json` ou `.cfg`;
4. listar as unidades Windows, preparando a detecção de drive ZCARD físico.

O caminho funcional agora é o diretório `examples\\demo.zgf`, que deve conter `META\\assets.zgf`.

## CPU virtual

A CPU inicial usa instruções de 1 byte e operandos little-endian:

| Opcode | Operação |
|---|---|
| `00` | NOP |
| `01 imm32` | LOAD_IMM A |
| `02 imm32` | ADD_IMM A |
| `03 addr32` | STORE A |
| `04 addr32` | JMP |
| `FF` | HALT |

Ela existe para validar o ciclo fetch-decode-execute, registradores, PC, flag zero e breakpoints futuros; não representa ainda a arquitetura final do ZConsole.

## Reader `.zcard`

`ZCardArchive` lê contêineres ZIP `.zcard`, indexa o diretório central e expõe os arquivos como `ZAssetStream`. Entradas ZIP `stored` funcionam sem dependências. Entradas DEFLATE funcionam quando o CMake encontra ZLIB (`find_package(ZLIB)`). Sem ZLIB, o erro informa como instalar/habilitar o suporte.

A `VirtualZCard` aceita tanto um diretório `.zgf` quanto um arquivo `.zcard`.

## GUI e métricas

A GUI Win32 mantém o emulador montado e atualiza a cada 500 ms:

- cache hits/misses;
- prefetch processado;
- falhas;
- bytes lidos e streamed;
- latência estimada.

Ela também permite abrir diretório, abrir arquivo `.zcard`, selecionar configuração e listar drives Windows.
