# Execução no Windows

O projeto C++ foi estruturado como projeto CMake, formato suportado nativamente pelo Visual Studio 2022. Isso evita manter arquivos `.vcxproj` gerados manualmente e permite gerar a solução adequada à versão instalada do Visual Studio.

## Requisitos

- Visual Studio 2022;
- workload **Desktop development with C++**;
- componente **C++ CMake tools for Windows**;
- CMake incluído no Visual Studio.

## Fluxo recomendado

Abra a pasta `zcard-cpp` em **File > Open > Folder**. Selecione o preset `windows-vs2022`, escolha o alvo `zconsole_demo` e execute em `x64-Debug`.

No terminal PowerShell do Visual Studio:

```powershell
Set-Location C:\caminho\zcard-cpp
.\build.ps1 -Action build
.\build.ps1 -Action test
.\build.ps1 -Action run -Scene menu
```

Para executar uma cena com scheduler de deadline:

```powershell
.\out\build\windows-vs2022\Debug\zconsole_demo.exe `
  .\examples\demo.zgf `
  --scene level `
  --channels 4 `
  --scheduler deadline `
  --deadline-ms 100
```

A aplicação usa o diretório `examples\demo.zgf` como mídia virtual. O runtime não depende de DLLs externas nem de bibliotecas de terceiros.

## Validação desta entrega

O sandbox usado para gerar o projeto não possui CMake nem compilador C++, portanto a compilação nativa não foi possível neste ambiente. A validação final deve ser feita no Visual Studio do usuário usando `build.ps1 -Action build` e `build.ps1 -Action test`.
