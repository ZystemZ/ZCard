# Fase A — MVP-2 ZCF 0.1

## Decisão

O próximo marco do ZConsole será um container `.zcard` com cabeçalho ZCF e regiões protegidas. O ZIP MVP-1 será mantido como formato legado detectado automaticamente pelo magic. Nenhum arquivo Unity/Overgrowth será renomeado para ZEXE; jogos reais precisarão da toolchain ZEXE.

## Ordem de implementação

O incremento atual adiciona `ZCardContainer`, detecta `ZCF0` ou ZIP legado no `VirtualZCard`, valida header/tabela/região MASTER, verifica SHA-256 e abre o ZIP interno MASTER. O Builder possui `--format zcf`, produzindo uma MASTER alinhada em 4096 bytes. Regiões graváveis e escrita transacional ficam nos próximos incrementos.

1. Implementar estruturas binárias do header ZCF e da tabela de regiões.
2. Implementar `ZCardContainer::create`, `open`, `verify` e `regionInfo`.
3. Reusar o ZIP interno existente para a região MASTER.
4. Adicionar detecção ZCF/ZIP na montagem de `VirtualZCard`.
5. Adicionar `writeStream` com bloqueio de MASTER e capacidade para regiões graváveis.
6. Adicionar SHA-256 sem dependência obrigatória: preferir BCrypt no Windows e backend documentado para Linux/testes.
7. Integrar `ZConsoleEmulator::boot` com verificação da MASTER.
8. Criar `tests/zcf_tests.cpp` cobrindo criação, leitura, hash mismatch e escrita protegida.
9. Adicionar opção CLI `zcard_builder --format zcf`, mantendo ZIP como padrão durante a transição.
10. Atualizar Dashboard com tipo de container e estado de integridade.

## Critério de pronto

A Fase A só será marcada como concluída quando o teste fizer `build → verify → open → tentativa de escrita em MASTER (falha) → escrita em UPDATE (sucesso) → corrupção/hash mismatch (falha)`, e quando o cartão legado continuar passando pelos testes existentes.

## O que não será feito nesta fase

Não serão adicionados SDL2, renderer, áudio, input, firmware RP2040 ou tradução de C# Unity. Esses itens pertencem às Fases B–E. O objetivo é evitar misturar segurança do container com a toolchain de gameplay.

## Riscos

SHA-256 precisa de uma implementação estável em MSVC v143 e Linux. A abstração `ZHash256` deve esconder o backend. A tabela de regiões precisa de limites explícitos para evitar overflow de 64 bits. A compatibilidade ZIP deve ser testada com os cartões MVP-1 existentes.
