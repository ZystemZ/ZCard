# Protocolo físico ZHS V0.1

## Estado

Esta é a primeira camada de contrato para um leitor ZCARD físico. A implementação atual é independente de hardware real e usa `ZhsMemoryDevice` como backend de teste.

## Arquitetura

```text
VirtualZCard       cartão em diretório ou arquivo
       │
       └── API lógica de emulação

ZHSDevice          cartão físico ou backend simulado
       │
       └── transporte futuro USB CDC/vendor-specific
```

`ZHSDevice` é separado de `VirtualZCard` para que a emulação por arquivo não seja confundida com descoberta ou acesso a um dispositivo removível.

## Transporte V0.1

O transporte de desenvolvimento é USB CDC. O protocolo é binário e possui CRC32; a velocidade de uma porta serial não faz parte do contrato lógico.

O transporte final ainda não está fixado. USB vendor-specific é o candidato de referência. O protocolo não depende de cartão SD, microSD, letra de unidade ou USB Mass Storage.

## Identificação

Cada dispositivo deve informar:

```text
device_id
firmware_version
capacity
block_size
present
read_only
master_locked
```

O backend de teste usa:

```text
ZHS-SIM-0001
sim-0.1
```

Um dispositivo físico deverá possuir um identificador estável de mídia/controlador. O identificador não deve conter dados pessoais.

## Quadro binário

Todos os campos são little-endian:

| Offset | Tamanho | Campo |
|---:|---:|---|
| 0 | 2 | `magic = 0x485A` (`Z`, `H` no wire) |
| 2 | 1 | `version = 1` |
| 3 | 1 | `command` |
| 4 | 2 | `flags` |
| 6 | 2 | `request_id` |
| 8 | 8 | `offset` |
| 16 | 4 | `payload_length` |
| 20 | N | `payload` |
| final | 4 | `CRC32` sobre cabeçalho + payload |

O backend atual limita o payload a 1 MiB para proteger o parser. A implementação de transporte poderá impor um limite menor.

## Comandos

| Código | Nome | V0.1 |
|---:|---|---|
| `0x01` | `GET_INFO` | Retorna identificação e capacidades; contrato definido. |
| `0x02` | `READ` | Lê `payload_length` bytes a partir de `offset`. |
| `0x03` | `VERIFY` | Verifica integridade do dispositivo. |
| `0x04` | `GET_STATUS` | Retorna presença, modo somente leitura e estado. |

A V0.1 não possui comando de escrita física. O leitor começa deliberadamente em modo somente leitura. Escrita, atualização e política de `MASTER` serão adicionadas somente depois de o transporte e a recuperação contra remoção serem testados.

## Status

| Código | Nome |
|---:|---|
| `0` | `OK` |
| `1` | `INVALID_FRAME` |
| `2` | `UNSUPPORTED_VERSION` |
| `3` | `INVALID_COMMAND` |
| `4` | `INVALID_RANGE` |
| `5` | `READ_ONLY` |
| `6` | `NOT_PRESENT` |
| `7` | `INTEGRITY_ERROR` |
| `8` | `IO_ERROR` |

A camada de transporte deve retornar uma resposta para cada requisição válida, associada por `request_id`.

## Dispatcher V0.1

`ZhsDispatcher` recebe um quadro completo, valida magic, versão, tamanho e CRC, executa a operação no backend `ZhsDevice` e devolve outro quadro completo. O `request_id`, o comando e o offset são preservados; `flags` contém o valor de `ZhsStatus`.

Os payloads de resposta são:

| Comando | Payload de resposta |
|---|---|
| `GET_INFO` | `u16 device_id_len`, `device_id`, `u16 firmware_len`, `firmware`, `u64 capacity`, `u32 block_size`, `u8 present`, `u8 read_only`, `u8 master_locked` |
| `READ` | Os bytes solicitados; o tamanho desejado é o tamanho do payload da requisição. |
| `VERIFY` | Vazio quando `flags == OK`. |
| `GET_STATUS` | Quatro bytes: `open`, `present`, `read_only`, `master_locked`. |

O dispatcher não implementa escrita na V0.1. Uma solicitação com comando desconhecido retorna `INVALID_COMMAND`.

## Segurança inicial

O requisito mínimo de V0.1 é:

- rejeitar magic inválido;
- rejeitar versão desconhecida;
- rejeitar comprimento inconsistente;
- rejeitar CRC inválido;
- rejeitar leitura fora da capacidade;
- não permitir escrita no backend somente leitura;
- informar `master_locked` explicitamente;
- não expor a mídia como USB Mass Storage.

## Próximos incrementos

1. backend de transporte USB real no Windows;
2. enumeração de dispositivos ZHS;
3. integração do `ZHSDevice` com `VirtualZCard`/runtime;
4. modo somente leitura no dashboard;
5. verificação de firmware e identidade;
6. teste de remoção e reconexão;
7. escrita transacional em `UPDATE`, nunca em `MASTER`;
8. protocolo físico dedicado do leitor para cartucho.

## Validação dos exemplos C0-C8

O gerador dos perfis agora extrai `memory_required` do header do `CODE/game.zexe`, em vez de assumir um valor fixo. Isso evita que o manifesto declare menos memória do que o executável exige. O perfil C7 também usa deadlines numéricos válidos no formato ZGF.

O teste `c0_c8_directory_boot_tests` monta cada diretório de `examples/c0-minimal` até `examples/c8-native-windows`, executa o boot e confirma que a CPU termina em `HALTED` com `A=42`. C8 continua sendo um payload Windows externo; o arquivo `PLACEHOLDER.txt` não é executado pelo loader ZEXE.
