# Builder ZConsole 0.6

## Objetivo

A versão 0.6 deve transformar o Builder de uma API usada pelos testes em uma ferramenta reproduzível de produção. O fluxo recomendado é:

```text
projeto .zgame -> validate -> build ZCARD -> verify -> report -> run no emulador
```

## Entregue nesta etapa

O alvo CMake `zcard_builder` fornece uma CLI sem dependência da GUI. A saída agora ordena entradas por caminho, usa metadados ZIP estáveis e reabre o arquivo gerado para verificar contagem, nomes, tamanhos e CRC:

```text
zcard_builder --source examples/complete-game.zgame \
             --output build/complete-game.zcard \
             --report build/complete-game-report.txt
```

O formato pode ser escolhido explicitamente:

```text
zcard_builder --source examples/complete-game.zgame \
              --output build/complete-game.zcard \
              --format zcf
```

`legacy` continua sendo o padrão. `zcf` gera o header `ZCF0`, uma tabela com a região MASTER alinhada em 4096 bytes e o ZIP MVP-1 dentro dessa região. O emulador detecta o container e abre a MASTER pela mesma API pública.

A ferramenta identifica três tipos de fonte: projeto ZEXE (`META/zgame.json` + `CODE/game.zexe`), runtime ROM/ISO (`META/rom-runtime.json` + a mídia indicada) e payload nativo (`zgame-native-0.1`, como C8). Somente o primeiro exige `CODE/game.zexe`. Todos percorrem arquivos recursivamente, rejeitam caminhos inválidos e duplicados, calculam hashes FNV-1a32, verificam o ZCARD pós-build e salvam relatório textual. O CTest `zcard_builder_cli` executa esse fluxo automaticamente; os testes de runtime cobrem também a criação de um ZCARD GBA sem ZEXE.

Quando `META/assets.zgf` não existe, o Builder gera essa entrada dentro do ZCARD sem modificar o projeto de origem. Cada arquivo em `assets/` recebe grupo `streaming`, prioridade `100`, sem deadline ou dependência, e um tipo inferido da extensão; por exemplo, `assets/player.ztex` recebe o tipo `ztex`. Um projeto que já possui `META/assets.zgf` continua usando o manifesto fornecido pelo autor.

## Melhorias recomendadas para completar 0.6

| Prioridade | Melhoria | Motivo | Critério de aceite |
|---|---|---|---|
| P0 | Parser JSON formal | O parser atual é deliberadamente pequeno e deve rejeitar JSON malformado | Campos, tipos e mensagens de erro validados por testes |
| P0 | Schema versionado de `zgame.json` | Evita incompatibilidades silenciosas | `format`, `platform`, memória, cenas e executável validados por versão |
| P0 | Build determinístico | Facilita CI e auditoria | **Concluído:** mesmos arquivos produzem bytes idênticos e relatório estável |
| P0 | Verificação pós-build | Garante que o arquivo produzido pode ser montado | **Concluído:** Builder reabre o ZCARD e verifica entradas, tamanhos e CRC |
| P1 | Cache incremental | Evita reprocessar assets inalterados | Hashes permitem rebuild parcial e relatório de cache |
| P1 | Índice de assets | Acelera enumeração e prepara streaming | `META/assets.index` contém caminho, tipo, tamanho e hash |
| P1 | Compressão configurável | Reduz cartões sem comprometer stored | `--compression stored|deflate` e validação dos dois modos |
| P1 | Perfil de build | Separa Debug, Release e distribuição | Manifesto informa perfil e símbolos opcionais |
| P2 | Assinatura de cartão | Protege integridade e origem | Reader valida assinatura quando habilitada |
| P2 | Integração GUI | Evita alternância para terminal | Botões Build ZCARD, escolher saída e abrir relatório |
| P2 | Plugins/decoders de tipos | Converte etiquetas como `zmesh` em recursos utilizáveis | Decoder registra tipo, versão e validação |

## Tipos customizados de assets

`META/assets.zgf` aceita um sétimo campo opcional:

```text
asset|assets/player.zmesh|boot|10|100|assets/player.mat|zmesh
```

O tipo é metadado (`AssetInfo::type`). O runtime atual lê o arquivo como bytes; adicionar `zmesh` não implementa um decoder. Decoders devem ser adicionados posteriormente nos módulos de renderer, áudio ou ferramentas.

## Uso no CI

```text
cmake -S . -B build
cmake --build build --target zcard_builder zconsole_tests
ctest --test-dir build --output-on-failure
build/zcard_builder --source examples/complete-game.zgame \
                    --output build/complete-game.zcard \
                    --report build/complete-game-report.txt
```

O artefato só deve ser distribuído se o CTest, a verificação ZIP e o mount pelo emulador forem bem-sucedidos.
