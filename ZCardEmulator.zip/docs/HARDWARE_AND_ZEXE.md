# ZEXE e hardware virtual ZConsole

## O que é ZEXE

`ZEXE` é um executável binário personalizado para a ZCPU virtual. Ele não é um `.exe` PE do Windows renomeado. O header atual contém a assinatura `ZEXE`, versão, arquitetura, offsets, tamanho do CODE, memória requerida, entry point e checksum. O código é executado diretamente pela `ZVirtualCpu`.

A sequência de produção é:

```text
código suportado/bytecode
    → assembler ou toolchain ZConsole
    → game.zexe
    → META/zgame.json + assets
    → zcard_builder
    → game.zcard
    → ZConsoleEmulator
```

O exporter Unity atual gera apenas o ZEXE de exemplo configurável. Para jogos reais, ainda será necessário um compilador de gameplay para a ISA ZCPU ou uma VM/IR suportada.

## Memória

A memória principal padrão é 64 MiB e é validada pelo loader contra `memory_required`. A CPU usa endereços lineares de 32 bits dentro dessa memória.

A camada de hardware virtual introduz um framebuffer separado da RAM:

```text
ZConsoleGraphics(320, 180)
  4 bytes por pixel: RGBA8
  320 * 180 * 4 = 230400 bytes
```

A API atual oferece `clear`, `fillRect`, acesso ao framebuffer e dimensões. Ela é determinística e funciona em modo headless, permitindo testar jogos sem uma janela.

## Input

`ZConsoleInput` mantém eventos de teclado/botão, estado pressionado e fila de polling. Os botões iniciais são `Up`, `Down`, `Left`, `Right`, `Action` e `Start`.

## Áudio

`ZConsoleAudio` registra tons com frequência e duração por meio de `playTone`. O backend atual é headless e determinístico; o próximo backend SDL2 deve consumir essa fila e produzir o áudio físico.

## Estado desta entrega

GPU/framebuffer, input e áudio possuem APIs funcionais e testes unitários sem dependências externas. A janela visível, captura de teclado real, gamepad e saída de áudio física dependem do backend SDL2 da Fase B. Isso é deliberado para manter o build Visual Studio funcional sem tornar SDL2 obrigatório.
