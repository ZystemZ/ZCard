# Serviços da plataforma ZConsole

## Gráficos

O jogo deve escolher um backend por configuração, não assumir uma API única:

```text
Auto → Vulkan → DirectX 12 → DirectX 11 → OpenGL → Software
```

No Windows, DirectX 12 é uma opção de alto desempenho e DirectX 11 é fallback de compatibilidade. No Linux, Vulkan é o backend principal; OpenGL fica como fallback. SDL2 fornece janela e eventos, mas não substitui esses renderers.

Resolução deve ser configurável. A resolução lógica do jogo pode ser 640×360, 1280×720, 1920×1080 ou outra; a resolução de apresentação é independente e pode usar fullscreen, vsync e dynamic resolution. HDR, MSAA e upscaling devem ser capacidades negociadas pelo backend.

## Áudio HD

O contrato usa sample rate, canais, tamanho de buffer e surround. A implementação física futura deve suportar PCM 16/24/32-bit, float, múltiplos canais, mixagem, streaming, áudio posicional e WASAPI/PulseAudio/ALSA. `playTone` é somente uma primitiva de teste; não representa o sistema de áudio final.

## Input e controles USB

SDL enumera joysticks e permite que o runtime adicione mapeamentos para NES, SNES, Xbox, Switch e PlayStation. O ID e o nome físico são preservados; a família deve ser determinada por um banco de mapeamentos e não apenas pelo nome.

O input final deve suportar teclado completo, mouse, gamepad, hotplug, dead zones, rumble, triggers, eixos, combinação de teclas, layouts internacionais e remapeamento por jogo.

## Storage e filesystem

Jogos não devem escrever diretamente no disco inteiro. `ZStorage` separa:

- `InstallReadOnly`: assets instalados e conteúdo do ZCARD;
- `SaveReadWrite`: saves e configurações de progresso;
- `CacheReadWrite`: shaders e dados derivados descartáveis;
- `UserReadWrite`: conteúdo criado pelo usuário.

Cada área usa path canonicalizado, rejeita traversal, permite quota e gravação atômica. O runtime pode mapear o diretório raiz para SSD, HDD ou armazenamento externo sem expor o sistema inteiro ao jogo.

## Rede

A API futura deve separar transporte, sessão e sincronização. UDP/TCP/QUIC não devem ser expostos diretamente ao jogo sem sandbox e políticas de firewall. O contrato inicial reserva `ZNetwork`; sockets reais serão implementados com Winsock no Windows e BSD sockets/epoll no Linux, com uma camada comum.

## Windows e Linux

Um jogo Windows nativo continua sendo executado pelo Windows host, fora da VM, mediante um launcher/integração opcional. Isso não é o mesmo que executar o PE dentro da ZCPU.

Um jogo Linux não roda nativamente dentro do Windows apenas porque está dentro de um ZCARD. Há três caminhos distintos:

1. **Builds duplos:** o jogo é compilado para Windows e Linux/Bazzite, recomendado para a primeira versão.
2. **Runtime Linux no Windows:** WSL2, máquina virtual ou container, dependente do host.
3. **Compatibilidade futura:** Wine/Proton ou uma camada própria, grande e fora do escopo do emulador ZCPU.

O ZConsole pode fornecer um launcher que escolhe o build correto do ZCARD, mas não deve renomear `.exe` para `.zexe`. `ZEXE` continua sendo um binário próprio da toolchain ZConsole.

## Estado desta versão

Nesta etapa foram criados os contratos `ZGraphicsConfig`, `ZAudioConfig`, `ZControllerInfo`, `ZStorage` e `ZNetwork`. SDL2 já possui janela, framebuffer, teclado, áudio básico e enumeração de joysticks. Vulkan, DirectX 12, DirectX 11, OpenGL, áudio HD completo e rede real ainda precisam de backends e testes próprios; permanecem deliberadamente não marcados como concluídos.
