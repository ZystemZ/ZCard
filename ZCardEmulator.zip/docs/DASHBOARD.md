# ZCARD Emulator Dashboard

A GUI deixou de ser um launcher mínimo e agora oferece um dashboard Win32 para inspeção do emulador.

## Painéis

O painel superior informa o estado do emulador, contador de instruções da CPU virtual e program counter. O painel esquerdo lista os assets carregados pelo manifesto, incluindo grupo e prioridade. O painel direito mantém um log de eventos de boot e prefetch.

## Controles

`Montar diretório` abre um Virtual ZCARD/ZGF. `Abrir .zcard` abre um arquivo ZIP ZCARD. `Prefetch boot` enfileira os assets do grupo boot. `Processar fila` executa a fila com dois canais simulados. O status é atualizado automaticamente a cada 500 ms.

A GUI utiliza os métodos públicos `assetList()`, `metrics()`, `assetsForGroup()` e `processPrefetch()`; nenhuma estrutura interna do runtime é acessada diretamente.

## Manual completo

Consulte `docs/ZCONSOLE_DASHBOARD_0.5.html` para o manual visual completo, incluindo montagem, painéis, execução, inspeção hexadecimal, diagnóstico e o formato de tipos customizados em `META/assets.zgf`.
