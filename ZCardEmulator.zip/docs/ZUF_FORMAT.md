# ZUF — ZCARD Update Format 0.1

## Objetivo

Um arquivo `.zuf` é um pacote de atualização separado do cartão original. Ele não altera o `MASTER` automaticamente e não deve ser confundido com um `.zcard` completo.

## Criação

Pela CLI:

```text
zcard_builder --source ./update-1.1 --output ./update-1.1.zuf --format zuf
```

Na GUI, use **Salvar .zuf**, selecione a pasta da atualização e escolha o destino do pacote.

## Estrutura binária V0.1

Todos os inteiros são little-endian.

### Cabeçalho de 32 bytes

| Offset | Tamanho | Campo |
|---:|---:|---|
| 0 | 4 | `magic = ZUF0` |
| 4 | 2 | versão `1` |
| 6 | 2 | tamanho do cabeçalho `32` |
| 8 | 4 | quantidade de arquivos |
| 12 | 8 | tamanho do payload |
| 20 | 8 | reservado, zero |
| 28 | 4 | reservado, zero |

### Entrada

Cada arquivo é serializado como:

```text
name_length:u16
reserved:u16
data_size:u64
name:name_length bytes
data:data_size bytes
```

Os caminhos são relativos à pasta da atualização, ordenados lexicograficamente e rejeitam `..`, caminhos absolutos e nomes maiores que 65535 bytes.

## Política

A V0.1 somente cria o pacote. Ainda não instala a atualização no cartão físico. A instalação futura deverá:

1. verificar o pacote;
2. verificar assinatura, quando o perfil exigir;
3. escrever em `UPDATE`, nunca em `MASTER`;
4. verificar hash;
5. fazer commit transacional;
6. manter rollback para a versão anterior.

## Salvamento de ZCARD

Na GUI, **Salvar .zcard**:

- exporta um diretório montado como ZIP legado determinístico;
- copia um `.zcard` já existente para o destino escolhido.

A exportação para ZCF pode ser feita pela CLI com `--format zcf`.
