# Arquitetura do runtime ZConsole para hardware Ryzen 5 5500G / 16 GB / SSD

## Decisão de plataforma

Não é necessário escrever um sistema operacional dedicado para o primeiro hardware ZConsole. O caminho recomendado é um runtime nativo executado sobre Windows 10/11 ou Linux. O sistema operacional fornece drivers de GPU, agendamento, filesystem, áudio e USB; o runtime fornece a máquina virtual ZConsole, o formato ZCARD e a ABI do jogo.

Um SO próprio só passa a fazer sentido depois de existir hardware final, firmware de boot, drivers de GPU, gerenciamento de memória, filesystem, atualização segura e uma necessidade comprovada de eliminar o overhead do host. Implementá-lo agora atrasaria o objetivo principal e duplicaria funcionalidades já disponíveis.

## Camadas

```text
Jogo / SDK ZConsole
        │
ZEXE + syscalls + AssetRuntime
        │
ZConsoleEmulator / frame loop / memória / input
        │
ZConsole platform abstraction
        ├── SDL2: janela, eventos, áudio, gamepad
        ├── Vulkan: renderer 3D principal multiplataforma
        ├── DirectX 12: backend Windows opcional
        └── OpenGL: fallback de compatibilidade
        │
Windows ou Linux + drivers do Ryzen 5 5500G
```

SDL2 não é um renderer AAA. Ela resolve criação de janela, input, gamepad e dispositivo de áudio. O renderer 3D deve ser uma camada própria com backend Vulkan/D3D12.

## Resolução e GPU

O framebuffer fixo 320×180 foi mantido apenas como teste headless. O runtime final deve separar resolução lógica e resolução de apresentação:

- resolução lógica configurável por jogo;
- janela redimensionável;
- render target HDR opcional;
- swapchain na resolução do monitor;
- dynamic resolution e upscaling futuros;
- VRAM gerenciada pelo backend GPU, não dentro da RAM virtual da CPU.

A API futura deve expor `ZRenderDevice`, `ZTexture`, `ZBuffer`, `ZPipeline`, `ZCommandList` e `ZSwapchain`. O primeiro backend recomendado é Vulkan; DirectX 12 é uma otimização Windows posterior.

## Memória

O Ryzen 5 5500G possui GPU integrada, portanto a VRAM pode ser memória compartilhada. O runtime deve distinguir:

- RAM do processo/CPU virtual;
- alocações de recursos GPU;
- staging/upload buffers;
- cache de shaders;
- cache de assets descomprimidos.

O `.zcard` permanece armazenamento de distribuição. Assets grandes não devem ser carregados todos na RAM: o AssetRuntime deve usar leitura por chunks, cache LRU por orçamento e prefetch por cena.

## Loading e streaming

Para reduzir loading screens:

1. manter índices de assets e offsets no ZCARD;
2. usar compressão por asset ou grupo, não um único ZIP monolítico;
3. fazer I/O assíncrono em threads do host;
4. descomprimir em workers;
5. fazer upload GPU incremental;
6. manter cache persistente de shaders e dados derivados;
7. priorizar assets visíveis e dependências da cena;
8. permitir que a CPU execute enquanto assets não críticos chegam.

O SSD reduz latência, mas não elimina custo de descompressão, upload e criação de recursos GPU. A arquitetura precisa medir cada etapa.

## AAA: limite realista

Um emulador com SDL2/Vulkan pode ser a base de um runtime visual, mas isso não torna automaticamente um jogo AAA de Unity/Unreal executável. Para AAA serão necessários:

- renderer 3D completo;
- sistema de materiais e shaders;
- animação, física, cenas e streaming de mundo;
- áudio espacial;
- input e networking;
- toolchain capaz de compilar gameplay para a ABI ZConsole;
- importadores de formatos e pipeline de assets;
- otimização multithread e GPU.

A primeira meta técnica correta é uma demo 3D autoral pequena com streaming e renderer Vulkan, não declarar compatibilidade imediata com executáveis Unity/Unreal.

## Plano de backends

1. SDL2 real para janela/input/áudio.
2. Abstração de renderer e teste com clear/triângulo.
3. Vulkan com swapchain e sincronização.
4. Texturas, buffers, shaders e upload assíncrono.
5. `runFrame()` integrado ao emulador.
6. Demo 3D com streaming de assets.
7. Backend D3D12 opcional para Windows.
8. SDK/toolchain ZEXE para gameplay real.

## Primeiro backend Vulkan

O runtime agora possui `ZVulkanRuntime`, que cria uma `VkInstance`, enumera dispositivos físicos e informa vendor, device, versão da API e se a GPU é discreta. A demo oferece:

```bash
./build-vulkan/zconsole_demo --vulkan-info
```

No ambiente de validação, o loader encontrou `llvmpipe` Vulkan 1.4. Isso valida a integração do loader, mas não representa o desempenho de uma GPU Radeon real. O runtime agora expõe as extensões Vulkan exigidas pela SDL2, cria `VkSurfaceKHR` quando há uma janela disponível, seleciona uma fila com suporte simultâneo a gráficos e apresentação, cria `VkDevice`, negocia formato/extent, cria `VkSwapchainKHR` com image views, render pass, framebuffers, command pool, command buffers, semáforos e fence. `presentFrame()` executa clear, submit e present; a validação visual requer uma sessão gráfica ativa.

DirectX 11/12 ainda exigem implementação nativa Windows usando DXGI/D3D11/D3D12 e não podem ser testados neste host Linux. Os contratos de seleção de backend já existem, mas não devem ser marcados como suporte funcional até haver build e smoke test no Visual Studio/Windows.
