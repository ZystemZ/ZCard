#include "zconsole/emulator/zexe.hpp"
#include <fstream>
#include <iostream>
#include <string>

namespace {
void usage() {
  std::cout << "zcard_builder --source <diretorio> --output <arquivo> "
               "[--format legacy|zcf|zuf] [--report <arquivo.txt>]\n";
}
}

int main(int argc, char** argv) {
  std::filesystem::path source, output, reportPath;
  std::string format = "legacy";
  for (int i = 1; i < argc; ++i) {
    const std::string arg = argv[i];
    if (arg == "--help") { usage(); return 0; }
    if (i + 1 >= argc) { std::cerr << "argumento sem valor: " << arg << "\n"; return 2; }
    if (arg == "--source") source = argv[++i];
    else if (arg == "--output") output = argv[++i];
    else if (arg == "--format") format = argv[++i];
    else if (arg == "--report") reportPath = argv[++i];
    else { std::cerr << "opcao desconhecida: " << arg << "\n"; usage(); return 2; }
  }
  if (source.empty() || output.empty() ||
      (format != "legacy" && format != "zcf" && format != "zuf")) {
    usage(); return 2;
  }

  std::string report, error;
  bool ok = false;
  if (format == "zcf") ok = zconsole::ZCardBuilder::buildZcf(source, output, &report, &error);
  else if (format == "zuf") ok = zconsole::ZCardBuilder::buildZuf(source, output, &report, &error);
  else ok = zconsole::ZCardBuilder::build(source, output, &report, &error);
  if (!ok) { std::cerr << "BUILDER FAILED: " << error << "\n"; return 1; }
  std::cout << report;
  if (!reportPath.empty()) {
    std::ofstream file(reportPath);
    if (!file) { std::cerr << "nao foi possivel salvar relatorio: " << reportPath.string() << "\n"; return 3; }
    file << report;
  }
  return 0;
}
