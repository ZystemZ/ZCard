#include "zconsole/platform/settings.hpp"
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace zconsole {
namespace {
std::string trim(std::string value) {
  const auto first = value.find_first_not_of(" \t\r\n");
  const auto last = value.find_last_not_of(" \t\r\n");
  return first == std::string::npos ? std::string{} : value.substr(first, last - first + 1);
}
std::string valueOf(const std::map<std::string, std::string>& values, const std::string& key, const std::string& fallback = {}) {
  const auto found = values.find(key);
  return found == values.end() ? fallback : found->second;
}
bool boolean(const std::map<std::string, std::string>& values, const std::string& key, bool fallback) {
  const auto value = valueOf(values, key, fallback ? "true" : "false");
  return value == "1" || value == "true" || value == "yes";
}
std::uint32_t number(const std::map<std::string, std::string>& values, const std::string& key, std::uint32_t fallback) {
  try { return static_cast<std::uint32_t>(std::stoul(valueOf(values, key, std::to_string(fallback)))); } catch (...) { return fallback; }
}
void put(std::ofstream& output, const std::string& key, const std::string& value) { output << key << "=" << value << "\n"; }
std::string pathString(const std::filesystem::path& path) { return path.generic_string(); }
}

std::filesystem::path defaultSettingsPath() {
#ifdef _WIN32
  const char* appData = std::getenv("APPDATA");
  return (appData ? std::filesystem::path(appData) : std::filesystem::path(".")) / "ZConsole" / "settings.ini";
#else
  const char* home = std::getenv("HOME");
  return (home ? std::filesystem::path(home) : std::filesystem::path(".")) / ".config" / "zconsole" / "settings.ini";
#endif
}

ZHostSettings defaultHostSettings() {
  ZHostSettings settings;
  settings.systemDirectory = std::filesystem::current_path();
  settings.savesDirectory = settings.systemDirectory / "saves";
  settings.cacheDirectory = settings.systemDirectory / "cache";
  settings.emulators["gba"] = {};
  settings.emulators["nes"] = {};
  settings.emulators["snes"] = {};
  settings.emulators["gameboy"] = {};
  settings.emulators["n64"] = {};
  settings.emulators["ps1"] = {};
  settings.emulators["ps2"] = {};
  settings.emulators["gamecube"] = {};
  settings.emulators["wii"] = {};
  settings.emulators["pc"] = {};
#ifdef _WIN32
  const auto coreExtension = ".dll";
#elif __APPLE__
  const auto coreExtension = ".dylib";
#else
  const auto coreExtension = ".so";
#endif
  auto coreDirectory = settings.systemDirectory / "runtime" / "cores";
#ifdef _WIN32
  coreDirectory /= (sizeof(void*) == 8 ? "windows/x86_64" : "windows/i686");
#endif
  const auto mgba = coreDirectory / ("mgba_libretro" + std::string(coreExtension));
  const auto sameboy = coreDirectory / ("sameboy_libretro" + std::string(coreExtension));
  if (std::filesystem::is_regular_file(mgba)) {
    settings.emulators["gba"].internalEnabled = true;
    settings.emulators["gba"].internalLibrary = mgba;
  }
  if (std::filesystem::is_regular_file(sameboy)) {
    settings.emulators["gameboy"].internalEnabled = true;
    settings.emulators["gameboy"].internalLibrary = sameboy;
    settings.emulators["gameboy-color"].internalEnabled = true;
    settings.emulators["gameboy-color"].internalLibrary = sameboy;
  }
  return settings;
}

bool loadHostSettings(ZHostSettings& settings, std::string* error) {
  settings = defaultHostSettings();
  const auto file = defaultSettingsPath();
  std::ifstream input(file);
  if (!input) return true;
  std::map<std::string, std::string> values;
  std::string line;
  while (std::getline(input, line)) {
    line = trim(line);
    if (line.empty() || line[0] == '#' || line[0] == ';' || line[0] == '[') continue;
    const auto separator = line.find('=');
    if (separator == std::string::npos) { if (error) *error = "configuração inválida: linha sem '='"; return false; }
    values[trim(line.substr(0, separator))] = trim(line.substr(separator + 1));
  }
  settings.systemDirectory = valueOf(values, "system.directory", pathString(settings.systemDirectory));
  settings.savesDirectory = valueOf(values, "storage.saves", pathString(settings.savesDirectory));
  settings.cacheDirectory = valueOf(values, "storage.cache", pathString(settings.cacheDirectory));
  settings.cpuThreads = number(values, "cpu.threads", settings.cpuThreads);
  settings.memoryMiB = number(values, "memory.mib", settings.memoryMiB);
  settings.networkEnabled = boolean(values, "network.enabled", settings.networkEnabled);
  settings.networkUdpPort = static_cast<std::uint16_t>(number(values, "network.udp_port", settings.networkUdpPort));
  settings.keyboardProfile = valueOf(values, "input.keyboard_profile", settings.keyboardProfile);
  settings.controllerId = valueOf(values, "input.controller_id", settings.controllerId);
  settings.preferInternalCores = boolean(values, "emulation.prefer_internal", settings.preferInternalCores);
  settings.graphics.mode.width = number(values, "video.width", settings.graphics.mode.width);
  settings.graphics.mode.height = number(values, "video.height", settings.graphics.mode.height);
  settings.graphics.mode.refreshHz = number(values, "video.refresh_hz", settings.graphics.mode.refreshHz);
  settings.graphics.fullscreen = boolean(values, "video.fullscreen", settings.graphics.fullscreen);
  settings.graphics.vsync = boolean(values, "video.vsync", settings.graphics.vsync);
  settings.audio.sampleRate = number(values, "audio.sample_rate", settings.audio.sampleRate);
  settings.audio.channels = number(values, "audio.channels", settings.audio.channels);
  settings.audio.bufferFrames = number(values, "audio.buffer_frames", settings.audio.bufferFrames);
  for (auto& item : settings.emulators) {
    const auto prefix = "emulator." + item.first + ".";
    item.second.enabled = boolean(values, prefix + "enabled", item.second.enabled);
    item.second.executable = valueOf(values, prefix + "executable", pathString(item.second.executable));
    item.second.arguments = valueOf(values, prefix + "arguments", item.second.arguments);
    item.second.internalEnabled = boolean(values, prefix + "internal_enabled", item.second.internalEnabled);
    item.second.internalLibrary = valueOf(values, prefix + "internal_library", pathString(item.second.internalLibrary));
  }
  return true;
}

bool saveHostSettings(const ZHostSettings& settings, std::string* error) {
  const auto file = defaultSettingsPath();
  try {
    std::filesystem::create_directories(file.parent_path());
    std::ofstream output(file, std::ios::trunc);
    if (!output) { if (error) *error = "não foi possível gravar configurações: " + file.string(); return false; }
    output << "# ZConsole host settings 0.1\n";
    put(output, "system.directory", pathString(settings.systemDirectory));
    put(output, "storage.saves", pathString(settings.savesDirectory));
    put(output, "storage.cache", pathString(settings.cacheDirectory));
    put(output, "cpu.threads", std::to_string(settings.cpuThreads));
    put(output, "memory.mib", std::to_string(settings.memoryMiB));
    put(output, "network.enabled", settings.networkEnabled ? "true" : "false");
    put(output, "network.udp_port", std::to_string(settings.networkUdpPort));
    put(output, "input.keyboard_profile", settings.keyboardProfile);
    put(output, "input.controller_id", settings.controllerId);
    put(output, "emulation.prefer_internal", settings.preferInternalCores ? "true" : "false");
    put(output, "video.width", std::to_string(settings.graphics.mode.width));
    put(output, "video.height", std::to_string(settings.graphics.mode.height));
    put(output, "video.refresh_hz", std::to_string(settings.graphics.mode.refreshHz));
    put(output, "video.fullscreen", settings.graphics.fullscreen ? "true" : "false");
    put(output, "video.vsync", settings.graphics.vsync ? "true" : "false");
    put(output, "audio.sample_rate", std::to_string(settings.audio.sampleRate));
    put(output, "audio.channels", std::to_string(settings.audio.channels));
    put(output, "audio.buffer_frames", std::to_string(settings.audio.bufferFrames));
    for (const auto& item : settings.emulators) {
      const auto prefix = "emulator." + item.first + ".";
      put(output, prefix + "enabled", item.second.enabled ? "true" : "false");
      put(output, prefix + "executable", pathString(item.second.executable));
      put(output, prefix + "arguments", item.second.arguments);
      put(output, prefix + "internal_enabled", item.second.internalEnabled ? "true" : "false");
      put(output, prefix + "internal_library", pathString(item.second.internalLibrary));
    }
    return true;
  } catch (const std::exception& exception) {
    if (error) *error = std::string("falha ao salvar configurações: ") + exception.what();
    return false;
  }
}
} // namespace zconsole
