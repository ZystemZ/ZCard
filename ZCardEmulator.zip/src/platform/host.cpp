#include "zconsole/platform/host.hpp"
#include <chrono>
#include <thread>
namespace zconsole {
class SystemHost final: public ZHost {
public:
 void initialize() override {}
 void shutdown() override {}
 std::uint64_t getTimeUs() const override { return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count()); }
 void sleepMs(std::uint32_t ms) const override { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }
};
std::unique_ptr<ZHost> createHost(){return std::make_unique<SystemHost>();}
}
