#include "zconsole/emulator/vulkan_runtime.hpp"
#include "zconsole/emulator/sdl_runtime.hpp"
#include <algorithm>
#include <sstream>
#ifdef ZCONSOLE_HAS_VULKAN
#include <vulkan/vulkan.h>
#ifdef ZCONSOLE_HAS_SDL2
#include <SDL_vulkan.h>
#endif
#endif
namespace zconsole {
struct ZVulkanRuntime::Impl {
#ifdef ZCONSOLE_HAS_VULKAN
 VkInstance instance=VK_NULL_HANDLE;VkSurfaceKHR surface=VK_NULL_HANDLE;VkPhysicalDevice physical=VK_NULL_HANDLE;VkDevice device=VK_NULL_HANDLE;VkQueue graphicsQueue=VK_NULL_HANDLE,presentQueue=VK_NULL_HANDLE;VkSwapchainKHR swapchain=VK_NULL_HANDLE;std::vector<VkImage> images;std::vector<VkImageView> views;std::vector<VkFramebuffer> framebuffers;VkRenderPass renderPass=VK_NULL_HANDLE;VkCommandPool commandPool=VK_NULL_HANDLE;std::vector<VkCommandBuffer> commandBuffers;VkSemaphore imageAvailable=VK_NULL_HANDLE,renderFinished=VK_NULL_HANDLE;VkFence inFlight=VK_NULL_HANDLE;VkFormat format=VK_FORMAT_UNDEFINED;VkExtent2D extent{};std::vector<ZVulkanDeviceInfo> devices;std::uint32_t graphicsFamily=0;bool hasQueue=false;
#endif
};
ZVulkanRuntime::ZVulkanRuntime():impl_(std::make_unique<Impl>()){}ZVulkanRuntime::~ZVulkanRuntime(){shutdown();}
#ifdef ZCONSOLE_HAS_VULKAN
static bool enumerate(ZVulkanRuntime::Impl& i,std::string* e){std::uint32_t n=0;if(vkEnumeratePhysicalDevices(i.instance,&n,nullptr)!=VK_SUCCESS||!n){if(e)*e="nenhuma GPU Vulkan encontrada";return false;}std::vector<VkPhysicalDevice> ds(n);vkEnumeratePhysicalDevices(i.instance,&n,ds.data());for(auto d:ds){VkPhysicalDeviceProperties p{};vkGetPhysicalDeviceProperties(d,&p);ZVulkanDeviceInfo x;x.name=p.deviceName;x.vendorId=p.vendorID;x.deviceId=p.deviceID;x.apiMajor=VK_VERSION_MAJOR(p.apiVersion);x.apiMinor=VK_VERSION_MINOR(p.apiVersion);x.discrete=p.deviceType==VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU;i.devices.push_back(std::move(x));}return true;}
static bool choose(ZVulkanRuntime::Impl& i,std::string* e){std::uint32_t n=0;vkEnumeratePhysicalDevices(i.instance,&n,nullptr);std::vector<VkPhysicalDevice> ds(n);vkEnumeratePhysicalDevices(i.instance,&n,ds.data());for(auto d:ds){std::uint32_t qn=0;vkGetPhysicalDeviceQueueFamilyProperties(d,&qn,nullptr);std::vector<VkQueueFamilyProperties> q(qn);vkGetPhysicalDeviceQueueFamilyProperties(d,&qn,q.data());for(std::uint32_t k=0;k<qn;++k){VkBool32 present=VK_FALSE;vkGetPhysicalDeviceSurfaceSupportKHR(d,k,i.surface,&present);if((q[k].queueFlags&VK_QUEUE_GRAPHICS_BIT)&&present){i.physical=d;i.graphicsFamily=k;i.hasQueue=true;return true;}}}if(e)*e="GPU Vulkan sem fila gráfica/apresentação compatível";return false;}
static bool createDevice(ZVulkanRuntime::Impl& i,std::string* e){const float priority=1.0f;VkDeviceQueueCreateInfo q{};q.sType=VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;q.queueFamilyIndex=i.graphicsFamily;q.queueCount=1;q.pQueuePriorities=&priority;VkPhysicalDeviceFeatures features{};VkDeviceCreateInfo info{};info.sType=VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;info.pQueueCreateInfos=&q;info.queueCreateInfoCount=1;info.pEnabledFeatures=&features;const char* ext=VK_KHR_SWAPCHAIN_EXTENSION_NAME;info.enabledExtensionCount=1;info.ppEnabledExtensionNames=&ext;if(vkCreateDevice(i.physical,&info,nullptr,&i.device)!=VK_SUCCESS){if(e)*e="falha ao criar VkDevice";return false;}vkGetDeviceQueue(i.device,i.graphicsFamily,0,&i.graphicsQueue);i.presentQueue=i.graphicsQueue;return true;}
static bool createSwapchain(ZVulkanRuntime::Impl& i,std::string* e){VkSurfaceCapabilitiesKHR caps{};if(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(i.physical,i.surface,&caps)!=VK_SUCCESS){if(e)*e="falha ao consultar capacidades da surface";return false;}std::uint32_t fn=0;vkGetPhysicalDeviceSurfaceFormatsKHR(i.physical,i.surface,&fn,nullptr);if(!fn){if(e)*e="surface sem formatos Vulkan";return false;}std::vector<VkSurfaceFormatKHR> formats(fn);vkGetPhysicalDeviceSurfaceFormatsKHR(i.physical,i.surface,&fn,formats.data());auto chosen=formats[0];for(const auto& f:formats)if(f.format==VK_FORMAT_B8G8R8A8_SRGB)chosen=f;i.format=chosen.format;i.extent=caps.currentExtent;if(i.extent.width==UINT32_MAX)i.extent={std::clamp(1280u,caps.minImageExtent.width,caps.maxImageExtent.width),std::clamp(720u,caps.minImageExtent.height,caps.maxImageExtent.height)};auto count=caps.minImageCount+1;if(caps.maxImageCount&&count>caps.maxImageCount)count=caps.maxImageCount;VkSwapchainCreateInfoKHR info{};info.sType=VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;info.surface=i.surface;info.minImageCount=count;info.imageFormat=i.format;info.imageColorSpace=chosen.colorSpace;info.imageExtent=i.extent;info.imageArrayLayers=1;info.imageUsage=VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;info.imageSharingMode=VK_SHARING_MODE_EXCLUSIVE;info.preTransform=caps.currentTransform;info.compositeAlpha=VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;info.presentMode=VK_PRESENT_MODE_FIFO_KHR;info.clipped=VK_TRUE;if(vkCreateSwapchainKHR(i.device,&info,nullptr,&i.swapchain)!=VK_SUCCESS){if(e)*e="falha ao criar swapchain Vulkan";return false;}std::uint32_t imageCount=0;vkGetSwapchainImagesKHR(i.device,i.swapchain,&imageCount,nullptr);i.images.resize(imageCount);vkGetSwapchainImagesKHR(i.device,i.swapchain,&imageCount,i.images.data());for(auto image:i.images){VkImageViewCreateInfo view{};view.sType=VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;view.image=image;view.viewType=VK_IMAGE_VIEW_TYPE_2D;view.format=i.format;view.subresourceRange.aspectMask=VK_IMAGE_ASPECT_COLOR_BIT;view.subresourceRange.levelCount=1;view.subresourceRange.layerCount=1;VkImageView output;if(vkCreateImageView(i.device,&view,nullptr,&output)!=VK_SUCCESS){if(e)*e="falha ao criar image view Vulkan";return false;}i.views.push_back(output);}VkAttachmentDescription attachment{};attachment.format=i.format;attachment.samples=VK_SAMPLE_COUNT_1_BIT;attachment.loadOp=VK_ATTACHMENT_LOAD_OP_CLEAR;attachment.storeOp=VK_ATTACHMENT_STORE_OP_STORE;attachment.initialLayout=VK_IMAGE_LAYOUT_UNDEFINED;attachment.finalLayout=VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;VkAttachmentReference ref{};ref.attachment=0;ref.layout=VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;VkSubpassDescription sub{};sub.pipelineBindPoint=VK_PIPELINE_BIND_POINT_GRAPHICS;sub.colorAttachmentCount=1;sub.pColorAttachments=&ref;VkRenderPassCreateInfo rp{};rp.sType=VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO;rp.attachmentCount=1;rp.pAttachments=&attachment;rp.subpassCount=1;rp.pSubpasses=&sub;if(vkCreateRenderPass(i.device,&rp,nullptr,&i.renderPass)!=VK_SUCCESS){if(e)*e="falha ao criar render pass Vulkan";return false;}for(auto view:i.views){VkImageView attachments[]={view};VkFramebufferCreateInfo fb{};fb.sType=VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO;fb.renderPass=i.renderPass;fb.attachmentCount=1;fb.pAttachments=attachments;fb.width=i.extent.width;fb.height=i.extent.height;fb.layers=1;VkFramebuffer framebuffer;if(vkCreateFramebuffer(i.device,&fb,nullptr,&framebuffer)!=VK_SUCCESS){if(e)*e="falha ao criar framebuffer Vulkan";return false;}i.framebuffers.push_back(framebuffer);}VkCommandPoolCreateInfo pool{};pool.sType=VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;pool.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;pool.queueFamilyIndex=i.graphicsFamily;if(vkCreateCommandPool(i.device,&pool,nullptr,&i.commandPool)!=VK_SUCCESS){if(e)*e="falha ao criar command pool Vulkan";return false;}i.commandBuffers.resize(i.framebuffers.size());VkCommandBufferAllocateInfo alloc{};alloc.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;alloc.commandPool=i.commandPool;alloc.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;alloc.commandBufferCount=static_cast<std::uint32_t>(i.commandBuffers.size());if(vkAllocateCommandBuffers(i.device,&alloc,i.commandBuffers.data())!=VK_SUCCESS){if(e)*e="falha ao alocar command buffers Vulkan";return false;}VkSemaphoreCreateInfo sem{};sem.sType=VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;vkCreateSemaphore(i.device,&sem,nullptr,&i.imageAvailable);vkCreateSemaphore(i.device,&sem,nullptr,&i.renderFinished);VkFenceCreateInfo fence{};fence.sType=VK_STRUCTURE_TYPE_FENCE_CREATE_INFO;fence.flags=VK_FENCE_CREATE_SIGNALED_BIT;vkCreateFence(i.device,&fence,nullptr,&i.inFlight);return true;}
#endif
bool ZVulkanRuntime::initialize(bool,std::string* error){
#ifdef ZCONSOLE_HAS_VULKAN
 VkApplicationInfo app{};app.sType=VK_STRUCTURE_TYPE_APPLICATION_INFO;app.pApplicationName="ZConsole Runtime";app.pEngineName="ZConsole";app.apiVersion=VK_API_VERSION_1_1;VkInstanceCreateInfo info{};info.sType=VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;info.pApplicationInfo=&app;if(vkCreateInstance(&info,nullptr,&impl_->instance)!=VK_SUCCESS){if(error)*error="falha ao criar instance Vulkan";return false;}if(!enumerate(*impl_,error)){shutdown();return false;}initialized_=true;return true;
#else
 if(error)*error="Vulkan não disponível";
 return false;
#endif
}
bool ZVulkanRuntime::initializeForSdl(const ZSdlRuntime& sdl,bool,std::string* error){
#ifdef ZCONSOLE_HAS_VULKAN
 const auto names=sdl.requiredVulkanExtensions(error);if(names.empty())return false;std::vector<const char*> ext;for(const auto& n:names)ext.push_back(n.c_str());VkApplicationInfo app{};app.sType=VK_STRUCTURE_TYPE_APPLICATION_INFO;app.pApplicationName="ZConsole Runtime";app.pEngineName="ZConsole";app.apiVersion=VK_API_VERSION_1_1;VkInstanceCreateInfo info{};info.sType=VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;info.pApplicationInfo=&app;info.enabledExtensionCount=static_cast<std::uint32_t>(ext.size());info.ppEnabledExtensionNames=ext.data();if(vkCreateInstance(&info,nullptr,&impl_->instance)!=VK_SUCCESS){if(error)*error="falha ao criar instance Vulkan SDL2";return false;}if(!SDL_Vulkan_CreateSurface(static_cast<SDL_Window*>(sdl.nativeWindow()),impl_->instance,&impl_->surface)||!enumerate(*impl_,error)||!choose(*impl_,error)||!createDevice(*impl_,error)||!createSwapchain(*impl_,error)){if(error&&error->empty())*error="falha ao inicializar apresentação Vulkan";shutdown();return false;}initialized_=true;return true;
#else
 (void)sdl;if(error)*error="Vulkan ou SDL2 não disponível";return false;
#endif
}
std::vector<ZVulkanDeviceInfo>ZVulkanRuntime::devices()const{
#ifdef ZCONSOLE_HAS_VULKAN
 return impl_->devices;
#else
 return{};
#endif
}
bool ZVulkanRuntime::presentationReady()const{
#ifdef ZCONSOLE_HAS_VULKAN
 return impl_->swapchain&&impl_->renderPass&&!impl_->commandBuffers.empty();
#else
 return false;
#endif
}
bool ZVulkanRuntime::presentFrame(std::string* error){
#ifdef ZCONSOLE_HAS_VULKAN
 if(!presentationReady()){if(error)*error="apresentação Vulkan não inicializada";return false;}if(vkWaitForFences(impl_->device,1,&impl_->inFlight,VK_TRUE,UINT64_MAX)!=VK_SUCCESS)return false;vkResetFences(impl_->device,1,&impl_->inFlight);std::uint32_t index=0;const auto acquire=vkAcquireNextImageKHR(impl_->device,impl_->swapchain,UINT64_MAX,impl_->imageAvailable,VK_NULL_HANDLE,&index);if(acquire!=VK_SUCCESS&&acquire!=VK_SUBOPTIMAL_KHR){if(error)*error="falha ao adquirir imagem Vulkan";return false;}auto command=impl_->commandBuffers[index];vkResetCommandBuffer(command,0);VkCommandBufferBeginInfo begin{};begin.sType=VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;vkBeginCommandBuffer(command,&begin);VkClearValue clear{{0.03f,0.06f,0.12f,1.0f}};VkRenderPassBeginInfo rp{};rp.sType=VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;rp.renderPass=impl_->renderPass;rp.framebuffer=impl_->framebuffers[index];rp.renderArea.extent=impl_->extent;rp.clearValueCount=1;rp.pClearValues=&clear;vkCmdBeginRenderPass(command,&rp,VK_SUBPASS_CONTENTS_INLINE);vkCmdEndRenderPass(command);vkEndCommandBuffer(command);VkPipelineStageFlags waitStage=VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;VkSubmitInfo submit{};submit.sType=VK_STRUCTURE_TYPE_SUBMIT_INFO;submit.waitSemaphoreCount=1;submit.pWaitSemaphores=&impl_->imageAvailable;submit.pWaitDstStageMask=&waitStage;submit.commandBufferCount=1;submit.pCommandBuffers=&command;submit.signalSemaphoreCount=1;submit.pSignalSemaphores=&impl_->renderFinished;if(vkQueueSubmit(impl_->graphicsQueue,1,&submit,impl_->inFlight)!=VK_SUCCESS){if(error)*error="falha ao submeter frame Vulkan";return false;}VkPresentInfoKHR present{};present.sType=VK_STRUCTURE_TYPE_PRESENT_INFO_KHR;present.waitSemaphoreCount=1;present.pWaitSemaphores=&impl_->renderFinished;present.swapchainCount=1;present.pSwapchains=&impl_->swapchain;present.pImageIndices=&index;const auto result=vkQueuePresentKHR(impl_->presentQueue,&present);if(result!=VK_SUCCESS&&result!=VK_SUBOPTIMAL_KHR){if(error)*error="falha ao apresentar frame Vulkan";return false;}return true;
#else
 if(error)*error="Vulkan não disponível";
 return false;
#endif
}
std::string ZVulkanRuntime::diagnostics()const{std::ostringstream out;out<<"Vulkan initialized="<<(initialized_?"true":"false")<<" devices="<<devices().size();
#ifdef ZCONSOLE_HAS_VULKAN
 out<<" surface="<<(impl_->surface?"true":"false")<<" device="<<(impl_->device?"true":"false")<<" swapchain="<<(impl_->swapchain?"true":"false")<<" renderPass="<<(impl_->renderPass?"true":"false")<<" views="<<impl_->views.size();
#endif
 out<<"\n";for(const auto& d:devices())out<<"  "<<d.name<<" vendor="<<d.vendorId<<" device="<<d.deviceId<<" api="<<d.apiMajor<<"."<<d.apiMinor<<" discrete="<<(d.discrete?"yes":"no")<<"\n";return out.str();}
void ZVulkanRuntime::shutdown(){
#ifdef ZCONSOLE_HAS_VULKAN
 if(impl_->device){if(impl_->inFlight)vkDestroyFence(impl_->device,impl_->inFlight,nullptr);if(impl_->imageAvailable)vkDestroySemaphore(impl_->device,impl_->imageAvailable,nullptr);if(impl_->renderFinished)vkDestroySemaphore(impl_->device,impl_->renderFinished,nullptr);if(impl_->commandPool)vkDestroyCommandPool(impl_->device,impl_->commandPool,nullptr);for(auto f:impl_->framebuffers)vkDestroyFramebuffer(impl_->device,f,nullptr);if(impl_->renderPass)vkDestroyRenderPass(impl_->device,impl_->renderPass,nullptr);for(auto v:impl_->views)vkDestroyImageView(impl_->device,v,nullptr);if(impl_->swapchain)vkDestroySwapchainKHR(impl_->device,impl_->swapchain,nullptr);vkDestroyDevice(impl_->device,nullptr);}if(impl_->surface&&impl_->instance)vkDestroySurfaceKHR(impl_->instance,impl_->surface,nullptr);if(impl_->instance)vkDestroyInstance(impl_->instance,nullptr);impl_->devices.clear();
#endif
 initialized_=false;
}
}
