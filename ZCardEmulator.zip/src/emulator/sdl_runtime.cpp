#include "zconsole/emulator/sdl_runtime.hpp"
#include <cmath>
#include <vector>
#ifdef ZCONSOLE_HAS_SDL2
#include <SDL.h>
#include <SDL_vulkan.h>
#endif
namespace zconsole {
struct ZSdlRuntime::Impl {
#ifdef ZCONSOLE_HAS_SDL2
 SDL_Window* window=nullptr; SDL_Renderer* renderer=nullptr; SDL_Texture* texture=nullptr; SDL_AudioDeviceID audio=0; ZSdlConfig config{};
#endif
};
ZSdlRuntime::ZSdlRuntime():impl_(std::make_unique<Impl>()){}
ZSdlRuntime::~ZSdlRuntime(){shutdown();}
bool ZSdlRuntime::initialize(const ZSdlConfig& config,std::string* error){
#ifdef ZCONSOLE_HAS_SDL2
 impl_->config=config;if(SDL_Init(SDL_INIT_VIDEO|(config.audio?SDL_INIT_AUDIO:0))!=0){if(error)*error=SDL_GetError();return false;}impl_->window=SDL_CreateWindow("ZConsole Runtime",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,static_cast<int>(config.width),static_cast<int>(config.height),SDL_WINDOW_SHOWN|SDL_WINDOW_RESIZABLE);if(!impl_->window){if(error)*error=SDL_GetError();shutdown();return false;}impl_->renderer=SDL_CreateRenderer(impl_->window,-1,config.vsync?SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC:SDL_RENDERER_ACCELERATED);if(!impl_->renderer){if(error)*error=SDL_GetError();shutdown();return false;}impl_->texture=SDL_CreateTexture(impl_->renderer,SDL_PIXELFORMAT_RGBA32,SDL_TEXTUREACCESS_STREAMING,static_cast<int>(config.logicalWidth),static_cast<int>(config.logicalHeight));if(!impl_->texture){if(error)*error=SDL_GetError();shutdown();return false;}if(config.audio){SDL_AudioSpec want{};want.freq=48000;want.format=AUDIO_S16SYS;want.channels=1;want.samples=1024;impl_->audio=SDL_OpenAudioDevice(nullptr,0,&want,nullptr,0);if(!impl_->audio&&error)*error=SDL_GetError();else SDL_PauseAudioDevice(impl_->audio,0);}initialized_=true;return true;
#else
 (void)config;
 if(error)*error="SDL2 não disponível; instale SDL2 ou configure ZCONSOLE_SDL2=ON";
 return false;
#endif
}
bool ZSdlRuntime::pumpInput(ZConsoleInput& input,std::string* error){
#ifdef ZCONSOLE_HAS_SDL2
 if(!initialized_){if(error)*error="backend SDL2 não inicializado";return false;}SDL_Event event;while(SDL_PollEvent(&event)){if(event.type==SDL_QUIT)return false;if(event.type==SDL_KEYDOWN||event.type==SDL_KEYUP){const bool pressed=event.type==SDL_KEYDOWN;ZInputKey key;switch(event.key.keysym.sym){case SDLK_UP:key=ZInputKey::Up;break;case SDLK_DOWN:key=ZInputKey::Down;break;case SDLK_LEFT:key=ZInputKey::Left;break;case SDLK_RIGHT:key=ZInputKey::Right;break;case SDLK_SPACE:key=ZInputKey::Action;break;case SDLK_RETURN:key=ZInputKey::Start;break;default:continue;}input.push({key,pressed});}}return true;
#else
 (void)input;if(error)*error="SDL2 não disponível";return false;
#endif
}
bool ZSdlRuntime::present(const ZConsoleGraphics& graphics,std::string* error){
#ifdef ZCONSOLE_HAS_SDL2
 if(!initialized_){if(error)*error="backend SDL2 não inicializado";return false;}if(graphics.width()!=impl_->config.logicalWidth||graphics.height()!=impl_->config.logicalHeight){if(error)*error="dimensão do framebuffer incompatível com o backend SDL2";return false;}SDL_UpdateTexture(impl_->texture,nullptr,graphics.framebuffer().data(),static_cast<int>(graphics.width()*4));SDL_RenderClear(impl_->renderer);SDL_RenderCopy(impl_->renderer,impl_->texture,nullptr,nullptr);SDL_RenderPresent(impl_->renderer);return true;
#else
 (void)graphics;if(error)*error="SDL2 não disponível";return false;
#endif
}
std::vector<ZControllerInfo> ZSdlRuntime::controllers() const {
 std::vector<ZControllerInfo> result;
#ifdef ZCONSOLE_HAS_SDL2
 if(!initialized_)return result;
 for(int i=0;i<SDL_NumJoysticks();++i){SDL_Joystick* joystick=SDL_JoystickOpen(i);if(!joystick)continue;ZControllerInfo item;item.id=std::to_string(SDL_JoystickInstanceID(joystick));item.name=SDL_JoystickName(joystick)?SDL_JoystickName(joystick):"USB controller";item.family=ZControllerFamily::Unknown;item.buttons=static_cast<std::uint32_t>(SDL_JoystickNumButtons(joystick));item.axes=static_cast<std::uint32_t>(SDL_JoystickNumAxes(joystick));result.push_back(std::move(item));SDL_JoystickClose(joystick);}
#endif
 return result;
}
std::vector<std::string> ZSdlRuntime::requiredVulkanExtensions(std::string* error) const {
 std::vector<std::string> result;
#ifdef ZCONSOLE_HAS_SDL2
 if(!initialized_||!impl_->window){if(error)*error="janela SDL2 não inicializada";return result;}unsigned int count=0;if(!SDL_Vulkan_GetInstanceExtensions(impl_->window,&count,nullptr)){if(error)*error=SDL_GetError();return result;}std::vector<const char*> names(count);if(!SDL_Vulkan_GetInstanceExtensions(impl_->window,&count,names.data())){if(error)*error=SDL_GetError();return result;}for(const auto name:names)result.emplace_back(name);
#else
 if(error)*error="SDL2 não disponível";
#endif
 return result;
}
void* ZSdlRuntime::nativeWindow() const {
#ifdef ZCONSOLE_HAS_SDL2
 return impl_->window;
#else
 return nullptr;
#endif
}
bool ZSdlRuntime::playTone(const ZTone& tone,std::string* error){
#ifdef ZCONSOLE_HAS_SDL2
 if(!initialized_||!impl_->audio){if(error)*error="áudio SDL2 não inicializado";return false;}const int samples=static_cast<int>(48000ull*tone.durationMs/1000ull);std::vector<std::int16_t> pcm(static_cast<std::size_t>(samples));for(int i=0;i<samples;++i)pcm[static_cast<std::size_t>(i)]=static_cast<std::int16_t>(std::sin(6.28318530718*tone.frequency*i/48000.0)*10000);SDL_QueueAudio(impl_->audio,pcm.data(),static_cast<Uint32>(pcm.size()*sizeof(std::int16_t)));return true;
#else
 (void)tone;if(error)*error="SDL2 não disponível";return false;
#endif
}
void ZSdlRuntime::shutdown(){
#ifdef ZCONSOLE_HAS_SDL2
 if(impl_->audio){SDL_CloseAudioDevice(impl_->audio);impl_->audio=0;}if(impl_->texture){SDL_DestroyTexture(impl_->texture);impl_->texture=nullptr;}if(impl_->renderer){SDL_DestroyRenderer(impl_->renderer);impl_->renderer=nullptr;}if(impl_->window){SDL_DestroyWindow(impl_->window);impl_->window=nullptr;}if(initialized_)SDL_Quit();
#endif
 initialized_=false;
}
}
