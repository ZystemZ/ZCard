#include "zconsole/emulator/hardware.hpp"
#include <algorithm>
namespace zconsole {
ZConsoleGraphics::ZConsoleGraphics(std::uint32_t width,std::uint32_t height):width_(width),height_(height),pixels_(static_cast<std::size_t>(width)*height*4,0){clear({0,0,0,255});}
void ZConsoleGraphics::clear(ZColor c){for(std::size_t i=0;i<pixels_.size();i+=4){pixels_[i]=c.r;pixels_[i+1]=c.g;pixels_[i+2]=c.b;pixels_[i+3]=c.a;}}
void ZConsoleGraphics::fillRect(std::uint32_t x,std::uint32_t y,std::uint32_t w,std::uint32_t h,ZColor c){const auto x2=std::min(width_,x+w),y2=std::min(height_,y+h);for(std::uint32_t py=y;py<y2;++py)for(std::uint32_t px=x;px<x2;++px){const auto p=(static_cast<std::size_t>(py)*width_+px)*4;pixels_[p]=c.r;pixels_[p+1]=c.g;pixels_[p+2]=c.b;pixels_[p+3]=c.a;}}
void ZConsoleInput::push(ZInputEvent e){events_.push_back(e);auto it=std::find(down_.begin(),down_.end(),e.key);if(e.pressed){if(it==down_.end())down_.push_back(e.key);}else if(it!=down_.end())down_.erase(it);}
bool ZConsoleInput::poll(ZInputEvent& e){if(events_.empty())return false;e=events_.front();events_.pop_front();return true;}
bool ZConsoleInput::isDown(ZInputKey key)const{return std::find(down_.begin(),down_.end(),key)!=down_.end();}
void ZConsoleAudio::playTone(std::uint32_t frequency,std::uint32_t durationMs){tones_.push_back({frequency,durationMs});}
}
