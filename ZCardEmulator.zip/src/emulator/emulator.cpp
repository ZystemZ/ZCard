#include "zconsole/emulator/emulator.hpp"
#include "zconsole/platform/settings.hpp"
#include <cctype>
#include <chrono>
#include <fstream>
#include <initializer_list>
#include <iterator>

namespace zconsole {
namespace {
std::string manifestValue(const std::string& json, const std::string& key) {
  const auto p = json.find("\"" + key + "\"");
  if (p == std::string::npos) return {};
  const auto c = json.find(':', p);
  if (c == std::string::npos) return {};
  const auto q = json.find('"', c + 1);
  if (q == std::string::npos) return {};
  const auto r = json.find('"', q + 1);
  return r == std::string::npos ? std::string{} : json.substr(q + 1, r - q - 1);
}

bool manifestNumber(const std::string& json, const std::string& key, std::uint32_t& value) {
  const auto p = json.find("\"" + key + "\"");
  if (p == std::string::npos) return false;
  const auto c = json.find(':', p);
  if (c == std::string::npos) return false;
  std::size_t q = c + 1;
  while (q < json.size() && std::isspace(static_cast<unsigned char>(json[q]))) ++q;
  try {
    std::size_t end = 0;
    const auto n = std::stoul(json.substr(q), &end);
    if (end == 0) return false;
    value = static_cast<std::uint32_t>(n);
    return true;
  } catch (...) {
    return false;
  }
}

bool manifestHas(const std::string& json, const std::string& key) {
  return json.find("\"" + key + "\"") != std::string::npos;
}

bool oneOf(const std::string& value, std::initializer_list<const char*> choices) {
  for (const auto choice : choices) if (value == choice) return true;
  return false;
}

bool fail(std::string* error, const std::string& message) {
  if (error) *error = message;
  return false;
}

bool readCardText(const VirtualZCard& card, const std::string& path, std::string& result,
                  std::string* error) {
  auto stream = card.openStream(path, error);
  if (!stream) return false;
  result.resize(static_cast<std::size_t>(stream->size()));
  if (stream->read(result.data(), result.size()) != result.size())
    return fail(error, "arquivo truncado: " + path);
  return true;
}
}

ZConsoleEmulator::ZConsoleEmulator() : host_(createHost()) {}

ZConsoleEmulator::~ZConsoleEmulator() {
  shutdown();
  if (!romTempRoot_.empty()) {
    std::error_code ignored;
    std::filesystem::remove_all(romTempRoot_, ignored);
  }
}

bool ZConsoleEmulator::loadCard(const std::filesystem::path& path, std::string* error) {
  shutdown();
  internalCore_.close();
  if (!romTempRoot_.empty()) {
    std::error_code ignored;
    std::filesystem::remove_all(romTempRoot_, ignored);
    romTempRoot_.clear();
  }
  card_ = std::make_unique<VirtualZCard>(path);
  booted_ = false;
  executionKind_ = CardExecutionKind::Unknown;
  romPlan_ = {};
  loadedExecutable_.clear();
  if (!card_->mount(error)) {
    lastError_ = error ? *error : "falha ao montar cartão";
    card_.reset();
    return false;
  }
  return true;
}

bool ZConsoleEmulator::boot(std::string* error) {
  if (error) error->clear();
  if (!card_) return fail(error, "nenhum cartão carregado");
  host_->initialize();
  if (!card_->verify(error)) {
    lastError_ = error ? *error : "falha na verificação";
    return false;
  }

  std::string manifest;
  std::string manifestError;
  const bool hasZgame = readCardText(*card_, "META/zgame.json", manifest, &manifestError);
  if (hasZgame) {
    const auto format = manifestValue(manifest, "format");
    const auto platform = manifestValue(manifest, "platform");

    if (format == "zgame-native-0.1" || format == "zgame-native-0.2" || platform == "windows-x64") {
      guestPolicy_ = {};
      guestPolicy_.platform = platform;
      guestPolicy_.architecture = manifestValue(manifest, "architecture");
      guestPolicy_.binaryFormat = manifestValue(manifest, "binary_format");
      guestPolicy_.abi = manifestValue(manifest, "abi");
      guestPolicy_.hostWorkers = manifestValue(manifest, "host_workers");
      guestPolicy_.threadPolicy = manifestValue(manifest, "thread_policy");
      if (format == "zgame-native-0.2") {
        std::uint32_t visibleProcessors = 0;
        if (!oneOf(platform, {"windows", "linux"}) ||
            !oneOf(guestPolicy_.architecture, {"x86", "x86_64", "arm32", "arm64"}) ||
            guestPolicy_.binaryFormat.empty() || guestPolicy_.abi.empty() ||
            !manifestNumber(manifest, "visible_processors", visibleProcessors) || visibleProcessors == 0 ||
            !oneOf(guestPolicy_.hostWorkers, {"automatic", "fixed"}) ||
            !oneOf(guestPolicy_.threadPolicy, {"parallel_guest", "serialized_guest_parallel_host", "deterministic"}))
          return fail(error, "manifesto nativo inválido: arquitetura, ABI, CPUs ou política de threads");
        if (guestPolicy_.architecture == "x86" || guestPolicy_.architecture == "arm32") {
          if (visibleProcessors != 1) return fail(error, "programas 32-bit devem enxergar exatamente uma vCPU");
        } else if (visibleProcessors < 1) {
          return fail(error, "programas 64-bit precisam de ao menos uma vCPU");
        }
        guestPolicy_.visibleProcessors = visibleProcessors;
      } else {
        guestPolicy_.platform = platform == "windows-x64" ? "windows" : platform;
        guestPolicy_.architecture = platform == "windows-x64" ? "x86_64" : guestPolicy_.architecture;
        guestPolicy_.visibleProcessors = 1;
      }
      executionKind_ = CardExecutionKind::NativeWindows;
      title_ = manifestValue(manifest, "title");
      bootScene_ = manifestValue(manifest, "boot_scene");
      running_ = true;
      booted_ = true;
      lastError_.clear();
      return true;
    }

    if (format != "zgame-0.1" || platform != "zconsole-v1" ||
        !manifestHas(manifest, "title") || !manifestHas(manifest, "boot_scene") ||
        !manifestHas(manifest, "entrypoint") || !manifestHas(manifest, "memory_required"))
      return fail(error, "manifesto inválido: campos obrigatórios ausentes ou incompatíveis");

    title_ = manifestValue(manifest, "title");
    bootScene_ = manifestValue(manifest, "boot_scene");
    const auto executable = manifestValue(manifest, "executable");
    std::uint32_t manifestEntry = 0, manifestMemory = 0;
    if (executable.empty() || executable.find("..") != std::string::npos ||
        !manifestNumber(manifest, "entrypoint", manifestEntry) ||
        !manifestNumber(manifest, "memory_required", manifestMemory))
      return fail(error, "manifesto inválido: executable, entrypoint ou memory_required");

    auto exeStream = card_->openStream(executable, error);
    if (!exeStream) return false;
    loadedExecutable_.resize(static_cast<std::size_t>(exeStream->size()));
    if (exeStream->read(loadedExecutable_.data(), loadedExecutable_.size()) != loadedExecutable_.size())
      return fail(error, "ZEXE truncado");
    if (!ZExecutableLoader::load(loadedExecutable_, console_, &executable_, error)) return false;
    if (manifestEntry != executable_.entryPoint || manifestMemory < executable_.memoryRequired)
      return fail(error, "manifesto incompatível com ZEXE: entrypoint ou memória");

    executionKind_ = CardExecutionKind::Zexe;
    console_.setRunning(true);
    std::string cpuError;
    console_.cpu().run(100000, &cpuError);
    if (!cpuError.empty()) return fail(error, cpuError);
    running_ = true;
    booted_ = true;
    lastError_.clear();
    return true;
  }

  // ROM/ISO cards are filesystem payloads, not ZEXE programs. They use the
  // resolver already shared by the CLI and deliberately do not start a host
  // process or a Windows mount from inside the emulator.
  std::string romManifest;
  if (!readCardText(*card_, "META/rom-runtime.json", romManifest, &manifestError))
    return fail(error, "cartão não reconhecido: esperados META/zgame.json ou META/rom-runtime.json");
  const auto rom = manifestValue(romManifest, "rom");
  if (rom.empty()) return fail(error, "manifesto ROM inválido: campo rom ausente");
  std::filesystem::path romRoot = card_->root();
  if (!std::filesystem::is_directory(romRoot)) {
    const auto stamp = std::chrono::high_resolution_clock::now().time_since_epoch().count();
    romTempRoot_ = std::filesystem::temp_directory_path() / ("zconsole-rom-" + std::to_string(stamp));
    const auto tempRom = romTempRoot_ / rom;
    const auto tempManifest = romTempRoot_ / "META" / "rom-runtime.json";
    std::error_code filesystemError;
    std::filesystem::create_directories(tempRom.parent_path(), filesystemError);
    if (!filesystemError) std::filesystem::create_directories(tempManifest.parent_path(), filesystemError);
    if (filesystemError) return fail(error, "não foi possível criar diretório temporário da ROM: " + filesystemError.message());
    std::ofstream manifestFile(tempManifest, std::ios::binary);
    manifestFile.write(romManifest.data(), static_cast<std::streamsize>(romManifest.size()));
    manifestFile.close();
    if (!manifestFile) return fail(error, "não foi possível preparar o manifesto ROM temporário");
    auto romStream = card_->openStream(rom, error);
    if (!romStream) return false;
    std::ofstream romFile(tempRom, std::ios::binary);
    if (!romFile) return fail(error, "não foi possível extrair a ROM para o filesystem temporário");
    std::vector<std::uint8_t> chunk(1024 * 1024);
    std::uint64_t remaining = romStream->size();
    while (remaining > 0) {
      const auto wanted = static_cast<std::size_t>(std::min<std::uint64_t>(remaining, chunk.size()));
      if (romStream->read(chunk.data(), wanted) != wanted) return fail(error, "ROM empacotada truncada");
      romFile.write(reinterpret_cast<const char*>(chunk.data()), static_cast<std::streamsize>(wanted));
      if (!romFile) return fail(error, "falha ao extrair a ROM empacotada");
      remaining -= wanted;
    }
    romFile.close();
    romRoot = romTempRoot_;
  }
  if (!resolveRomRuntime(romRoot, rom, romPlan_, error)) return false;

  ZHostSettings hostSettings;
  if (!loadHostSettings(hostSettings, error)) return false;
  const auto configured = hostSettings.emulators.find(romPlan_.system);
  const bool internalConfigured = configured != hostSettings.emulators.end() && configured->second.internalEnabled &&
                                  !configured->second.internalLibrary.empty();
  if (!internalConfigured && configured != hostSettings.emulators.end() && configured->second.enabled &&
      !configured->second.executable.empty()) {
    romPlan_.backend = RomBackendKind::ExternalProcess;
    romPlan_.command = configured->second.executable;
    romPlan_.arguments = {configured->second.arguments};
    if (!launchExternalRom(romPlan_, error)) return false;
    romPlan_.message = "ROM iniciada no emulador externo configurado: " + romPlan_.command.string();
  }
  if (internalConfigured) {
    std::string coreError;
    if (!internalCore_.open(configured->second.internalLibrary, &coreError) ||
        !internalCore_.loadRom(romPlan_.romPath, &coreError)) {
      internalCore_.close();
      romPlan_.backend = RomBackendKind::Unavailable;
      romPlan_.message = "ROM reconhecida, mas o core interno não pôde carregá-la: " + coreError;
      if (configured != hostSettings.emulators.end() && configured->second.enabled &&
          !configured->second.executable.empty()) {
        RomLaunchPlan externalPlan = romPlan_;
        externalPlan.backend = RomBackendKind::ExternalProcess;
        externalPlan.command = configured->second.executable;
        externalPlan.arguments = {configured->second.arguments};
        std::string externalError;
        if (launchExternalRom(externalPlan, &externalError)) {
          romPlan_ = std::move(externalPlan);
          romPlan_.message = "ROM iniciada no emulador externo configurado: " + romPlan_.command.string();
        }
      }
    } else {
      romPlan_.backend = RomBackendKind::InternalCore;
      romPlan_.message = "ROM carregada no núcleo libretro interno: " + configured->second.internalLibrary.string();
      executionKind_ = CardExecutionKind::RomInternalCore;
      if (!internalCore_.runFrame(error)) return false;
      running_ = true;
      booted_ = true;
      lastError_.clear();
      return true;
    }
  }

  if (romPlan_.backend == RomBackendKind::InternalCore) {
    romPlan_.backend = RomBackendKind::Unavailable;
    romPlan_.message = "ROM reconhecida, mas o manifesto solicita núcleo interno e nenhuma biblioteca foi configurada";
  }

  title_ = "ROM " + romPlan_.system;
  bootScene_ = "rom-runtime";
  switch (romPlan_.backend) {
    case RomBackendKind::InternalCore: executionKind_ = CardExecutionKind::RomInternalCore; break;
    case RomBackendKind::ExternalProcess: executionKind_ = CardExecutionKind::RomExternalProcess; break;
    case RomBackendKind::WindowsMount: executionKind_ = CardExecutionKind::RomWindowsMount; break;
    case RomBackendKind::Unavailable: executionKind_ = CardExecutionKind::RomNoBackend; break;
  }
  running_ = executionKind_ != CardExecutionKind::RomNoBackend;
  booted_ = true;
  lastError_ = executionKind_ == CardExecutionKind::RomNoBackend ? romPlan_.message : std::string{};
  return true;
}

bool ZConsoleEmulator::pause(std::string* error) {
  if (error) error->clear();
  if (!running_) return fail(error, "emulador não está em execução");
  if (!hasCpuProgram()) return fail(error, "este cartão não possui CPU ZEXE; use o backend indicado no plano");
  console_.cpu().pause();
  return true;
}

bool ZConsoleEmulator::resume(std::string* error) {
  if (error) error->clear();
  if (!running_) return fail(error, "emulador não está em execução");
  if (!hasCpuProgram()) return fail(error, "este cartão não possui CPU ZEXE; use o backend indicado no plano");
  console_.cpu().resume();
  console_.setRunning(true);
  return true;
}

bool ZConsoleEmulator::reset(std::string* error) {
  if (error) error->clear();
  if (!hasCpuProgram() || loadedExecutable_.empty())
    return fail(error, "nenhum ZEXE carregado; o cartão está apenas roteado ao backend");
  console_.reset();
  if (!ZExecutableLoader::load(loadedExecutable_, console_, &executable_, error)) return false;
  console_.setRunning(true);
  running_ = true;
  return true;
}

bool ZConsoleEmulator::runInstructions(std::size_t count, std::string* error) {
  if (error) error->clear();
  if (!running_) return fail(error, "emulador não está em execução");
  if (executionKind_ == CardExecutionKind::RomInternalCore) {
    for (std::size_t frame = 0; frame < count; ++frame) if (!internalCore_.runFrame(error)) return false;
    return true;
  }
  if (!hasCpuProgram()) return fail(error, "este cartão não possui CPU ZEXE; use o backend indicado no plano");
  console_.cpu().run(count, error);
  return error == nullptr || error->empty();
}

bool ZConsoleEmulator::runOneInstruction(std::string* error) { return runInstructions(1, error); }

void ZConsoleEmulator::shutdown() {
  console_.setRunning(false);
  internalCore_.unload();
  if (running_) host_->shutdown();
  running_ = false;
  booted_ = false;
  executionKind_ = CardExecutionKind::Unknown;
}
}
