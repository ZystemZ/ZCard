#include "zconsole/zcard/zhs_dispatcher.hpp"
#include <algorithm>
#include <limits>

namespace zconsole {
namespace {
void put16(std::vector<std::uint8_t>& out, std::uint16_t value) {
  out.push_back(static_cast<std::uint8_t>(value));
  out.push_back(static_cast<std::uint8_t>(value >> 8));
}
void put32(std::vector<std::uint8_t>& out, std::uint32_t value) {
  for (unsigned i = 0; i < 4; ++i) out.push_back(static_cast<std::uint8_t>(value >> (8 * i)));
}
void put64(std::vector<std::uint8_t>& out, std::uint64_t value) {
  for (unsigned i = 0; i < 8; ++i) out.push_back(static_cast<std::uint8_t>(value >> (8 * i)));
}
void putString(std::vector<std::uint8_t>& out, const std::string& value) {
  const auto size = static_cast<std::uint16_t>(std::min<std::size_t>(value.size(), 65535));
  put16(out, size);
  out.insert(out.end(), value.begin(), value.begin() + size);
}
ZhsFrame responseFor(const ZhsFrame& request, ZhsStatus status) {
  ZhsFrame response;
  response.command = request.command;
  response.flags = static_cast<std::uint16_t>(status);
  response.requestId = request.requestId;
  response.offset = request.offset;
  return response;
}
ZhsStatus statusForError(const std::string& error) {
  if (error.find("limites") != std::string::npos) return ZhsStatus::InvalidRange;
  if (error.find("somente leitura") != std::string::npos) return ZhsStatus::ReadOnly;
  if (error.find("integr") != std::string::npos || error.find("CRC") != std::string::npos)
    return ZhsStatus::IntegrityError;
  return ZhsStatus::IoError;
}
}

std::vector<std::uint8_t> ZhsDispatcher::handle(const std::vector<std::uint8_t>& request,
                                                 std::string* error) {
  ZhsFrame decoded;
  std::string decodeError;
  if (!decodeZhsFrame(request, decoded, &decodeError)) {
    if (error) *error = decodeError;
    ZhsFrame response;
    response.command = ZhsCommand::GetStatus;
    response.flags = static_cast<std::uint16_t>(
        decodeError.find("versão") != std::string::npos ? ZhsStatus::UnsupportedVersion
                                                          : ZhsStatus::InvalidFrame);
    return encodeZhsFrame(response);
  }

  ZhsFrame response = responseFor(decoded, ZhsStatus::Ok);
  std::string operationError;
  switch (decoded.command) {
    case ZhsCommand::GetInfo: {
      if (!device_.isOpen() && !device_.open(&operationError)) {
        response.flags = static_cast<std::uint16_t>(statusForError(operationError));
        break;
      }
      const auto info = device_.info();
      if (!info.present) {
        response.flags = static_cast<std::uint16_t>(ZhsStatus::NotPresent);
        break;
      }
      putString(response.payload, info.deviceId);
      putString(response.payload, info.firmwareVersion);
      put64(response.payload, info.capacity);
      put32(response.payload, info.blockSize);
      response.payload.push_back(info.present ? 1 : 0);
      response.payload.push_back(info.readOnly ? 1 : 0);
      response.payload.push_back(info.masterLocked ? 1 : 0);
      break;
    }
    case ZhsCommand::Read: {
      if (!device_.isOpen() && !device_.open(&operationError)) {
        response.flags = static_cast<std::uint16_t>(statusForError(operationError));
        break;
      }
      response.payload.assign(decoded.payload.size(), 0);
      if (!device_.read(decoded.offset, response.payload, &operationError))
        response.flags = static_cast<std::uint16_t>(statusForError(operationError));
      break;
    }
    case ZhsCommand::Verify:
      if (!device_.isOpen() && !device_.open(&operationError)) {
        response.flags = static_cast<std::uint16_t>(statusForError(operationError));
        break;
      }
      if (!device_.verify(&operationError))
        response.flags = static_cast<std::uint16_t>(statusForError(operationError));
      break;
    case ZhsCommand::GetStatus: {
      const auto info = device_.info();
      response.payload = {static_cast<std::uint8_t>(device_.isOpen()),
                          static_cast<std::uint8_t>(info.present),
                          static_cast<std::uint8_t>(info.readOnly),
                          static_cast<std::uint8_t>(info.masterLocked)};
      break;
    }
    default:
      response.flags = static_cast<std::uint16_t>(ZhsStatus::InvalidCommand);
      break;
  }
  if (!operationError.empty() && error) *error = operationError;
  return encodeZhsFrame(response);
}

} // namespace zconsole
