#include "zconsole/zcard/zhs_device.hpp"
#include "zconsole/zcard/zcf_hash.hpp"
#include <algorithm>
#include <cstring>

namespace zconsole {
namespace {
constexpr std::size_t HeaderSize = 20; // 2+1+1+2+2+8+4
constexpr std::size_t CrcSize = 4;
constexpr std::uint32_t MaxPayload = 1024U * 1024U;

void put16(std::vector<std::uint8_t>& out, std::uint16_t value) {
  out.push_back(static_cast<std::uint8_t>(value));
  out.push_back(static_cast<std::uint8_t>(value >> 8));
}
void put32(std::vector<std::uint8_t>& out, std::uint32_t value) {
  for (unsigned i = 0; i < 4; ++i) out.push_back(static_cast<std::uint8_t>(value >> (8 * i)));
}
void put64(std::vector<std::uint8_t>& out, std::uint64_t value) {
  for (unsigned i = 0; i < 8; ++i) out.push_back(static_cast<std::uint8_t>(value >> (8 * i)));
}
std::uint16_t get16(const std::uint8_t* p) {
  return static_cast<std::uint16_t>(p[0]) | (static_cast<std::uint16_t>(p[1]) << 8);
}
std::uint32_t get32(const std::uint8_t* p) {
  std::uint32_t value = 0;
  for (unsigned i = 0; i < 4; ++i) value |= static_cast<std::uint32_t>(p[i]) << (8 * i);
  return value;
}
std::uint64_t get64(const std::uint8_t* p) {
  std::uint64_t value = 0;
  for (unsigned i = 0; i < 8; ++i) value |= static_cast<std::uint64_t>(p[i]) << (8 * i);
  return value;
}
void setError(std::string* error, const std::string& value) { if (error) *error = value; }
}

std::uint32_t zhsCrc32(const std::uint8_t* data, std::size_t size) {
  std::uint32_t crc = 0xFFFFFFFFU;
  for (std::size_t i = 0; i < size; ++i) {
    crc ^= data[i];
    for (unsigned bit = 0; bit < 8; ++bit)
      crc = (crc & 1U) ? ((crc >> 1) ^ 0xEDB88320U) : (crc >> 1);
  }
  return ~crc;
}

std::vector<std::uint8_t> encodeZhsFrame(const ZhsFrame& frame) {
  if (frame.payload.size() > MaxPayload) return {};
  std::vector<std::uint8_t> result;
  result.reserve(HeaderSize + frame.payload.size() + CrcSize);
  put16(result, ZhsFrame::Magic);
  result.push_back(ZhsFrame::Version);
  result.push_back(static_cast<std::uint8_t>(frame.command));
  put16(result, frame.flags);
  put16(result, frame.requestId);
  put64(result, frame.offset);
  put32(result, static_cast<std::uint32_t>(frame.payload.size()));
  result.insert(result.end(), frame.payload.begin(), frame.payload.end());
  put32(result, zhsCrc32(result.data(), result.size()));
  return result;
}

bool decodeZhsFrame(const std::vector<std::uint8_t>& bytes, ZhsFrame& frame,
                    std::string* error) {
  if (bytes.size() < HeaderSize + CrcSize) {
    setError(error, "quadro ZHS menor que o cabeçalho mínimo"); return false;
  }
  if (get16(bytes.data()) != ZhsFrame::Magic) {
    setError(error, "magic ZHS inválido"); return false;
  }
  if (bytes[2] != ZhsFrame::Version) {
    setError(error, "versão ZHS não suportada"); return false;
  }
  const std::uint32_t length = get32(bytes.data() + 16);
  if (length > MaxPayload || bytes.size() != HeaderSize + length + CrcSize) {
    setError(error, "tamanho de payload ZHS inválido"); return false;
  }
  const std::uint32_t expected = get32(bytes.data() + HeaderSize + length);
  const std::uint32_t actual = zhsCrc32(bytes.data(), HeaderSize + length);
  if (expected != actual) {
    setError(error, "CRC32 do quadro ZHS divergente"); return false;
  }
  frame.command = static_cast<ZhsCommand>(bytes[3]);
  frame.flags = get16(bytes.data() + 4);
  frame.requestId = get16(bytes.data() + 6);
  frame.offset = get64(bytes.data() + 8);
  frame.payload.assign(bytes.begin() + HeaderSize, bytes.begin() + HeaderSize + length);
  return true;
}

ZhsMemoryDevice::ZhsMemoryDevice(std::vector<std::uint8_t> image, std::string deviceId)
    : image_(std::move(image)), deviceId_(std::move(deviceId)) {}

bool ZhsMemoryDevice::open(std::string* error) {
  if (image_.empty()) { setError(error, "imagem ZHS vazia"); return false; }
  open_ = true;
  return true;
}
void ZhsMemoryDevice::close() { open_ = false; }
ZhsDeviceInfo ZhsMemoryDevice::info() const {
  ZhsDeviceInfo result;
  result.deviceId = deviceId_;
  result.firmwareVersion = "sim-0.1";
  result.capacity = image_.size();
  result.present = !image_.empty();
  result.readOnly = true;
  result.masterLocked = true;
  return result;
}
bool ZhsMemoryDevice::read(std::uint64_t offset, std::vector<std::uint8_t>& data,
                           std::string* error) {
  if (!open_) { setError(error, "dispositivo ZHS não está aberto"); return false; }
  if (offset > image_.size() || data.size() > image_.size() - offset) {
    setError(error, "leitura ZHS fora dos limites"); return false;
  }
  std::copy(image_.begin() + static_cast<std::ptrdiff_t>(offset),
            image_.begin() + static_cast<std::ptrdiff_t>(offset + data.size()), data.begin());
  return true;
}
bool ZhsMemoryDevice::verify(std::string* error) {
  if (!open_) { setError(error, "dispositivo ZHS não está aberto"); return false; }
  if (image_.empty()) { setError(error, "imagem ZHS vazia"); return false; }
  return true;
}
bool ZhsMemoryDevice::write(std::uint64_t, const std::vector<std::uint8_t>&,
                            std::string* error) {
  setError(error, "dispositivo ZHS em modo somente leitura");
  return false;
}
std::unique_ptr<ZhsDevice> createZhsMemoryDevice(std::vector<std::uint8_t> image) {
  return std::make_unique<ZhsMemoryDevice>(std::move(image));
}

} // namespace zconsole
