#include "zconsole/runtime/rom_runtime.hpp"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <iterator>
#include <sstream>
#ifdef _WIN32
#include <windows.h>
#endif

namespace zconsole {
namespace {
std::string readText(const std::filesystem::path& path) {
  std::ifstream input(path);
  return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}
std::string jsonString(const std::string& json, const std::string& key) {
  const auto p = json.find("\"" + key + "\"");
  if (p == std::string::npos) return {};
  const auto colon = json.find(':', p);
  const auto first = json.find('"', colon == std::string::npos ? p : colon + 1);
  if (first == std::string::npos) return {};
  const auto last = json.find('"', first + 1);
  return last == std::string::npos ? std::string{} : json.substr(first + 1, last - first - 1);
}
bool jsonBool(const std::string& json, const std::string& key, bool fallback) {
  const auto p = json.find("\"" + key + "\"");
  if (p == std::string::npos) return fallback;
  const auto colon = json.find(':', p);
  const auto value = json.substr(colon + 1, 8);
  if (value.find("true") != std::string::npos) return true;
  if (value.find("false") != std::string::npos) return false;
  return fallback;
}
bool sectionEnabled(const std::string& json, const std::string& section) {
  const auto p = json.find("\"" + section + "\"");
  if (p == std::string::npos) return false;
  const auto end = json.find('}', p);
  return jsonBool(json.substr(p, end == std::string::npos ? std::string::npos : end - p + 1), "enabled", false);
}
std::string lower(std::string value) {
  std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
  return value;
}
std::string inferredSystem(const std::filesystem::path& path) {
  const auto ext = lower(path.extension().string());
  if (ext == ".gba") return "gba";
  if (ext == ".nes") return "nes";
  if (ext == ".sfc" || ext == ".smc") return "snes";
  if (ext == ".gb" || ext == ".gbc") return "gameboy";
  if (ext == ".n64") return "n64";
  if (ext == ".iso" || ext == ".bin" || ext == ".cue" || ext == ".chd") return "disc";
  return {};
}
void fail(std::string* error, const std::string& message) { if (error) *error = message; }
}

bool resolveRomRuntime(const std::filesystem::path& cardRoot,
                      const std::filesystem::path& romPath,
                      RomLaunchPlan& plan,
                      std::string* error) {
  plan = {};
  const auto relative = romPath.generic_string();
  if (relative.empty() || romPath.is_absolute() || relative.find("..") != std::string::npos) {
    fail(error, "caminho de ROM inválido"); return false;
  }
  plan.romPath = cardRoot / romPath;
  if (!std::filesystem::is_regular_file(plan.romPath)) {
    fail(error, "ROM ausente: " + plan.romPath.string()); return false;
  }
  const auto configPath = cardRoot / "META" / "rom-runtime.json";
  const auto config = std::filesystem::is_regular_file(configPath) ? readText(configPath) : std::string{};
  plan.system = jsonString(config, "system");
  if (plan.system.empty()) plan.system = inferredSystem(romPath);
  if (plan.system.empty()) {
    fail(error, "formato de ROM não reconhecido: " + romPath.extension().string()); return false;
  }

  plan.command = jsonString(config, "command");
  if (plan.command.empty()) plan.command = jsonString(config, "external_command");
  plan.internalCore = jsonString(config, "core");
  if (plan.internalCore.empty()) plan.internalCore = plan.system;
  plan.mountMode = jsonString(config, "mode");
  plan.backend = RomBackendKind::Unavailable;

  if (plan.system == "pc" && jsonBool(config, "mount_enabled", sectionEnabled(config, "mount"))) {
    plan.backend = RomBackendKind::WindowsMount;
    if (plan.mountMode.empty()) plan.mountMode = "windows";
    plan.message = "ISO de PC preparada para montagem no Windows";
    return true;
  }

  // Internal cores take precedence. The emulator must register the core before
  // this plan can be executed; resolution itself never starts a process.
  if (jsonBool(config, "internal_enabled", sectionEnabled(config, "internal")) && !plan.internalCore.empty()) {
    plan.backend = RomBackendKind::InternalCore;
    plan.message = "ROM encaminhada ao núcleo interno: " + plan.internalCore;
    return true;
  }
  if (jsonBool(config, "external_enabled", sectionEnabled(config, "external")) && !plan.command.empty()) {
    plan.backend = RomBackendKind::ExternalProcess;
    plan.message = "ROM encaminhada ao backend externo configurado";
    plan.arguments.push_back(plan.romPath.string());
    return true;
  }
  plan.backend = RomBackendKind::Unavailable;
  plan.message = "ROM reconhecida, mas nenhum backend foi configurado para " + plan.system;
  return true;
}

const char* toString(RomBackendKind backend) {
  switch (backend) {
    case RomBackendKind::InternalCore: return "internal-core";
    case RomBackendKind::ExternalProcess: return "external-process";
    case RomBackendKind::WindowsMount: return "windows-mount";
    case RomBackendKind::Unavailable: return "unavailable";
  }
  return "unknown";
}

bool prepareExternalRomInvocation(const RomLaunchPlan& plan,
                                  RomProcessInvocation& invocation,
                                  std::string* error) {
  invocation = {};
  if (plan.backend != RomBackendKind::ExternalProcess) {
    fail(error, "o plano de ROM não é um processo externo");
    return false;
  }
  if (plan.command.empty()) {
    fail(error, "backend externo sem executável configurado");
    return false;
  }
  if (plan.command.has_parent_path() && !std::filesystem::is_regular_file(plan.command)) {
    fail(error, "executável externo não existe: " + plan.command.string());
    return false;
  }
  invocation.executable = plan.command;
  const auto rom = plan.romPath.string();
  for (const auto& argument : plan.arguments) {
    std::string expanded = argument;
    std::size_t position = 0;
    while ((position = expanded.find("{rom}", position)) != std::string::npos) {
      expanded.replace(position, 5, rom);
      position += rom.size();
    }
    invocation.arguments.push_back(std::move(expanded));
  }
  if (invocation.arguments.empty()) invocation.arguments.push_back(rom);
  return true;
}

bool launchExternalRom(const RomLaunchPlan& plan, std::string* error) {
  RomProcessInvocation invocation;
  if (!prepareExternalRomInvocation(plan, invocation, error)) return false;
#ifdef _WIN32
  std::string command = "\"" + invocation.executable.string() + "\"";
  for (const auto& argument : invocation.arguments) {
    command += " \"" + argument + "\"";
  }
  STARTUPINFOA startup{};
  startup.cb = sizeof(startup);
  PROCESS_INFORMATION process{};
  std::vector<char> commandLine(command.begin(), command.end());
  commandLine.push_back('\0');
  if (!CreateProcessA(nullptr, commandLine.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr,
                      &startup, &process)) {
    fail(error, "falha ao iniciar emulador externo; código Win32: " + std::to_string(GetLastError()));
    return false;
  }
  CloseHandle(process.hThread);
  CloseHandle(process.hProcess);
  return true;
#else
  fail(error, "inicialização de emulador externo está disponível nesta versão somente no host Windows");
  return false;
#endif
}

} // namespace zconsole
