#include "zconsole/runtime/libretro_core.hpp"
#include <algorithm>
#include <cstring>
#include <fstream>
#include <iterator>
#include <sstream>
#ifdef _WIN32
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace zconsole {
namespace {
constexpr unsigned kEnvGetSystemDirectory = 9;
constexpr unsigned kEnvSetPixelFormat = 10;
constexpr unsigned kEnvGetSaveDirectory = 31;
constexpr unsigned kPixelXrgb8888 = 1;
struct GameInfo { const void* data; std::size_t size; const char* path; const char* meta; };
struct AvInfo { double fps; double sampleRate; };
using SetEnvironment = void(*)(bool(*)(unsigned, void*));
using SetVideo = void(*)(void(*)(const void*, unsigned, unsigned, std::size_t));
using SetAudio = void(*)(std::size_t(*)(const std::int16_t*, std::size_t));
using SetAudioSample = void(*)(void(*)(std::int16_t, std::int16_t));
using SetInputPoll = void(*)(void(*)());
using SetInputState = void(*)(std::int16_t(*)(unsigned, unsigned, unsigned, unsigned));
using ApiVersion = unsigned(*)();
using Init = void(*)();
using Deinit = void(*)();
using GetSystemAvInfo = void(*)(AvInfo*);
using LoadGame = bool(*)(const GameInfo*);
using UnloadGame = void(*)();
using Run = void(*)();

template <typename Function>
Function symbol(void* library, const char* name) {
#ifdef _WIN32
  return reinterpret_cast<Function>(GetProcAddress(static_cast<HMODULE>(library), name));
#else
  return reinterpret_cast<Function>(dlsym(library, name));
#endif
}
void fail(std::string* error, const std::string& text) { if (error) *error = text; }
}

LibretroCore* LibretroCore::active_ = nullptr;

LibretroCore::~LibretroCore() { close(); }

bool LibretroCore::open(const std::filesystem::path& library, std::string* error) {
  close();
#ifdef _WIN32
  library_ = LoadLibraryW(library.wstring().c_str());
#else
  library_ = dlopen(library.c_str(), RTLD_NOW | RTLD_LOCAL);
#endif
  if (!library_) return fail(error, "não foi possível carregar o core libretro: " + library.string()), false;
  if (!symbol<ApiVersion>(library_, "retro_api_version") || symbol<ApiVersion>(library_, "retro_api_version")() != 1)
    return fail(error, "ABI libretro incompatível"), close(), false;
  active_ = this;
  return initialize(error);
}

bool LibretroCore::initialize(std::string* error) {
  const auto setEnvironment = symbol<SetEnvironment>(library_, "retro_set_environment");
  const auto setVideo = symbol<SetVideo>(library_, "retro_set_video_refresh");
  const auto setAudio = symbol<SetAudio>(library_, "retro_set_audio_sample_batch");
  const auto setAudioSample = symbol<SetAudioSample>(library_, "retro_set_audio_sample");
  const auto setPoll = symbol<SetInputPoll>(library_, "retro_set_input_poll");
  const auto setState = symbol<SetInputState>(library_, "retro_set_input_state");
  const auto init = symbol<Init>(library_, "retro_init");
  if (!setEnvironment || !setVideo || !setAudio || !setAudioSample || !setPoll || !setState || !init)
    return fail(error, "core libretro sem callbacks obrigatórios"), false;
  setEnvironment(&LibretroCore::environmentCallback);
  setVideo(&LibretroCore::videoCallback);
  setAudio(&LibretroCore::audioCallback);
  setAudioSample(&LibretroCore::audioSampleCallback);
  setPoll(&LibretroCore::inputPollCallback);
  setState(&LibretroCore::inputStateCallback);
  init();
  initialized_ = true;
  return true;
}

bool LibretroCore::loadRom(const std::filesystem::path& rom, std::string* error) {
  if (!library_ || !initialized_) return fail(error, "core libretro não aberto"), false;
  const auto load = symbol<LoadGame>(library_, "retro_load_game");
  if (!load) return fail(error, "core libretro sem retro_load_game"), false;
  std::ifstream input(rom, std::ios::binary);
  if (!input) return fail(error, "ROM não encontrada: " + rom.string()), false;
  const std::vector<std::uint8_t> data((std::istreambuf_iterator<char>(input)), {});
  if (data.empty()) return fail(error, "ROM vazia: " + rom.string()), false;
  const auto extension = rom.extension().string();
  if ((extension == ".gba" && data.size() < 0xC0) ||
      ((extension == ".gb" || extension == ".gbc") && data.size() < 0x150))
    return fail(error, "ROM truncada ou sem cabeçalho mínimo para o core: " + rom.string()), false;
  loadedRom_ = rom;
  systemDirectory_ = rom.parent_path().string();
  saveDirectory_ = (rom.parent_path() / "saves").string();
  std::filesystem::create_directories(saveDirectory_);
  const auto path = rom.string();
  const GameInfo info{data.data(), data.size(), path.c_str(), nullptr};
  if (!load(&info)) return fail(error, "o core libretro rejeitou a ROM: " + rom.string()), false;
  loaded_ = true;
  return true;
}

bool LibretroCore::runFrame(std::string* error) {
  if (!loaded_) return fail(error, "nenhuma ROM carregada no core libretro"), false;
  const auto run = symbol<Run>(library_, "retro_run");
  if (!run) return fail(error, "core libretro sem retro_run"), false;
  run();
  ++frames_;
  return true;
}

void LibretroCore::unload() {
  if (loaded_ && library_) if (const auto function = symbol<UnloadGame>(library_, "retro_unload_game")) function();
  loaded_ = false;
  frames_ = 0;
  videoFrame_.clear();
}

void LibretroCore::close() {
  unload();
  if (initialized_ && library_) if (const auto function = symbol<Deinit>(library_, "retro_deinit")) function();
  initialized_ = false;
#ifdef _WIN32
  if (library_) FreeLibrary(static_cast<HMODULE>(library_));
#else
  if (library_) dlclose(library_);
#endif
  library_ = nullptr;
  if (active_ == this) active_ = nullptr;
}

bool LibretroCore::environment(unsigned command, void* data) {
  if (command == kEnvSetPixelFormat) {
    if (!data || *static_cast<unsigned*>(data) != kPixelXrgb8888) return false;
    return true;
  }
  if (command == kEnvGetSystemDirectory) { if (!data) return false; *static_cast<const char**>(data) = systemDirectory_.c_str(); return true; }
  if (command == kEnvGetSaveDirectory) { if (!data) return false; *static_cast<const char**>(data) = saveDirectory_.c_str(); return true; }
  return false;
}

void LibretroCore::receiveVideo(const void* data, unsigned width, unsigned height, std::size_t pitch) {
  if (!data || width == 0 || height == 0) return;
  videoWidth_ = width; videoHeight_ = height; videoFrame_.resize(static_cast<std::size_t>(width) * height);
  const auto* source = static_cast<const std::uint32_t*>(data);
  for (unsigned y = 0; y < height; ++y) std::memcpy(videoFrame_.data() + static_cast<std::size_t>(y) * width, reinterpret_cast<const std::uint8_t*>(source) + pitch * y, static_cast<std::size_t>(width) * sizeof(std::uint32_t));
}
std::size_t LibretroCore::receiveAudio(const std::int16_t*, std::size_t frames) { return frames; }
bool LibretroCore::environmentCallback(unsigned command, void* data) { return active_ && active_->environment(command, data); }
void LibretroCore::videoCallback(const void* data, unsigned width, unsigned height, std::size_t pitch) { if (active_) active_->receiveVideo(data, width, height, pitch); }
std::size_t LibretroCore::audioCallback(const std::int16_t* data, std::size_t frames) { return active_ ? active_->receiveAudio(data, frames) : 0; }
void LibretroCore::audioSampleCallback(std::int16_t, std::int16_t) {}
void LibretroCore::inputPollCallback() {}
std::int16_t LibretroCore::inputStateCallback(unsigned, unsigned, unsigned, unsigned) { return 0; }
}
