C2 deve ser empacotado com o formato ZIP legado.
