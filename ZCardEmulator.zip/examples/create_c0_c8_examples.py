from pathlib import Path
import json
import shutil
import struct

ROOT = Path(__file__).resolve().parent
source_zexe = ROOT / "complete-game.zgame" / "CODE" / "game.zexe"
source_memory_required = 1024
if source_zexe.exists():
    source_bytes = source_zexe.read_bytes()
    if len(source_bytes) >= 36 and source_bytes[:4] == b"ZEXE":
        source_memory_required = struct.unpack_from("<I", source_bytes, 32)[0]
profiles = {
    "c0-minimal": ("C0 Minimal ZEXE", "menu", "CODE/game.zexe"),
    "c1-directory": ("C1 Directory Card", "menu", "CODE/game.zexe"),
    "c2-legacy-zcard": ("C2 Legacy ZCARD", "menu", "CODE/game.zexe"),
    "c3-zcf-base": ("C3 ZCF Base", "menu", "CODE/game.zexe"),
    "c4-update": ("C4 Update", "menu", "CODE/game.zexe"),
    "c5-dlc": ("C5 DLC", "menu", "CODE/game.zexe"),
    "c6-save-user": ("C6 Save and User", "menu", "CODE/game.zexe"),
    "c7-streaming": ("C7 Streaming", "menu", "CODE/game.zexe"),
    "c8-native-windows": ("C8 Native Windows Payload", "menu", "CODE/game.zexe"),
}

for dirname, (title, scene, executable) in profiles.items():
    root = ROOT / dirname
    (root / "META").mkdir(parents=True, exist_ok=True)
    is_native_windows = dirname == "c8-native-windows"
    if not is_native_windows:
        (root / "CODE").mkdir(parents=True, exist_ok=True)
        if source_zexe.exists():
            shutil.copyfile(source_zexe, root / "CODE" / "game.zexe")
    else:
        shutil.rmtree(root / "CODE", ignore_errors=True)
    manifest = {
        "format": "zgame-native-0.1" if is_native_windows else "zgame-0.1",
        "title": title,
        "platform": "windows-x64" if is_native_windows else "zconsole-v1",
        "executable": "native/windows/MyGame.exe" if is_native_windows else executable,
        "boot_scene": scene,
        "profile": dirname.split("-", 1)[0].upper(),
    }
    if not is_native_windows:
        manifest["entrypoint"] = 0
        manifest["memory_required"] = source_memory_required
    (root / "META" / "zgame.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    (root / "META" / "assets.zgf").write_text("ZGF-0.1\n", encoding="utf-8")
    readme = {
        "c0-minimal": "C0 testa somente o programa ZEXE mínimo.",
        "c1-directory": "C1 é montado diretamente como diretório Virtual ZCARD.",
        "c2-legacy-zcard": "C2 deve ser empacotado com o formato ZIP legado.",
        "c3-zcf-base": "C3 deve ser empacotado com --format zcf.",
        "c4-update": "C4 reserva UPDATE; a escrita é feita pela API writeStream.",
        "c5-dlc": "C5 reserva DLC para conteúdo opcional.",
        "c6-save-user": "C6 testa SAVE e USER com payloads transacionais.",
        "c7-streaming": "C7 contém assets para testar manifesto, prefetch e cache.",
        "c8-native-windows": "C8 é apenas payload Windows autorizado; não é ZEXE e não deve ser executado pelo loader virtual.",
    }[dirname]
    (root / "README.md").write_text(readme + "\n", encoding="utf-8")

# Assets deterministicos para o perfil de streaming.
streaming = ROOT / "c7-streaming" / "assets"
streaming.mkdir(parents=True, exist_ok=True)
(streaming / "menu.ztex").write_bytes(b"ZTEXTURE-MENU\n")
(streaming / "level-01.zmesh").write_bytes(b"ZMESH-LEVEL-01\n")
(streaming / "level-01.zmat").write_bytes(b"ZMATERIAL-LEVEL-01\n")
(ROOT / "c7-streaming" / "META" / "assets.zgf").write_text(
    "ZGF-0.1\n"
    "asset|assets/menu.ztex|resident|100|100|-|ztex\n"
    "asset|assets/level-01.zmesh|streaming|80|200|-|zmesh\n"
    "asset|assets/level-01.zmat|streaming|80|200|assets/level-01.zmesh|zmat\n",
    encoding="utf-8",
)

# Payload Windows ilustrativo, sem binario de terceiros.
native = ROOT / "c8-native-windows" / "native" / "windows"
native.mkdir(parents=True, exist_ok=True)
(native / "PLACEHOLDER.txt").write_text(
    "Coloque aqui somente um executável Windows próprio ou redistribuível com autorização.\n"
    "Este arquivo não é executado pelo ZEXE loader atual.\n",
    encoding="utf-8",
)
(ROOT / "c8-native-windows" / "META" / "native-runtime.json").write_text(
    json.dumps({
        "format": "zconsole-native-payload-0.1",
        "host": "windows-x64",
        "executable": "native/windows/MyGame.exe",
        "execution": "external-host-required",
        "redistribution": "owner-authorized-only",
    }, indent=2) + "\n",
    encoding="utf-8",
)
print("created", len(profiles), "profiles under", ROOT)
