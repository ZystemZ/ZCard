C6 testa SAVE e USER com payloads transacionais.
