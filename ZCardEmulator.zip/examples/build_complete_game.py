from pathlib import Path
import json
import struct
import zipfile

ROOT = Path(__file__).parent / "complete-game.zgame"
CODE = ROOT / "CODE" / "game.zexe"
META = ROOT / "META"
ASSETS = ROOT / "assets"

# ZCPU-32 program:
# 1. Write a boot marker (1) to 0x200.
# 2. Compare A with 7 and branch over the failure path.
# 3. Call a function that writes 42 to 0x208.
# 4. Halt. The dashboard/CPU can inspect these memory cells.
code = bytearray()
labels = {}
fixups = []

def label(name):
    labels[name] = len(code)

def op(value):
    code.append(value)

def imm(value):
    code.extend(struct.pack("<I", value))

def target(name):
    fixups.append((len(code), name))
    code.extend(b"\0\0\0\0")

op(0x01); imm(1)                 # LOAD_IMM 1
op(0x03); imm(0x200)             # STORE 0x200
op(0x01); imm(7)                 # LOAD_IMM 7
op(0x05); imm(7)                 # CMP_IMM 7
op(0x06); target("call_path")    # JZ call_path
op(0x01); imm(99)                # failure path (not taken)
op(0x03); imm(0x204)             # STORE 0x204
label("call_path")
op(0x09); target("award")        # CALL award
op(0xff)                          # HALT
label("award")
op(0x01); imm(42)                # LOAD_IMM 42
op(0x03); imm(0x208)             # STORE 0x208
op(0x0a)                          # RET

for position, name in fixups:
    code[position:position + 4] = struct.pack("<I", labels[name])

header = (
    b"ZEXE"
    + struct.pack(
        "<HHIIIIIIII",
        1,              # version
        1,              # ZCPU-32
        40,             # header size
        0,              # entry point
        40,             # code file offset
        len(code),
        0, 0,           # no data segment yet
        1024,           # required virtual memory
        sum(code) & 0xFFFFFFFF,
    )
)
CODE.parent.mkdir(parents=True, exist_ok=True)
META.mkdir(parents=True, exist_ok=True)
ASSETS.mkdir(parents=True, exist_ok=True)
CODE.write_bytes(header + code)
(META / "zgame.json").write_text(json.dumps({
    "format": "zgame-0.1",
    "title": "ZConsole Treasure Run",
    "platform": "zconsole-v1",
    "executable": "CODE/game.zexe",
    "entrypoint": 0,
    "boot_scene": "menu",
    "memory_required": 1024,
}, indent=2) + "\n", encoding="utf-8")
(META / "assets.zgf").write_text(
    "ZGF-0.1\n"
    "asset|assets/title.txt|boot|10|100|-|text\n"
    "asset|assets/treasure.txt|menu|20|200|-|dialogue\n"
    "scene|menu|assets/title.txt,assets/treasure.txt\n",
    encoding="utf-8",
)
(ASSETS / "title.txt").write_text("ZCONSOLE TREASURE RUN\n", encoding="utf-8")
(ASSETS / "treasure.txt").write_text("TREASURE MARKER: memory[0x208] = 42\n", encoding="utf-8")

card = ROOT.parent / "complete-game.zcard"
with zipfile.ZipFile(card, "w", compression=zipfile.ZIP_STORED) as archive:
    for path in sorted(ROOT.rglob("*")):
        if path.is_file():
            archive.write(path, path.relative_to(ROOT).as_posix())
print(f"created {CODE} ({len(header) + len(code)} bytes)")
print(f"created {card}")
print(f"code bytes: {len(code)}; labels: {labels}")
