C0 testa somente o programa ZEXE mínimo.
