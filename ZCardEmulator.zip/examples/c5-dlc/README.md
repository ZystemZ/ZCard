C5 reserva DLC para conteúdo opcional.
