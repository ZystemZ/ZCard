C7 contém assets para testar manifesto, prefetch e cache.
