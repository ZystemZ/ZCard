C8 é apenas payload Windows autorizado; não é ZEXE e não deve ser executado pelo loader virtual.
