from pathlib import Path
import struct
store = 0x100
code = bytes([1,42,0,0,0,2,5,0,0,0,3]) + struct.pack('<I', store) + bytes([0xff])
header = b'ZEXE' + struct.pack('<HHIIIIIIII', 1, 1, 40, 0, 40, len(code), 0, 0, store+4, sum(code) & 0xffffffff)
out = Path(__file__).parent / 'demo.zgf' / 'CODE' / 'game.zexe'
out.parent.mkdir(parents=True, exist_ok=True)
out.write_bytes(header + code)
print(out)
