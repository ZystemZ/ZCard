C3 deve ser empacotado com --format zcf.
