C4 reserva UPDATE; a escrita é feita pela API writeStream.
