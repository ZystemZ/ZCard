C1 é montado diretamente como diretório Virtual ZCARD.
