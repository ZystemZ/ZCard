# Exemplo Windows x86 32-bit

Este diretório demonstra o manifesto `zgame-native-0.2` para um programa Windows PE32. O programa convidado enxerga exatamente uma vCPU (`visible_processors: 1`). O ZConsole pode usar workers do host para I/O, áudio, renderização, cache e outras tarefas sem expor CPUs adicionais ao processo 32-bit.

O arquivo `native/windows-x86/game.exe` não é incluído neste exemplo. Ele deve ser fornecido pelo usuário e colocado no caminho indicado pelo manifesto. O exemplo não redistribui executáveis, jogos, DLLs ou conteúdo proprietário.

Para um programa Windows x64, use `architecture: x86_64`, `binary_format: PE32+`, `abi: win64` e um valor maior para `visible_processors` quando o programa realmente suportar execução paralela. A presença de 64 bits, por si só, não torna um programa multithread; ela apenas permite que a política de execução exponha mais de uma vCPU.
