from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent

rom_root = ROOT / "rom-gba"
(rom_root / "META").mkdir(parents=True, exist_ok=True)
(rom_root / "roms").mkdir(parents=True, exist_ok=True)
rom_bytes = bytes([0x00] * 32) + b"ZCONSOLE GBA FIXTURE\n"
(rom_root / "roms" / "demo.gba").write_bytes(rom_bytes)
(rom_root / "META" / "rom-runtime.json").write_text(json.dumps({
    "format": "zcard-rom-runtime-0.1",
    "rom": "roms/demo.gba",
    "system": "gba",
    "internal": {"enabled": True, "core": "gba"},
    "external": {"enabled": False, "command": "vgba.exe"},
}, indent=2) + "\n", encoding="utf-8")
(rom_root / "README.md").write_text(
    "Este é um fixture de ROM GBA para testar o resolvedor. Não é um jogo comercial e não deve ser tratado como ZEXE.\n",
    encoding="utf-8",
)

disc_root = ROOT / "disc-iso"
(disc_root / "META").mkdir(parents=True, exist_ok=True)
(disc_root / "media").mkdir(parents=True, exist_ok=True)
(disc_root / "media" / "demo.iso").write_bytes(b"ZCONSOLE DISC FIXTURE\n")
(disc_root / "META" / "rom-runtime.json").write_text(json.dumps({
    "format": "zcard-rom-runtime-0.1",
    "rom": "media/demo.iso",
    "system": "pc",
    "media": "iso",
    "mount": {"enabled": True, "mode": "windows"},
    "internal": {"enabled": False, "core": "pc"},
    "external": {"enabled": False, "command": ""},
}, indent=2) + "\n", encoding="utf-8")
(disc_root / "README.md").write_text(
    "Este é um fixture de ISO de PC para testar montagem no Windows. Não é uma ISO bootável.\n",
    encoding="utf-8",
)
print("created ROM and disc fixtures")
