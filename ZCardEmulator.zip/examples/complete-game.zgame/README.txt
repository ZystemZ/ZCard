JOGO EXEMPLO: ZCONSOLE TREASURE RUN

Este é um jogo autoral mínimo para testar o pipeline completo sem assets de terceiros:

  diretório do jogo
    -> game.zexe
    -> META/zgame.json
    -> META/assets.zgf
    -> assets próprios
    -> Builder ZCARD
    -> mount
    -> boot da CPU virtual

Gerar ou regenerar todos os arquivos:

  python examples/build_complete_game.py

Estrutura:

  examples/complete-game.zgame/
    META/zgame.json
    META/assets.zgf
    CODE/game.zexe
    assets/title.txt
  assets/treasure.txt

O manifesto usa os tipos customizados `text` e `dialogue` no sétimo campo de cada linha `asset`. Esses tipos são etiquetas de metadados; o runtime atual continua lendo os arquivos como bytes.

Comportamento do programa:

  - escreve 1 em memória[0x200] como marcador de boot;
  - compara A com 7;
  - usa JZ para selecionar o caminho de sucesso;
  - usa CALL/RET para executar a rotina de tesouro;
  - escreve 42 em memória[0x208];
  - termina com HALT.

Teste no dashboard:

  1. Pressione F5.
  2. Clique em Montar diretório.
  3. Selecione examples\\complete-game.zgame.
  4. Verifique título ZConsole Treasure Run e cena menu.
  5. Use Reset e depois Step para acompanhar PC e instruções.
  6. Ao concluir, a CPU deverá estar HALTED e A deverá ser 42.

O arquivo examples/complete-game.zcard contém o mesmo jogo empacotado em ZIP stored.
