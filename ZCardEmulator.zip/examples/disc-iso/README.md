Este é um fixture de ISO de PC para testar montagem no Windows. Não é uma ISO bootável.
