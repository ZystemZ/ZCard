EXEMPLO DE DIRETORIO VIRTUAL ZCARD

Selecione esta pasta no dashboard usando "Montar diretório".

Estrutura obrigatoria:
  META/assets.zgf   manifesto de assets
  META/zgame.json   manifesto do jogo
  CODE/game.zexe    executavel virtual ZEXE
  assets/           arquivos de exemplo

No dashboard, selecione a pasta examples/demo.zgf, confirme a montagem e observe:
  - BOOT OK
  - titulo ZConsole MVP Demo
  - cena menu
  - entry point 0
  - CPU HALTED
  - A=47 e quatro instrucoes executadas

O arquivo examples/demo.zcard contem o mesmo exemplo empacotado como ZIP.
