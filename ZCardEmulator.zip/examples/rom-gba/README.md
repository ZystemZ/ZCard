Este é um fixture de ROM GBA para testar o resolvedor. Não é um jogo comercial e não deve ser tratado como ZEXE.
