1. Extraia esta pasta inteira, preservando a estrutura.
2. Abra o arquivo ZCardEmulator.sln (não abra somente um .vcxproj).
3. Se os projetos aparecerem como descarregados, feche o Visual Studio e execute no PowerShell:
   Set-ExecutionPolicy -Scope Process Bypass
   .\check_vs.ps1
4. Se não aparecer Microsoft.Cpp.Default.props ou cl.exe, abra o Visual Studio Installer e instale:
   - Desktop development with C++
   - MSVC v143 - VS 2022 C++ x64/x86 build tools
   - Windows 10/11 SDK
   - C++ MSBuild tools
5. Reabra ZCardEmulator.sln.
6. Selecione Debug e x64.
7. No Gerenciador de Soluções, clique com o botão direito em zconsole_tests e use Definir como Projeto de Inicialização.
8. Pressione F5.

Projetos executáveis:
- zconsole_tests: testes nativos.
- zconsole_demo: emulador em console.
- zcard_emulator_gui: interface Win32.

Para abrir o Gerenciador de Soluções: Exibir > Gerenciador de Soluções ou Ctrl+Alt+L.

Os projetos foram recriados com ToolsVersion=Current, imports MSBuild completos, v143, Debug/Release x64 e arquivos .vcxproj.user.
