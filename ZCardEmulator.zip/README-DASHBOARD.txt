A GUI agora é um dashboard, não apenas uma tela de abertura.

Painéis:
- Status do emulador, CPU e PC.
- Lista de assets do manifesto com grupo e prioridade.
- Eventos e log de boot/prefetch.
- Cache, misses, bytes, streaming e latência.

Botões:
- Montar diretório: escolha examples\demo.zgf.
- Abrir .zcard: escolha examples\demo.zcard.
- Prefetch boot: enfileira o grupo boot.
- Processar fila: executa a fila e atualiza métricas.

Execute com Debug/x64 e F5.
