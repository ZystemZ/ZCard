#pragma once
#include <cstdint>
#include <memory>
namespace zconsole {
class ZHost {
public:
  virtual ~ZHost() = default;
  virtual void initialize() = 0;
  virtual void shutdown() = 0;
  virtual std::uint64_t getTimeUs() const = 0;
  virtual void sleepMs(std::uint32_t ms) const = 0;
};
std::unique_ptr<ZHost> createHost();
}
