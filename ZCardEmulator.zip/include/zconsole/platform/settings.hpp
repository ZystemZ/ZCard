#pragma once
#include "zconsole/platform/services.hpp"
#include <cstdint>
#include <filesystem>
#include <map>
#include <string>

namespace zconsole {

struct ZExternalEmulatorProfile {
  bool enabled = false;
  std::filesystem::path executable;
  std::string arguments = "{rom}";
  bool internalEnabled = false;
  std::filesystem::path internalLibrary;
};

struct ZHostSettings {
  std::filesystem::path systemDirectory;
  std::filesystem::path savesDirectory;
  std::filesystem::path cacheDirectory;
  std::uint32_t cpuThreads = 0; // zero means automatic
  std::uint32_t memoryMiB = 512;
  bool networkEnabled = false;
  std::uint16_t networkUdpPort = 0;
  std::string keyboardProfile = "default";
  std::string controllerId;
  bool preferInternalCores = true;
  ZGraphicsConfig graphics{};
  ZAudioConfig audio{};
  std::map<std::string, ZExternalEmulatorProfile> emulators;
};

std::filesystem::path defaultSettingsPath();
ZHostSettings defaultHostSettings();
bool loadHostSettings(ZHostSettings& settings, std::string* error = nullptr);
bool saveHostSettings(const ZHostSettings& settings, std::string* error = nullptr);

} // namespace zconsole
