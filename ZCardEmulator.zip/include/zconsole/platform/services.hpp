#pragma once
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <vector>
namespace zconsole {
enum class ZGraphicsBackend { Auto, Vulkan, DirectX12, DirectX11, OpenGL, Software };
struct ZDisplayMode { std::uint32_t width=1920,height=1080,refreshHz=60; bool hdr=false; };
struct ZGraphicsConfig { ZGraphicsBackend backend=ZGraphicsBackend::Auto; ZDisplayMode mode{}; bool fullscreen=false; bool vsync=true; bool dynamicResolution=true; std::uint32_t msaa=1; };
enum class ZAudioBackend { Auto, Wasapi, PulseAudio, ALSA, SDL, Null };
struct ZAudioConfig { ZAudioBackend backend=ZAudioBackend::Auto; std::uint32_t sampleRate=48000,channels=2,bufferFrames=1024; bool surround=false; };
enum class ZControllerFamily { Unknown, Keyboard, Nes, Snes, Xbox, Switch, Playstation3, Playstation4, Playstation5 };
struct ZControllerInfo { std::string id,name; ZControllerFamily family=ZControllerFamily::Unknown; std::uint32_t buttons=0,axes=0; };
enum class ZStorageScope { InstallReadOnly, SaveReadWrite, CacheReadWrite, UserReadWrite };
class ZStorage { public: ZStorage(std::filesystem::path root,std::uint64_t quotaBytes=4ull*1024*1024*1024); bool write(ZStorageScope scope,const std::string& relative,const std::vector<std::uint8_t>& data,std::string* error=nullptr); std::vector<std::uint8_t> read(ZStorageScope scope,const std::string& relative,std::string* error=nullptr) const; std::filesystem::path path(ZStorageScope scope,const std::string& relative,std::string* error=nullptr) const; private: std::filesystem::path root_;std::uint64_t quota_; };
class ZNetwork { public: bool openUdp(std::uint16_t port,std::string* error=nullptr); bool send(const std::string& host,std::uint16_t port,const std::vector<std::uint8_t>& payload,std::string* error=nullptr); void close(); bool active()const{return active_;} private: bool active_=false; };
}
