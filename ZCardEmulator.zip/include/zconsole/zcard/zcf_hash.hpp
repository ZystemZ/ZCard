#pragma once
#include <cstdint>
#include <vector>
namespace zconsole { std::vector<std::uint8_t> zcfSha256(const std::vector<std::uint8_t>& data); }
