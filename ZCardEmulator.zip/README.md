# ZConsole Runtime C++ — Windows / Visual Studio

Esta é a versão nativa C++ do runtime de assets do ZCARD/ZConsole. O projeto foi preparado para ser aberto diretamente no **Visual Studio 2022** como uma pasta CMake. Não é necessário usar Bash.

## Abrir no Visual Studio

1. Instale o Visual Studio 2022 com o workload **Desktop development with C++** e suporte a CMake.
2. Abra o Visual Studio.
3. Selecione **File > Open > Folder**.
4. Escolha a pasta deste projeto.
5. Selecione o preset `windows-vs2022`.
6. Compile o alvo `zconsole_demo` em `x64-Debug`.

O Visual Studio também pode abrir o arquivo `CMakePresets.json` diretamente pelo menu **CMake > Select Configure Preset**.

## Executar pelo PowerShell

No terminal integrado do Visual Studio:

```powershell
cmake --preset windows-vs2022
cmake --build --preset windows-vs2022-debug
.\out\build\windows-vs2022\Debug\zconsole_demo.exe .\examples\demo.zgf menu
```

Saída esperada:

```text
ZConsole C++ Runtime | scene=menu | loaded=2
  assets/menu.ogg | state=ready | deadline=on_time | channel=1
  assets/menu.bin | state=ready | deadline=on_time | channel=2
STREAM OK | asset=assets/menu.ogg | bytes=17
METRICS | hits=0 misses=2 latency_ms=33.2031 streamed=17
```

## Formato do exemplo ZGF

Para manter o primeiro projeto sem dependências externas, a V0 nativa usa um diretório `.zgf` com:

```text
GAME.zgf/
├── META/assets.zgf
└── assets/
```

Cada linha de asset segue:

```text
asset|caminho|grupo|prioridade|deadline_ms|dependências
```

Cenas seguem:

```text
scene|nome|asset1,asset2
```

O runtime C++ implementa cache, dependências, prefetch, cancelamento, canais, streaming e deadlines. A migração posterior para um arquivo ZGF compactado pode manter a mesma API e trocar somente o leitor de mídia.

## Teste sem Visual Studio

Para validar em Linux, macOS ou CI, use o preset `linux-gcc` equivalente; no Windows o caminho recomendado é Visual Studio/CMake.

## CLI nativa

A CLI C++ aceita os parâmetros abaixo:

```powershell
.\out\build\windows-vs2022\Debug\zconsole_demo.exe `
  .\examples\demo.zgf `
  --scene level `
  --channels 4 `
  --scheduler deadline `
  --deadline-ms 100 `
  --budget 8
```

Opções disponíveis: `--scene`, `--channels`, `--cache-bytes`, `--budget`, `--deadline-ms`, `--bandwidth` e `--scheduler priority|deadline`.

## Testes nativos

O projeto inclui o alvo `zconsole_tests`. No Visual Studio, compile e execute esse alvo normalmente. Pelo PowerShell:

```powershell
cmake --build --preset windows-vs2022-debug --target zconsole_tests
ctest --test-dir .\out\build\windows-vs2022 -C Debug --output-on-failure
```

Os testes verificam carregamento do manifesto, cena, dependência, prefetch, cache, deadline e cancelamento.

## Arquitetura ZCARD Emulator V2

O projeto deixou de ser apenas um `AssetRuntime` e agora representa o começo do **ZCARD Emulator / ZConsole Emulator 0.1**:

```text
ZCARD Emulator
├── ZConsole Emulator
├── Virtual ZCARD
├── ZGame Runtime
└── Windows/Linux Host
```

O `AssetRuntime` continua compatível. A nova classe `ZAssetStream` permite leitura real em chunks, sem carregar o arquivo inteiro para a memória. A implementação atual é `FileAssetStream`; no futuro serão adicionados `VirtualZCardStream` e `ZHSAssetStream`.

## GUI Windows

No Visual Studio, compile o alvo `zcard_emulator_gui`. Ele abre uma janela Win32 com:

- **Abrir diretório ZGF/ZCARD** — monta um diretório Virtual ZCARD;
- **Abrir arquivo** — reservado para o reader de `.zcard` compactado;
- **Selecionar drive** — lista as unidades do Windows para futura detecção de ZCARD físico.

Para o protótipo atual, use um diretório como `examples\\demo.zgf`.

## Núcleo e GUI

A V2 inclui `ZConsole`, com memória linear, timing em microssegundos, reset e estado de execução. Isso ainda não é uma CPU real; é a base do ciclo de vida do emulador.

A GUI Win32 tem quatro botões:

1. Abrir diretório Virtual ZCARD;
2. Abrir arquivo `.zcard`/`.zgf`;
3. Abrir configuração;
4. Listar drives Windows.

O mount funcional nesta versão é feito pelo diretório `examples\\demo.zgf`. O suporte a arquivo compactado e a conexão direta com um drive físico serão adicionados por implementações de reader/device sem alterar a API de jogo.

## CPU virtual

A CPU V0.1 possui `LOAD_IMM`, `ADD_IMM`, `STORE`, `JMP`, `NOP` e `HALT`, com registradores A/B/PC, flag zero e contador de instruções. Ela serve para validar o ciclo do emulador antes da CPU final.

## Arquivo `.zcard`

A `VirtualZCard` agora aceita:

```text
examples\\demo.zgf       # diretório
examples\\demo.zcard    # arquivo ZIP
```

O reader ZIP suporta entradas `stored` sem DLL externa. Para arquivos ZIP DEFLATE, o CMake usa ZLIB quando disponível. O projeto já inclui `examples\\demo.zcard` para teste.

## GUI de monitoramento

A GUI atualiza automaticamente o painel de status a cada 500 ms, mostrando cache hits/misses, prefetch processado, falhas, bytes e latência.

## Primeiro marco: ZEXE -> ZCARD -> CPU

O MVP-1 define o formato virtual `ZEXE` com assinatura `ZEXE`, versão 1, arquitetura `ZCPU-32` little-endian, header fixo de 40 bytes, entry point, segmento CODE, requisito de memória e checksum por soma de bytes. `ZExecutableLoader` valida esses campos antes de copiar o CODE para a memória virtual. O programa de exemplo executa `LOAD_IMM 42`, `ADD_IMM 5`, `STORE 0x100` e `HALT`.

`ZCardBuilder` cria um `.zcard` ZIP armazenado a partir de um diretório que contenha `META/zgame.json` e `CODE/game.zexe`. O emulador lê o manifesto, localiza o executável, carrega-o e executa a CPU no boot. O teste `zconsole_tests` cobre o fluxo ponta a ponta e confirma `A=47`, `PC=16`, memória `0x100=47` e quatro instruções executadas.

Para regenerar o executável do exemplo:

```text
python examples/build_minimal_zexe.py
```

O manifesto `zgame.json` agora rejeita formato/plataforma incompatíveis, campos obrigatórios ausentes, entry point divergente, memória insuficiente e caminhos com `..`. A CPU também expõe `pause()`, `resume()` e `paused()`. Durante esta etapa foi corrigida a interpretação de `-` como lista de dependências vazia no manifesto ZGF.

Os opcodes adicionais da CPU V0.2 são `CMP_IMM`, `JZ`, `PUSH_A`, `POP_A`, `CALL` e `RET`. O registrador `SP` começa no fim da memória virtual; a execução pode ser pausada e interrompida por breakpoint antes do fetch. Os testes cobrem salto condicional, pilha, breakpoint e retomada.

O reader `ZCardArchive` agora valida CRC32 após leitura, limita entradas a 256 MiB, rejeita ZIP64, arquivos criptografados, cartões divididos em discos e nomes inseguros/path traversal. A API `entries()` permite enumerar o conteúdo do cartão; a leitura de `META/zgame.json` continua disponível através de `VirtualZCard::openStream`.

O dashboard Win32 agora possui os controles `Boot`, `Pause`, `Resume`, `Reset`, `Stop` e `Step`. `Reset` recarrega o ZEXE sem executá-lo, `Pause` preserva o estado da CPU, `Resume` retoma a execução e `Step` executa uma instrução. As ações registram resultados e erros no painel de eventos.

## Jogo exemplo completo

O diretório `examples/complete-game.zgame` contém um jogo autoral completo para validar o pipeline sem depender de código ou assets externos. O script `python examples/build_complete_game.py` gera `CODE/game.zexe`, os manifestos, dois assets próprios e `examples/complete-game.zcard`. O programa grava `1` em `memory[0x200]`, testa uma condição com `CMP_IMM`/`JZ`, chama uma rotina com `CALL`/`RET`, grava `42` em `memory[0x208]` e termina em `HALT`. O teste automatizado monta tanto o diretório quanto o `.zcard` e verifica esses marcadores na CPU virtual.

Para testar no dashboard, use **Montar diretório** e selecione `examples\\complete-game.zgame`. O título esperado é `ZConsole Treasure Run`; após o boot, a CPU deve estar parada em `HALTED`, com `A=42`. O roteiro detalhado está em `examples/complete-game.zgame/README.txt`.

## Dashboard 0.4

O dashboard agora apresenta o cartão atual, uma lista enumerável de todos os arquivos do diretório Virtual ZCARD ou do arquivo `.zcard`, o conteúdo de `META/zgame.json` em painel somente leitura, o status detalhado da CPU e o log de eventos. O botão `Recarregar` atualiza a lista e o manifesto; selecionar um arquivo registra o caminho no log. Os controles de execução permanecem disponíveis: `Boot`, `Pause`, `Resume`, `Reset`, `Stop` e `Step`.

Na versão seguinte, a seleção de um arquivo mostra tamanho e os primeiros bytes em hexadecimal. O painel `MEMÓRIA HEX` mostra uma janela de 256 bytes em torno do PC atual, atualizada pelo timer do dashboard. Isso permite acompanhar fetch, saltos e alterações de memória enquanto o jogo é executado com `Step`.

## Builder 0.6

A versão 0.6 adiciona o alvo reproduzível `zcard_builder`, independente da GUI:

```text
zcard_builder --source examples/complete-game.zgame \
              --output build/complete-game.zcard \
              --report build/complete-game-report.txt
```

O comando identifica o tipo da fonte antes de validar: projetos ZConsole validam manifesto e ZEXE; pastas ROM/ISO com `META/rom-runtime.json`, como GBA, não precisam de `CODE/game.zexe`; e payloads C8 `zgame-native-0.1` também podem ser empacotados sem ZEXE. Todos percorrem os assets, calculam hashes, geram o `.zcard` e salvam relatório. Ao abrir uma ROM empacotada, o emulador extrai a mídia para um diretório temporário antes de chamar o emulador externo, preservando ROMs grandes como a de 16 MiB. O teste `zcard_builder_cli` foi integrado ao CTest. O roadmap completo está em `docs/BUILDER_0.6.md`.

## Runtime gráfico SDL2

O build pode usar SDL2 real para janela, teclado, áudio PCM e apresentação do framebuffer:

```bash
sudo apt install libsdl2-dev
cmake -S . -B build-sdl -DZCONSOLE_SDL2=ON
cmake --build build-sdl
./build-sdl/zconsole_demo examples/demo.zgf --sdl
```

No Windows, instale SDL2 via vcpkg e configure o CMake com o toolchain do vcpkg. Sem SDL2, `-DZCONSOLE_SDL2=OFF` mantém o modo headless.

O SDL2 é a camada de plataforma, não um renderer AAA. A arquitetura Vulkan/DirectX12 está documentada em `docs/RUNTIME_ARCHITECTURE.md`; os backends 3D ainda são etapas posteriores e não devem ser tratados como implementados antes de haver testes de swapchain, shaders, buffers e recursos GPU.

Os contratos de plataforma estão em `include/zconsole/platform/services.hpp` e incluem perfis de resolução/backends gráficos, áudio HD, famílias de controles, storage sandbox para instalação/saves/cache/user e a API reservada de rede. A implementação atual adiciona o sandbox de filesystem e enumeração de joysticks SDL2; sockets reais, Vulkan, DirectX 12, DirectX 11 e OpenGL continuam sendo backends futuros separados.

Se o projeto não tiver `META/assets.zgf`, o Builder gera essa entrada no pacote final, inferindo o tipo pela extensão dos arquivos em `assets/` (`.ztex` vira `ztex`, `.zmesh` vira `zmesh`, por exemplo). O diretório de origem não é alterado.

O builder também valida os limites ZIP32 antes da serialização e usa conversões explícitas para tamanhos de nomes, arquivos, offsets e contagem de entradas. Isso elimina os warnings MSVC de conversão `size_t` para `uint16_t`/`uint32_t`; o cálculo de CRC32 não usa mais negação unária implícita em tipos unsigned.

## Manifestos nativos Windows/Linux

O formato `zgame-native-0.2` registra a plataforma, a arquitetura do binário, o formato PE/ELF, a ABI, a quantidade de processadores visíveis e a política de workers. Programas `x86`/32-bit devem declarar `visible_processors: 1` e usam `serialized_guest_parallel_host`: o guest vê uma vCPU, enquanto o ZConsole pode usar workers para I/O, áudio, renderização, cache e outras tarefas internas. Programas `x86_64`/64-bit podem declarar múltiplas vCPUs e `parallel_guest`, mas o fato de ser 64-bit não torna um programa automaticamente multithread.

O exemplo completo está em `examples/windows-x86-32/META/zgame.json`. A validação inicial já rejeita manifestos 32-bit que tentem expor mais de uma vCPU e aceita `windows`/`linux` com arquiteturas `x86`, `x86_64`, `arm32` e `arm64`. Esta etapa valida e transporta a política; a execução completa de Win32/Win64, ELF/Linux e suas APIs continua sendo um subsistema posterior.

No Linux desta entrega não havia `cmake` nem `g++` instalados, portanto a validação local foi estrutural; a compilação oficial deve ser feita com Visual Studio 2022, `Debug|x64`, conforme este manual. 

## Abrir diretamente no Visual Studio

Além do CMake, a solução tradicional está disponível em:

```text
ZCardEmulator.sln
```

Ela contém:

```text
zconsole_runtime
zconsole_demo
zconsole_tests
zcard_emulator_gui
```

Abra `ZCardEmulator.sln`, selecione `Debug | x64`, defina `zcard_emulator_gui` ou `zconsole_demo` como projeto de inicialização e pressione `F5` para depurar.


## Roteiro C0–C8 e payloads nativos

O roteiro consolidado está em [`docs/ROADMAP_C0_C8.md`](docs/ROADMAP_C0_C8.md). Os nove diretórios de teste ficam em `examples/c0-minimal` até `examples/c8-native-windows` e podem ser regenerados com:

```bash
python3 examples/create_c0_c8_examples.py
```

Os perfis C0–C7 exercitam ZEXE, diretório, ZIP legado, ZCF, regiões lógicas e streaming. O perfil C8 mostra como organizar um payload Windows autorizado. Um executável Windows não é convertido em ZEXE apenas por ser colocado no ZCARD; ele exige host Windows, Wine/Proton ou um port para o SDK ZConsole.

## Incremento físico ZHS V0.1

O início da Fase 6 foi adicionado sem exigir hardware: `ZHSDevice` separa cartões físicos de `VirtualZCard`, `ZhsMemoryDevice` fornece um backend simulado somente leitura e `zhs_protocol.hpp` define enquadramento binário com CRC32, identificação, leitura e verificação. O transporte de desenvolvimento previsto é USB CDC; USB vendor-specific permanece candidato para a interface final. Consulte [`docs/ZHS_PROTOCOL.md`](docs/ZHS_PROTOCOL.md).

O dispatcher `ZhsDispatcher` agora executa os comandos V0.1 sobre qualquer backend `ZhsDevice`. Também foi adicionado o teste `c0_c8_directory_boot_tests`, que monta e inicializa todos os perfis C0-C8. O gerador foi corrigido para derivar `memory_required` do ZEXE e para emitir deadlines ZGF numéricos no perfil C7.

O dashboard agora possui **Salvar .zcard** e **Salvar .zuf**. A CLI também aceita `--format zuf`; consulte [`docs/ZUF_FORMAT.md`](docs/ZUF_FORMAT.md). O perfil C8 é um payload Windows externo e não contém `game.zexe`. ROMs seguem o contrato de [`docs/ROM_RUNTIME.md`](docs/ROM_RUNTIME.md): uma `.gba`, por exemplo, é encaminhada a um núcleo GBA interno ou a um backend externo configurado, nunca à CPU ZEXE.

O resolvedor `resolveRomRuntime()` já implementa a seleção por extensão e manifesto sem iniciar processos. A execução efetiva do núcleo interno ou do programa externo permanece isolada na camada de host.

A montagem de arquivos foi corrigida: um `.zcard` ZIP legado é reconhecido pelo magic `PK` e aberto por `ZCardArchive`; um container ZCF é reconhecido pelo magic `ZCF0` e aberto por `ZCardContainer`. Assim, C2 e C3 podem ser salvos e reabertos pelo dashboard sem enviar o formato ao parser errado.

Importante: C0–C7 são perfis de teste do pipeline ZEXE e possuem deliberadamente `CODE/game.zexe`. C8 é payload Windows e não possui ZEXE. ROM e ISO ficam em exemplos separados: `examples/rom-gba` contém apenas `roms/demo.gba` e `examples/disc-iso` contém apenas `media/demo.iso`, ambos descritos por `META/rom-runtime.json`. Consulte [`docs/ROM_RUNTIME.md`](docs/ROM_RUNTIME.md) para o encaminhamento ao emulador relacionado.

Uma ISO não é classificada automaticamente como disco de PC: ISOs de PS1/PS2/PS3/PS4/PS5, Xbox/Xbox 360/Xbox One, GameCube/Wii/Wii U e outros consoles devem declarar o console no manifesto e ir para o backend correspondente. Somente `system: "pc"` com `mount.enabled: true` recebe o plano `windows-mount`.

### Compatibilidade por filesystem

O dashboard e `ZConsoleEmulator::boot()` distinguem o tipo do diretório selecionado antes de procurar `CODE/game.zexe`:

| Estrutura selecionada | Manifesto | Tratamento |
|---|---|---|
| Projeto ZConsole | `META/zgame.json` com `format: zgame-0.1` | Carrega e executa o `ZEXE` na CPU virtual |
| Payload nativo Windows | `META/zgame.json` com `format: zgame-native-0.1` | Aceita o cartão e informa que é necessário um launcher/host Windows externo |
| ROM ou ISO | `META/rom-runtime.json` | Resolve o backend interno, processo externo ou montagem Windows pela extensão e pelo manifesto |

Assim, uma pasta `rom-gba` ou `disc-iso` não é mais reportada como “formato inválido de ZCARD” apenas por não possuir `CODE/game.zexe`. O roteador prepara o plano, mas não inicia processos externos nem monta imagens automaticamente. Arquivos `.zcard` ZIP legado e containers ZCF continuam sendo detectados pelo magic; um runtime ROM empacotado em arquivo ainda precisa ser extraído para o filesystem antes de ser encaminhado a um backend que exige um caminho físico.

### Janela de configurações do host

O botão **Configurações** do dashboard abre uma janela persistente em `settings.ini`. Ela reúne diretório do sistema, saves, cache, quantidade de threads da CPU, memória disponível, resolução, taxa de atualização, tela cheia, VSync, sample rate, canais, buffer de áudio, rede UDP, perfil de teclado e identificador do controle. A mesma janela mantém perfis para GBA, NES, SNES, Game Boy, N64, PS1, PS2, GameCube, Wii e PC, cada um com checkbox de ativação, caminho do executável e argumentos; `{rom}` é substituído pelo caminho absoluto da ROM.

Quando um perfil externo está ativo, o boot do cartão usa `CreateProcess` no Windows, sem shell, para iniciar o emulador configurado. Sem perfil ativo, o sistema apenas resolve o backend e informa claramente o que precisa ser configurado. Núcleos internos continuam sendo selecionados pelo manifesto quando disponíveis; esta camada não inventa nem redistribui executáveis de terceiros.

Exemplo de criação de ZCF:

```bash
./build-linux/zcard_builder \
  --source examples/c3-zcf-base \
  --output /tmp/c3.zcard \
  --format zcf
```

## Cores internos incorporados

O projeto inclui os fontes fixados de **mGBA** e **SameBoy** em `third_party/`, com suas licenças upstream preservadas, e os binários libretro Linux gerados em `runtime/cores/`. O host libretro do ZConsole descobre esses binários automaticamente a partir de `runtime/cores`, antes de considerar um processo externo. Em Windows, a mesma árvore deve ser recompilada com MSVC/MinGW para produzir as DLLs correspondentes; não é correto reutilizar uma biblioteca `.so` no Windows.

A execução externa continua sendo controlada por `~/.config/zconsole/settings.ini` no Linux ou `%APPDATA%\\ZConsole\\settings.ini` no Windows. Por exemplo, `emulator.gba.enabled=true`, `emulator.gba.executable=/caminho/mGBA` e `emulator.gba.arguments={rom}` habilitam o fallback externo quando o core interno não estiver disponível. O ZConsole lê essa configuração automaticamente ao abrir o cartão e passa a ROM extraída como argumento.

Para gerar e verificar cartões de vários sistemas, use:

```bash
RGBDS_DIR=/caminho/rgbds tools/build_cores_and_zcards.sh --build-cores
```

Sem `--build-cores`, o script compila o Builder, executa o CTest e gera/verifica cartões para ZEXE, GBA, Windows x86, payload Windows e ISO. O relatório SHA-256 é gravado em `build/zcards/summary.tsv`.

## DLLs Windows via cross-compilation

O ambiente Linux pode gerar os cores libretro Windows com MinGW-w64. O script instala os artefatos em `runtime/cores/windows/x86_64` ou `runtime/cores/windows/i686`, conforme a arquitetura solicitada, e também compila o `zcard_builder` Windows no diretório `build-windows-*`.

```bash
RGBDS_DIR=/caminho/para/rgbds tools/build_cores_and_zcards.sh --windows-dll x86_64
RGBDS_DIR=/caminho/para/rgbds tools/build_cores_and_zcards.sh --windows-dll i686
```

A opção `x86_64` gera DLLs para Windows 64-bit; `i686` gera DLLs para Windows 32-bit. Os binários não são executados pelo Linux durante o processo: a validação consiste em verificar o formato PE, os arquivos gerados e as dependências do pacote. A execução final deve ser validada em Windows, Wine ou CI Windows.

O host Windows escolhe automaticamente a subpasta correspondente à sua arquitetura. O fallback externo continua disponível caso uma DLL não esteja presente ou rejeite uma ROM.
