# Cores libretro incorporados

Esta pasta contém binários locais produzidos a partir dos fontes upstream fixados no projeto:

| Sistema | Core | Arquivo | Origem |
|---|---|---|---|
| GBA | mGBA | `mgba_libretro.so` | `third_party/mGBA`, commit `543a197582c30364584d773a974d7f991892fa43` |
| GB/GBC | SameBoy | `sameboy_libretro.so` | `third_party/SameBoy`, commit `213a12ce93d66b105a113debd9396306066a7cfc` |

Os binários Linux presentes foram compilados localmente como bibliotecas libretro e são carregados diretamente pelo host libretro do ZConsole. O programa não precisa de RetroArch ou de um processo externo para esses sistemas. No Windows, execute o script de build em um ambiente MSVC/MinGW para produzir os equivalentes `.dll`; o código de descoberta procura automaticamente `runtime/cores`.

Os textos de licença permanecem em `third_party/mGBA/LICENSE` e `third_party/SameBoy/LICENSE`. Verifique as licenças upstream antes de redistribuir uma build comercial.

O script `tools/build_cores_and_zcards.sh --build-cores` recompila os cores e copia os artefatos para esta pasta. Para SameBoy, defina `RGBDS_DIR` apontando para uma instalação/árvore RGBDS quando os boot ROMs ainda não existirem.
