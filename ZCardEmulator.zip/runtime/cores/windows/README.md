# Cores libretro Windows

As DLLs geradas por MinGW-w64 ficam separadas por arquitetura:

- `x86_64/`: Windows 64-bit;
- `i686/`: Windows 32-bit.

O executável Windows do ZConsole seleciona a pasta correspondente automaticamente. Não misture DLLs `i686` com um executável 64-bit ou DLLs `x86_64` com um executável 32-bit.
